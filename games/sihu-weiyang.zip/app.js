/* 四虎围羊（Bagh Chal）：尼泊尔古老猎棋。你执 20 只山羊（先放后走），电脑执 4 只老虎；
   老虎跳吃山羊，吃满 5 只获胜；山羊困住全部老虎获胜。
   核心规则逻辑（conn/neighbors/tigerMoves/goatMoves/aiTigerMove）源自
   HossamBalaha/Pixel-Arcade baghchal.js（MIT），棋盘斜线已按标准棋盘修正。 */
function hyEl(id) { return document.getElementById(id); }

/* ---- 核心规则（上游提取，斜线判定已修正为标准棋盘） ---- */
const DIRS = [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [-1, 1], [1, -1], [1, 1]];

  function inB(r, c) {
    return r >= 0 && r < 5 && c >= 0 && c < 5;
  }

  function conn(r1, c1, r2, c2) {
    if (!inB(r2, c2)) return false;
    const dr = r2 - r1, dc = c2 - c1;
    if (dr === 0 && Math.abs(dc) === 1) return true;   // rows
    if (dc === 0 && Math.abs(dr) === 1) return true;   // columns
    if (Math.abs(dr) === 1 && Math.abs(dc) === 1) {    // drawn diagonals only
      return (r1 + c1) % 2 === 0;
    }
    return false;
  }

  function neighbors(r, c) {
    const out = [];
    for (const [dr, dc] of DIRS) {
      if (conn(r, c, r + dr, c + dc)) out.push([r + dr, c + dc]);
    }
    return out;
  }

  // ---- tiger moves: steps to empty connected points + single jumps over a goat ----
  function tigerMoves(b) {
    const out = [];
    for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
      if (b[r][c] !== "T") continue;
      for (const [dr, dc] of DIRS) {
        const mr = r + dr, mc = c + dc;
        if (!conn(r, c, mr, mc)) continue;
        if (b[mr][mc] === "") {
          out.push({fr: r, fc: c, tr: mr, tc: mc, cap: null});
        } else if (b[mr][mc] === "G") {
          const lr = r + 2 * dr, lc = c + 2 * dc;
          if (conn(mr, mc, lr, lc) && b[lr][lc] === "") {
            out.push({fr: r, fc: c, tr: lr, tc: lc, cap: [mr, mc]});
          }
        }
      }
    }
    return out;
  }

  function goatMoves(b) {
    const out = [];
    for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
      if (b[r][c] !== "G") continue;
      for (const [nr, nc] of neighbors(r, c)) {
        if (b[nr][nc] === "") out.push({fr: r, fc: c, tr: nr, tc: nc});
      }
    }
    return out;
  }

  // ---- AI: capture if possible, else keep tigers mobile & out of goat traps ----
  function aiTigerMove(b) {
    const moves = tigerMoves(b);
    if (!moves.length) return null;
    let best = null, bestS = -Infinity;
    for (const m of moves) {
      let s = 0;
      if (m.cap) {
        s = 1000;
        // prefer landings that stay mobile (harder to trap afterwards)
        let open = 0;
        for (const [nr, nc] of neighbors(m.tr, m.tc)) if (b[nr][nc] === "") open++;
        s += open * 2;
      } else {
        let open = 0, goatsNear = 0;
        for (const [nr, nc] of neighbors(m.tr, m.tc)) {
          if (b[nr][nc] === "") open++;
          else if (b[nr][nc] === "G") goatsNear++;
        }
        s = open * 5 - goatsNear * 2;             // mobility first, avoid being surrounded
        if (open <= 1) s -= 20;                    // nearly trapped — avoid
        if (m.fr === 0 || m.fr === 4 || m.fc === 0 || m.fc === 4) s -= 1; // don't camp edges forever
      }
      s += Math.random();
      if (s > bestS) {
        bestS = s;
        best = m;
      }
    }
    return best;
  }


/* ---- WebAudio 合成音效 ---- */
var hyAudioCtx = null;
function hyCtx() {
  if (!hyAudioCtx) {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    hyAudioCtx = new AC();
  }
  if (hyAudioCtx.state === "suspended") hyAudioCtx.resume();
  return hyAudioCtx;
}
function hyTone(freqFrom, freqTo, dur, type, vol, delay) {
  var ctx = hyCtx();
  if (!ctx) return;
  var t0 = ctx.currentTime + (delay || 0);
  var osc = ctx.createOscillator();
  var gain = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freqFrom, t0);
  osc.frequency.exponentialRampToValueAtTime(Math.max(freqTo, 1), t0 + dur);
  gain.gain.setValueAtTime(vol || 0.15, t0);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}
var sfx = {
  place: function () { hyTone(320, 180, 0.1, "triangle", 0.16, 0); },
  move: function () { hyTone(420, 560, 0.09, "sine", 0.12, 0); },
  eat: function () {
    hyTone(220, 70, 0.28, "sawtooth", 0.14, 0);
    hyTone(140, 60, 0.3, "square", 0.07, 0.05);
  },
  select: function () { hyTone(600, 760, 0.06, "sine", 0.09, 0); },
  click: function () { hyTone(500, 700, 0.07, "sine", 0.1, 0); },
  error: function () { hyTone(200, 140, 0.1, "triangle", 0.08, 0); },
  win: function () {
    hyTone(523, 523, 0.14, "sine", 0.16, 0);
    hyTone(659, 659, 0.14, "sine", 0.16, 0.15);
    hyTone(784, 784, 0.14, "sine", 0.16, 0.3);
    hyTone(1047, 1047, 0.26, "sine", 0.16, 0.45);
  },
  lose: function () {
    hyTone(392, 392, 0.16, "sine", 0.15, 0);
    hyTone(330, 330, 0.16, "sine", 0.15, 0.17);
    hyTone(262, 220, 0.3, "sine", 0.15, 0.34);
  }
};

/* ---- 自绘棋子 v3（立体代币风：投影+底座+径向渐变+高光，奶凶老虎 / 软萌山羊） ---- */
function hyTigerSVG(x, y) {
  return '<g transform="translate(' + x + ',' + y + ')">' +
    '<ellipse cx="0" cy="15.5" rx="13" ry="3.6" fill="#000000" opacity="0.22"/>' +
    '<circle cx="-12" cy="-12" r="6" fill="#f59e0b" stroke="#6b4f3a" stroke-width="2"/>' +
    '<circle cx="12" cy="-12" r="6" fill="#f59e0b" stroke="#6b4f3a" stroke-width="2"/>' +
    '<circle cx="-12" cy="-12" r="2.8" fill="#ffd9a0"/>' +
    '<circle cx="12" cy="-12" r="2.8" fill="#ffd9a0"/>' +
    '<circle cy="1.6" r="17" fill="#c2410c"/>' +
    '<circle r="16.5" fill="url(#hyTigerGrad)" stroke="#6b4f3a" stroke-width="2"/>' +
    '<ellipse cx="-5.5" cy="-8.5" rx="6" ry="3.4" fill="#ffffff" opacity="0.55" transform="rotate(-25 -5.5 -8.5)"/>' +
    '<path d="M-6 -15.5 L-4.8 -11 M0 -16.5 L0 -12 M6 -15.5 L4.8 -11" stroke="#9a3412" stroke-width="2.2" stroke-linecap="round" fill="none"/>' +
    '<path d="M-16 -3 L-12.5 -2 M-16 1.5 L-12.8 1.8 M16 -3 L12.5 -2 M16 1.5 L12.8 1.8" stroke="#9a3412" stroke-width="2" stroke-linecap="round" fill="none"/>' +
    '<ellipse cx="0" cy="6.5" rx="9" ry="6.5" fill="#fff7ed"/>' +
    '<path d="M-9.5 -7.5 L-3.5 -5.8 M9.5 -7.5 L3.5 -5.8" stroke="#3a2e1f" stroke-width="2" stroke-linecap="round" fill="none"/>' +
    '<ellipse cx="-6" cy="-1.5" rx="2.2" ry="3" fill="#3a2e1f"/>' +
    '<ellipse cx="6" cy="-1.5" rx="2.2" ry="3" fill="#3a2e1f"/>' +
    '<circle cx="-6.7" cy="-2.6" r="0.8" fill="#ffffff"/>' +
    '<circle cx="5.3" cy="-2.6" r="0.8" fill="#ffffff"/>' +
    '<ellipse cx="-11" cy="3.5" rx="3" ry="1.8" fill="#ffb3c6" opacity="0.8"/>' +
    '<ellipse cx="11" cy="3.5" rx="3" ry="1.8" fill="#ffb3c6" opacity="0.8"/>' +
    '<path d="M-2.5 3.8 L2.5 3.8 L0 6.3 Z" fill="#e56b8c" stroke="#6b4f3a" stroke-width="1.2" stroke-linejoin="round"/>' +
    '<path d="M0 6.3 L0 8.3 M0 8.3 Q-2.8 10.3 -5 8.8 M0 8.3 Q2.8 10.3 5 8.8" stroke="#3a2e1f" stroke-width="1.5" fill="none" stroke-linecap="round"/>' +
    '<path d="M-4.6 8.6 L-2.6 8.6 L-3.6 11.4 Z" fill="#ffffff" stroke="#6b4f3a" stroke-width="1"/>' +
    '<path d="M4.6 8.6 L2.6 8.6 L3.6 11.4 Z" fill="#ffffff" stroke="#6b4f3a" stroke-width="1"/>' +
    '</g>';
}
function hyGoatSVG(x, y) {
  return '<g transform="translate(' + x + ',' + y + ')">' +
    '<ellipse cx="0" cy="15" rx="12.5" ry="3.4" fill="#000000" opacity="0.2"/>' +
    '<path d="M-10 -10 Q-18 -14 -15 -21 Q-12 -25 -8 -22" fill="none" stroke="#a16207" stroke-width="2.8" stroke-linecap="round"/>' +
    '<path d="M10 -10 Q18 -14 15 -21 Q12 -25 8 -22" fill="none" stroke="#a16207" stroke-width="2.8" stroke-linecap="round"/>' +
    '<ellipse cx="-15" cy="-2" rx="4" ry="7" fill="#ffe5d9" stroke="#6b4f3a" stroke-width="1.8" transform="rotate(18 -15 -2)"/>' +
    '<ellipse cx="15" cy="-2" rx="4" ry="7" fill="#ffe5d9" stroke="#6b4f3a" stroke-width="1.8" transform="rotate(-18 15 -2)"/>' +
    '<circle cy="1.6" r="16" fill="#c9a24b"/>' +
    '<circle r="15.5" fill="url(#hyGoatGrad)" stroke="#6b4f3a" stroke-width="2"/>' +
    '<circle cx="-6" cy="-13.5" r="4.5" fill="#ffffff" stroke="#6b4f3a" stroke-width="1.8"/>' +
    '<circle cx="0" cy="-15.5" r="4.8" fill="#ffffff" stroke="#6b4f3a" stroke-width="1.8"/>' +
    '<circle cx="6" cy="-13.5" r="4.5" fill="#ffffff" stroke="#6b4f3a" stroke-width="1.8"/>' +
    '<ellipse cx="-5.5" cy="-7.5" rx="5.4" ry="3" fill="#ffffff" opacity="0.55" transform="rotate(-25 -5.5 -7.5)"/>' +
    '<ellipse cx="-5.5" cy="-1" rx="2.2" ry="3" fill="#3a2e1f"/>' +
    '<ellipse cx="5.5" cy="-1" rx="2.2" ry="3" fill="#3a2e1f"/>' +
    '<circle cx="-6.2" cy="-2.1" r="0.8" fill="#ffffff"/>' +
    '<circle cx="4.8" cy="-2.1" r="0.8" fill="#ffffff"/>' +
    '<ellipse cx="-10.5" cy="3.5" rx="3" ry="1.8" fill="#ffb3c6" opacity="0.8"/>' +
    '<ellipse cx="10.5" cy="3.5" rx="3" ry="1.8" fill="#ffb3c6" opacity="0.8"/>' +
    '<ellipse cx="0" cy="3.2" rx="2" ry="1.4" fill="#ff8fab"/>' +
    '<path d="M-3.5 5.8 Q-1.7 8.3 0 5.8 Q1.7 8.3 3.5 5.8" fill="none" stroke="#3a2e1f" stroke-width="1.6" stroke-linecap="round"/>' +
    '<path d="M-2.5 8.8 L2.5 8.8 L0 14.5 Z" fill="#fde68a" stroke="#a16207" stroke-width="1.5" stroke-linejoin="round"/>' +
    '</g>';
}

/* ---- 游戏状态 ---- */
var hyScreen = "home";
var hyB = null;
var hyTurn = "G";
var hyOver = false;
var hyWinner = null;
var hyToPlace = 20;
var hyCaptured = 0;
var hySel = null;
var hyAiTimer = null;
var hyGen = 0;
var hySfxPlace = 0;
var hySfxMove = 0;
var hySfxEat = 0;
var hySfxWin = 0;
var hySfxLose = 0;
var hySfxClick = 0;

function hyPX(r, c) { return [40 + c * 65, 40 + r * 65]; }
function hyPhase() { return hyToPlace > 0 ? 1 : 2; }

function hySetStatus(t) { hyEl("hy-status").textContent = t; }

function hyBuildBoard() {
  var r, c, i, nr, nc, x, y;
  var linesHtml = "";
  for (r = 0; r < 5; r++) for (c = 0; c < 5; c++) {
    var nbs = neighbors(r, c);
    for (i = 0; i < nbs.length; i++) {
      nr = nbs[i][0]; nc = nbs[i][1];
      if (nr < r || (nr === r && nc < c)) continue;
      var p1 = hyPX(r, c), p2 = hyPX(nr, nc);
      linesHtml += '<line x1="' + p1[0] + '" y1="' + p1[1] + '" x2="' + p2[0] + '" y2="' + p2[1] + '"/>';
    }
  }
  hyEl("hy-lines").innerHTML = linesHtml;
  var dotsHtml = "";
  var hitsHtml = "";
  for (r = 0; r < 5; r++) for (c = 0; c < 5; c++) {
    x = hyPX(r, c)[0]; y = hyPX(r, c)[1];
    dotsHtml += '<circle cx="' + x + '" cy="' + y + '" r="4" class="hy-pt"/>';
    hitsHtml += '<circle cx="' + x + '" cy="' + y + '" r="28" class="hy-hit" data-r="' + r + '" data-c="' + c + '"/>';
  }
  hyEl("hy-dots").innerHTML = dotsHtml;
  hyEl("hy-hits").innerHTML = hitsHtml;
  var hitEls = hyEl("hy-hits").querySelectorAll("circle");
  for (i = 0; i < hitEls.length; i++) {
    (function (el) {
      var rr = parseInt(el.getAttribute("data-r"), 10);
      var cc = parseInt(el.getAttribute("data-c"), 10);
      var handler = function (e) {
        if (e && e.preventDefault) e.preventDefault();
        hyOnPoint(rr, cc);
      };
      el.addEventListener("touchstart", handler);
      el.addEventListener("click", handler);
    })(hitEls[i]);
  }
  var dots = hyEl("hy-place-dots");
  for (i = 0; i < 20; i++) {
    var sp = document.createElement("span");
    sp.className = "hy-pad-dot";
    dots.appendChild(sp);
  }
  var paws = hyEl("hy-cap-paws");
  for (i = 0; i < 5; i++) {
    var pw = document.createElement("span");
    pw.className = "hy-pad-paw";
    paws.appendChild(pw);
  }
}

function hyRender() {
  var marksEl = hyEl("hy-marks");
  var piecesEl = hyEl("hy-pieces");
  var r, c, i, x, y;
  var marksHtml = "";
  if (!hyOver && hyTurn === "G" && hyB) {
    if (hyPhase() === 1) {
      for (r = 0; r < 5; r++) for (c = 0; c < 5; c++) {
        if (hyB[r][c] !== "") continue;
        x = hyPX(r, c)[0]; y = hyPX(r, c)[1];
        marksHtml += '<circle cx="' + x + '" cy="' + y + '" r="12" class="hy-hl"/>';
      }
    } else if (hySel) {
      x = hyPX(hySel[0], hySel[1])[0]; y = hyPX(hySel[0], hySel[1])[1];
      marksHtml += '<circle cx="' + x + '" cy="' + y + '" r="21" class="hy-sel"/>';
      var gm = goatMoves(hyB);
      for (i = 0; i < gm.length; i++) {
        if (gm[i].fr !== hySel[0] || gm[i].fc !== hySel[1]) continue;
        x = hyPX(gm[i].tr, gm[i].tc)[0]; y = hyPX(gm[i].tr, gm[i].tc)[1];
        marksHtml += '<circle cx="' + x + '" cy="' + y + '" r="12" class="hy-hl"/>';
      }
    }
  }
  marksEl.innerHTML = marksHtml;
  var html = "";
  if (hyB) {
    for (r = 0; r < 5; r++) for (c = 0; c < 5; c++) {
      var v = hyB[r][c];
      if (!v) continue;
      x = hyPX(r, c)[0]; y = hyPX(r, c)[1];
      html += (v === "T") ? hyTigerSVG(x, y) : hyGoatSVG(x, y);
    }
  }
  piecesEl.innerHTML = html;
  hyEl("hy-place-num").textContent = hyToPlace;
  hyEl("hy-cap-num").textContent = hyCaptured + " / 5";
  var dots = hyEl("hy-place-dots").children;
  for (i = 0; i < dots.length; i++) {
    dots[i].className = "hy-pad-dot" + (i < hyToPlace ? "" : " off");
  }
  var paws = hyEl("hy-cap-paws").children;
  for (i = 0; i < paws.length; i++) {
    paws[i].className = "hy-pad-paw" + (i < hyCaptured ? " on" : "");
  }
}

function hyNewGame() {
  hyGen++;
  if (hyAiTimer) { clearTimeout(hyAiTimer); hyAiTimer = null; }
  hyB = [];
  var r, c;
  for (r = 0; r < 5; r++) {
    var row = [];
    for (c = 0; c < 5; c++) row.push("");
    hyB.push(row);
  }
  hyB[0][0] = "T"; hyB[0][4] = "T"; hyB[4][0] = "T"; hyB[4][4] = "T";
  hyTurn = "G";
  hyOver = false;
  hyWinner = null;
  hyToPlace = 20;
  hyCaptured = 0;
  hySel = null;
  hyEl("hy-over").className = "hy-over hy-hidden";
  hySetStatus("轮到你：点空位放一只山羊");
  hyRender();
}

function hyEnd(winner, title, text) {
  hyOver = true;
  hyWinner = winner;
  if (winner === "goat") {
    hySfxWin++;
    if (typeof sfx !== "undefined") sfx.win();
  } else {
    hySfxLose++;
    if (typeof sfx !== "undefined") sfx.lose();
  }
  hySetStatus(title);
  var t = hyEl("hy-over-title");
  t.textContent = title;
  t.className = "hy-over-title" + (winner === "goat" ? "" : " lose");
  hyEl("hy-over-text").textContent = text;
  hyEl("hy-over").className = "hy-over";
  hyRender();
}

function hyOnPoint(r, c) {
  if (hyOver || hyTurn !== "G" || hyScreen !== "game" || !hyB) return;
  if (hyPhase() === 1) {
    if (hyB[r][c] !== "") {
      if (typeof sfx !== "undefined") sfx.error();
      return;
    }
    hyB[r][c] = "G";
    hyToPlace--;
    hySfxPlace++;
    if (typeof sfx !== "undefined") sfx.place();
    hyAfterGoat();
    return;
  }
  if (hyB[r][c] === "G") {
    hySel = [r, c];
    hySfxClick++;
    if (typeof sfx !== "undefined") sfx.select();
    hyRender();
    return;
  }
  if (hySel && hyB[r][c] === "") {
    var gm = goatMoves(hyB);
    var ok = false;
    for (var i = 0; i < gm.length; i++) {
      if (gm[i].fr === hySel[0] && gm[i].fc === hySel[1] && gm[i].tr === r && gm[i].tc === c) { ok = true; break; }
    }
    if (!ok) {
      if (typeof sfx !== "undefined") sfx.error();
      return;
    }
    hyB[hySel[0]][hySel[1]] = "";
    hyB[r][c] = "G";
    hySel = null;
    hySfxMove++;
    if (typeof sfx !== "undefined") sfx.move();
    hyAfterGoat();
    return;
  }
  hySel = null;
  hyRender();
}

function hyAfterGoat() {
  if (tigerMoves(hyB).length === 0) {
    hyEnd("goat", "山羊获胜！", "四只老虎全被困住了，无路可走。山羊们守住了草原！");
    return;
  }
  hyTurn = "T";
  hySetStatus("老虎行动中…");
  hyRender();
  var gen = hyGen;
  hyAiTimer = setTimeout(function () {
    if (gen === hyGen) hyAiTurn();
  }, 650);
}

function hyAiTurn() {
  if (hyOver || !hyB) return;
  var m = aiTigerMove(hyB);
  if (!m) {
    hyEnd("goat", "山羊获胜！", "老虎无路可走，山羊们守住了草原！");
    return;
  }
  hyB[m.fr][m.fc] = "";
  hyB[m.tr][m.tc] = "T";
  var ate = false;
  if (m.cap) {
    hyB[m.cap[0]][m.cap[1]] = "";
    hyCaptured++;
    ate = true;
    hySfxEat++;
    if (typeof sfx !== "undefined") sfx.eat();
  } else {
    hySfxMove++;
    if (typeof sfx !== "undefined") sfx.move();
  }
  if (hyCaptured >= 5) {
    hyEnd("tiger", "老虎获胜", "老虎已经吃掉 5 只山羊。换个围法再来一局吧！");
    return;
  }
  if (hyPhase() === 2 && goatMoves(hyB).length === 0) {
    hyEnd("tiger", "老虎获胜", "山羊无处可走。换个围法再来一局吧！");
    return;
  }
  hyTurn = "G";
  if (ate) {
    hySetStatus("一只山羊被吃掉了！轮到你" + (hyPhase() === 1 ? "放羊" : "走羊"));
  } else {
    hySetStatus(hyPhase() === 1 ? "轮到你：点空位放一只山羊" : "轮到你：点一只山羊，再点相邻空位移动");
  }
  hyRender();
}

function hyShowHome() {
  hyScreen = "home";
  hyGen++;
  if (hyAiTimer) { clearTimeout(hyAiTimer); hyAiTimer = null; }
  hyEl("hy-game").className = "hy-hidden";
  hyEl("hy-home").className = "";
}

function hyShowGame() {
  hyScreen = "game";
  hyEl("hy-home").className = "hy-hidden";
  hyEl("hy-game").className = "";
  hyNewGame();
}

/* ---- 事件绑定 ---- */
hyEl("hy-start").addEventListener("click", function () {
  hyCtx();
  hySfxClick++;
  if (typeof sfx !== "undefined") sfx.click();
  hyShowGame();
});
hyEl("hy-new").addEventListener("click", function () {
  hySfxClick++;
  if (typeof sfx !== "undefined") sfx.click();
  hyNewGame();
});
hyEl("hy-again").addEventListener("click", function () {
  hySfxClick++;
  if (typeof sfx !== "undefined") sfx.click();
  hyNewGame();
});
hyEl("hy-back").addEventListener("click", function () {
  hySfxClick++;
  if (typeof sfx !== "undefined") sfx.click();
  hyShowHome();
});
hyEl("hy-over-home").addEventListener("click", function () {
  hySfxClick++;
  if (typeof sfx !== "undefined") sfx.click();
  hyShowHome();
});
function hyOpenHelp() {
  hySfxClick++;
  if (typeof sfx !== "undefined") sfx.click();
  hyEl("hy-mask").className = "hy-mask open";
}
hyEl("hy-help").addEventListener("click", hyOpenHelp);
hyEl("hy-help-home").addEventListener("click", hyOpenHelp);
hyEl("hy-help-close").addEventListener("click", function () {
  hyEl("hy-mask").className = "hy-mask";
});
hyEl("hy-mask").addEventListener("click", function (e) {
  if (e.target === hyEl("hy-mask")) hyEl("hy-mask").className = "hy-mask";
});

/* ---- 首页棋子展示 ---- */
hyEl("hy-home-tiger").innerHTML = '<svg viewBox="-24 -24 48 48"><defs><radialGradient id="hyTigerGrad" cx="35%" cy="30%" r="85%"><stop offset="0%" stop-color="#ffe3b3"/><stop offset="55%" stop-color="#fb923c"/><stop offset="100%" stop-color="#ea580c"/></radialGradient><radialGradient id="hyGoatGrad" cx="35%" cy="30%" r="85%"><stop offset="0%" stop-color="#ffffff"/><stop offset="55%" stop-color="#fff7e0"/><stop offset="100%" stop-color="#eed9a4"/></radialGradient><linearGradient id="hyWoodGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#f6e0ae"/><stop offset="55%" stop-color="#e9cd96"/><stop offset="100%" stop-color="#dcb87c"/></linearGradient></defs>' + hyTigerSVG(0, 0) + '</svg>';
hyEl("hy-home-goat").innerHTML = '<svg viewBox="-24 -24 48 48"><defs><radialGradient id="hyTigerGrad" cx="35%" cy="30%" r="85%"><stop offset="0%" stop-color="#ffe3b3"/><stop offset="55%" stop-color="#fb923c"/><stop offset="100%" stop-color="#ea580c"/></radialGradient><radialGradient id="hyGoatGrad" cx="35%" cy="30%" r="85%"><stop offset="0%" stop-color="#ffffff"/><stop offset="55%" stop-color="#fff7e0"/><stop offset="100%" stop-color="#eed9a4"/></radialGradient><linearGradient id="hyWoodGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#f6e0ae"/><stop offset="55%" stop-color="#e9cd96"/><stop offset="100%" stop-color="#dcb87c"/></linearGradient></defs>' + hyGoatSVG(0, 0) + '</svg>';

/* ---- 测试桥 ---- */
var HY = {
  getState: function () {
    var bs = "";
    if (hyB) {
      for (var r = 0; r < 5; r++) for (var c = 0; c < 5; c++) {
        bs += hyB[r][c] === "" ? "." : hyB[r][c];
      }
    }
    return {
      screen: hyScreen,
      phase: hyPhase(),
      toPlace: hyToPlace,
      captured: hyCaptured,
      turn: hyTurn,
      over: hyOver,
      winner: hyWinner,
      board: bs,
      sel: hySel,
      helpVisible: hyEl("hy-mask").className.indexOf("open") >= 0,
      sfxPlace: hySfxPlace,
      sfxMove: hySfxMove,
      sfxEat: hySfxEat,
      sfxWin: hySfxWin,
      sfxLose: hySfxLose,
      sfxClick: hySfxClick,
      tigerMoveCount: hyB ? tigerMoves(hyB).length : -1,
      goatMoveCount: hyB ? goatMoves(hyB).length : -1
    };
  },
  pointPos: function (r, c) {
    var h = hyEl("hy-hits").querySelector('circle[data-r="' + r + '"][data-c="' + c + '"]');
    if (!h) return null;
    var rect = h.getBoundingClientRect();
    return { x: Math.round(rect.left + rect.width / 2), y: Math.round(rect.top + rect.height / 2) };
  },
  tap: function (r, c) { hyOnPoint(r, c); return HY.getState(); },
  aiStep: function () {
    if (hyAiTimer) { clearTimeout(hyAiTimer); hyAiTimer = null; }
    if (hyTurn === "T" && !hyOver) hyAiTurn();
    return HY.getState();
  },
  setBoard: function (rows, toPlace, captured) {
    hyGen++;
    if (hyAiTimer) { clearTimeout(hyAiTimer); hyAiTimer = null; }
    hyB = [];
    for (var r = 0; r < 5; r++) {
      var row = [];
      for (var c = 0; c < 5; c++) {
        var ch = rows[r].charAt(c);
        row.push(ch === "." ? "" : ch);
      }
      hyB.push(row);
    }
    hyToPlace = toPlace;
    hyCaptured = captured;
    hyTurn = "G";
    hyOver = false;
    hyWinner = null;
    hySel = null;
    hyEl("hy-over").className = "hy-over hy-hidden";
    hySetStatus(hyPhase() === 1 ? "轮到你：点空位放一只山羊" : "轮到你：点一只山羊，再点相邻空位移动");
    hyRender();
    return HY.getState();
  },
  newGame: function () { hyNewGame(); return HY.getState(); }
};

hyBuildBoard();
hyNewGame();
