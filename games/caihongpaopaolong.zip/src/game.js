(function () {
  "use strict";

  const COLORS = ["#ff5d73", "#4da3ff", "#3ddc84", "#ffd93b", "#b388ff", "#ff9f43"];
  const LEVELS = {
    easy: { colors: 4, rows: 4, speed: 6 },
    medium: { colors: 5, rows: 5, speed: 8 },
    hard: { colors: 6, rows: 6, speed: 10 },
  };

  const COLS = 8;
  const R = 18;
  const ROW_H = R * 1.75;

  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");

  let state = {
    level: "easy",
    grid: [],
    score: 0,
    aimAngle: -Math.PI / 2,
    current: 0,
    next: 0,
    flying: null,
    running: false,
    gameOver: false,
    paused: false,
    particles: [],
    falling: [],
    frame: 0,
    shots: 0,
    best: loadBest(),
  };

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];

  function cfg() {
    return LEVELS[state.level];
  }

  function colsInRow(row) {
    return row % 2 === 0 ? COLS : COLS - 1;
  }

  function cellCenter(row, col) {
    const odd = row % 2 === 1;
    const x = R + col * (R * 2) + (odd ? R : 0) + 56;
    const y = R + row * ROW_H + 8;
    return { x, y };
  }

  function randomColor() {
    return Math.floor(Math.random() * cfg().colors);
  }

  function initGrid() {
    state.grid = [];
    const rows = cfg().rows;
    for (let r = 0; r < rows; r++) {
      const row = [];
      const n = colsInRow(r);
      for (let c = 0; c < n; c++) row.push(randomColor());
      state.grid.push(row);
    }
  }

  function neighbors(row, col) {
    const odd = row % 2 === 1;
    const deltas = odd
      ? [[0, -1], [0, 1], [-1, 0], [-1, 1], [1, 0], [1, 1]]
      : [[0, -1], [0, 1], [-1, -1], [-1, 0], [1, -1], [1, 0]];
    const out = [];
    for (const [dr, dc] of deltas) {
      const rr = row + dr;
      const cc = col + dc;
      if (rr >= 0 && rr < state.grid.length && cc >= 0 && cc < state.grid[rr].length && state.grid[rr][cc] !== null) {
        out.push([rr, cc]);
      }
    }
    return out;
  }

  function findCluster(row, col) {
    const color = state.grid[row][col];
    if (color === null) return [];
    const visited = new Set();
    const stack = [[row, col]];
    const cluster = [];
    while (stack.length) {
      const [r, c] = stack.pop();
      const key = r + "," + c;
      if (visited.has(key)) continue;
      visited.add(key);
      if (state.grid[r][c] !== color) continue;
      cluster.push([r, c]);
      neighbors(r, c).forEach(([nr, nc]) => stack.push([nr, nc]));
    }
    return cluster;
  }

  function connectedToCeiling() {
    const visited = new Set();
    const stack = [];
    if (!state.grid.length) return visited;
    for (let c = 0; c < state.grid[0].length; c++) {
      if (state.grid[0][c] !== null) stack.push([0, c]);
    }
    while (stack.length) {
      const [r, c] = stack.pop();
      const key = r + "," + c;
      if (visited.has(key)) continue;
      visited.add(key);
      neighbors(r, c).forEach(([nr, nc]) => stack.push([nr, nc]));
    }
    return visited;
  }

  function dropOrphans() {
    const connected = connectedToCeiling();
    let dropped = 0;
    for (let r = 0; r < state.grid.length; r++) {
      for (let c = 0; c < state.grid[r].length; c++) {
        if (state.grid[r][c] !== null && !connected.has(r + "," + c)) {
          const p = cellCenter(r, c);
          state.falling.push({ x: p.x, y: p.y, vy: 0, color: state.grid[r][c] });
          state.grid[r][c] = null;
          dropped++;
        }
      }
    }
    while (state.grid.length && state.grid[state.grid.length - 1].every((v) => v === null)) {
      state.grid.pop();
    }
    return dropped;
  }

  function snapBubble(x, y, color) {
    let best = null;
    let bestDist = Infinity;
    const maxRows = Math.max(state.grid.length + 1, cfg().rows + 2);
    for (let r = 0; r < maxRows; r++) {
      const n = colsInRow(r);
      if (!state.grid[r]) state.grid[r] = Array(n).fill(null);
      while (state.grid[r].length < n) state.grid[r].push(null);
      for (let c = 0; c < n; c++) {
        if (state.grid[r][c] !== null) continue;
        const p = cellCenter(r, c);
        const d = Math.hypot(p.x - x, p.y - y);
        if (d < bestDist) {
          bestDist = d;
          best = { r, c };
        }
      }
    }
    if (!best) return;
    const n = colsInRow(best.r);
    if (!state.grid[best.r]) state.grid[best.r] = Array(n).fill(null);
    state.grid[best.r][best.c] = color;
    const cluster = findCluster(best.r, best.c);
    if (cluster.length >= 3) {
      cluster.forEach(([r, c]) => {
        const p = cellCenter(r, c);
        spawnPop(p.x, p.y, COLORS[state.grid[r][c]]);
        state.grid[r][c] = null;
      });
      state.score += cluster.length * 10;
      if (typeof sfx !== 'undefined') { sfx.pop(); }
      const dropped = dropOrphans();
      state.score += dropped * 15;
      if (dropped > 0 && typeof sfx !== 'undefined') { sfx.drop(); }
    } else if (typeof sfx !== 'undefined') { sfx.stick(); }
    updateHud();
    checkEnd();
  }

  function checkEnd() {
    let any = false;
    let tooLow = false;
    const dangerY = canvas.height - 80;
    for (let r = 0; r < state.grid.length; r++) {
      for (let c = 0; c < state.grid[r].length; c++) {
        if (state.grid[r][c] !== null) {
          any = true;
          if (cellCenter(r, c).y + R > dangerY) tooLow = true;
        }
      }
    }
    if (!any) {
      endGame(true);
    } else if (tooLow) {
      endGame(false);
    }
  }

  function endGame(won) {
    if (state.gameOver) return;
    state.gameOver = true;
    state.running = false;
    state.flying = null;
    state.paused = false;
    $("#pauseVeil").classList.add("hidden");
    $("#pauseBtn").textContent = "暂停";
    const isRecord = state.score > state.best;
    if (isRecord) { state.best = state.score; saveBest(); }
    if (won) {
      $("#resultTitle").textContent = "全部清空！";
      if (typeof sfx !== 'undefined') { sfx.clear(); }
    } else {
      $("#resultTitle").textContent = "泡泡越线了";
      if (typeof sfx !== 'undefined') { sfx.over(); }
    }
    $("#resultMsg").textContent = "得分：" + state.score;
    $("#resultBest").textContent = "最高分：" + state.best;
    $("#resultRecord").style.display = isRecord ? "block" : "none";
    $("#resultOverlay").classList.remove("hidden");
    updateHud();
    updateBestDisplays();
  }

  function shoot() {
    if (!state.running || state.flying || state.gameOver || state.paused) return;
    state.shots++;
    if (typeof sfx !== 'undefined') { sfx.shoot(); }
    const speed = cfg().speed;
    state.flying = {
      x: canvas.width / 2,
      y: canvas.height - 40,
      vx: Math.cos(state.aimAngle) * speed,
      vy: Math.sin(state.aimAngle) * speed,
      color: state.current,
    };
    state.current = state.next;
    state.next = randomColor();
  }

  function update() {
    if (!state.flying) return;
    const b = state.flying;
    b.x += b.vx;
    b.y += b.vy;
    if (b.x - R < 0) {
      b.x = R;
      b.vx *= -1;
    }
    if (b.x + R > canvas.width) {
      b.x = canvas.width - R;
      b.vx *= -1;
    }
    if (b.y - R <= 0) {
      snapBubble(b.x, R, b.color);
      state.flying = null;
      return;
    }
    for (let r = 0; r < state.grid.length; r++) {
      for (let c = 0; c < state.grid[r].length; c++) {
        if (state.grid[r][c] === null) continue;
        const p = cellCenter(r, c);
        if (Math.hypot(p.x - b.x, p.y - b.y) < R * 1.85) {
          snapBubble(b.x, b.y, b.color);
          state.flying = null;
          return;
        }
      }
    }
  }

  function drawBubble(x, y, colorIndex) {
    const base = COLORS[colorIndex];
    const g = ctx.createRadialGradient(x - 6, y - 7, 2, x, y, R - 1);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(0.35, base);
    g.addColorStop(1, base);
    ctx.beginPath();
    ctx.arc(x, y, R - 1, 0, Math.PI * 2);
    ctx.fillStyle = g;
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.55)";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(x - 6, y - 7, 4.5, 3, -0.6, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.fill();
  }

  function draw() {
    // 梦幻底：竖向渐变 + 糖果星点
    const bgGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    bgGrad.addColorStop(0, "#1a0b2e");
    bgGrad.addColorStop(0.5, "#2d1b4e");
    bgGrad.addColorStop(1, "#0b1e3a");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    SPARKS.forEach((s) => {
      const tw = 0.3 + 0.3 * Math.sin(state.frame * 0.05 + s.ph);
      ctx.fillStyle = "rgba(249,168,212," + tw.toFixed(2) + ")";
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.s, 0, Math.PI * 2);
      ctx.fill();
    });

    // 危险线
    ctx.strokeStyle = "rgba(255,93,115,0.65)";
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(0, canvas.height - 80);
    ctx.lineTo(canvas.width, canvas.height - 80);
    ctx.stroke();
    ctx.setLineDash([]);

    // 棋盘泡泡
    for (let r = 0; r < state.grid.length; r++) {
      for (let c = 0; c < state.grid[r].length; c++) {
        if (state.grid[r][c] === null) continue;
        const p = cellCenter(r, c);
        drawBubble(p.x, p.y, state.grid[r][c]);
      }
    }

    // 掉落中的悬空泡泡
    state.falling.forEach((f) => drawBubble(f.x, f.y, f.color));

    // 瞄准虚线（带墙面反弹预览）
    if (!state.flying && state.running) {
      const sx = canvas.width / 2;
      const sy = canvas.height - 40;
      ctx.strokeStyle = "rgba(255,255,255,0.55)";
      ctx.lineWidth = 2;
      ctx.setLineDash([2, 7]);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      let ax = sx;
      let ay = sy;
      let vx = Math.cos(state.aimAngle);
      let vy = Math.sin(state.aimAngle);
      for (let i = 0; i < 80; i++) {
        ax += vx * 8;
        ay += vy * 8;
        if (ax < R || ax > canvas.width - R) vx *= -1;
        if (ay < 0) break;
        ctx.lineTo(ax, ay);
      }
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // 发射台 + 当前泡泡
    drawLauncher();
    if (state.flying) drawBubble(state.flying.x, state.flying.y, state.flying.color);
    else if (state.running) drawBubble(canvas.width / 2, canvas.height - 40, state.current);

    // 下一个预览
    ctx.fillStyle = "#c4b5fd";
    ctx.font = "12px sans-serif";
    ctx.fillText("下一个", 12, canvas.height - 12);
    drawBubble(68, canvas.height - 28, state.next);

    // 消除粒子
    state.particles.forEach((p) => {
      ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
  }

  let loopRunning = false;
  function loop() {
    if (!state.running) { loopRunning = false; return; }
    if (!state.paused) {
      state.frame++;
      update();
      updateFx();
    }
    draw();
    requestAnimationFrame(loop);
  }

  function setAimFromEvent(e) {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    const x = (clientX - rect.left) * scaleX;
    const y = (clientY - rect.top) * scaleY;
    const sx = canvas.width / 2;
    const sy = canvas.height - 40;
    let angle = Math.atan2(y - sy, x - sx);
    const minA = -Math.PI + 0.2;
    const maxA = -0.2;
    if (angle > 0) angle = -0.2;
    state.aimAngle = Math.max(minA, Math.min(maxA, angle));
  }

  function startNewGame() {
    initGrid();
    state.score = 0;
    state.current = randomColor();
    state.next = randomColor();
    state.flying = null;
    state.gameOver = false;
    state.running = true;
    state.paused = false;
    state.particles = [];
    state.falling = [];
    state.shots = 0;
    state.aimAngle = -Math.PI / 2;
    updateHud();
    $("#resultOverlay").classList.add("hidden");
    $("#pauseVeil").classList.add("hidden");
    $("#pauseBtn").textContent = "暂停";
    draw();
    if (!loopRunning) { loopRunning = true; requestAnimationFrame(loop); }
  }

  function startGame(level) {
    state.level = level;
    $("#levelScreen").classList.add("hidden");
    $("#gameScreen").classList.remove("hidden");
    $("#levelBadge").textContent = level === "easy" ? "简单" : level === "medium" ? "普通" : "困难";
    startNewGame();
  }

  function goToLevelScreen() {
    state.running = false;
    state.gameOver = false;
    state.paused = false;
    $("#gameScreen").classList.add("hidden");
    $("#resultOverlay").classList.add("hidden");
    $("#pauseVeil").classList.add("hidden");
    $("#pauseBtn").textContent = "暂停";
    $("#levelScreen").classList.remove("hidden");
    updateBestDisplays();
  }

  document.addEventListener("DOMContentLoaded", () => {
    $$(".level-btn").forEach((btn) => btn.addEventListener("click", () => startGame(btn.dataset.level)));
    $("#newGameBtn").addEventListener("click", startNewGame);
    $("#changeLevelBtn").addEventListener("click", goToLevelScreen);
    $("#playAgainBtn").addEventListener("click", startNewGame);
    $("#changeLevelFromResultBtn").addEventListener("click", goToLevelScreen);
    $("#fireBtn").addEventListener("click", shoot);
    canvas.addEventListener("mousemove", setAimFromEvent);
    canvas.addEventListener("touchmove", (e) => {
      e.preventDefault();
      setAimFromEvent(e);
    }, { passive: false });
    canvas.addEventListener("click", shoot);
    canvas.addEventListener("touchend", (e) => {
      e.preventDefault();
      shoot();
    });
    $("#helpBtnLevel").addEventListener("click", () => $("#helpOverlay").classList.remove("hidden"));
    $("#helpBtnGame").addEventListener("click", () => $("#helpOverlay").classList.remove("hidden"));
    $("#helpClose").addEventListener("click", () => $("#helpOverlay").classList.add("hidden"));
    $("#helpOverlay").addEventListener("click", (e) => {
      if (e.target.id === "helpOverlay") $("#helpOverlay").classList.add("hidden");
    });
  });
  // ---------- 改编版新增：最高分 / 粒子 / 发射台 / 暂停 ----------
  const SPARKS = [];
  for (let i = 0; i < 60; i++) {
    SPARKS.push({ x: (i * 97 + 31) % 400, y: (i * 61 + 17) % 560, s: i % 5 === 0 ? 2 : 1.2, ph: i * 0.7 });
  }

  function spawnPop(x, y, color) {
    for (let i = 0; i < 10; i++) {
      const ang = (Math.PI * 2 * i) / 10 + Math.random() * 0.6;
      const spd = 0.6 + Math.random() * 1.8;
      state.particles.push({
        x: x, y: y,
        vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd - 0.4,
        life: 22 + Math.floor(Math.random() * 14), maxLife: 36,
        color: color, size: 2 + Math.random() * 2,
      });
    }
  }

  function updateFx() {
    state.particles = state.particles.filter((p) => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.05;
      p.life--;
      return p.life > 0;
    });
    state.falling = state.falling.filter((f) => {
      f.vy += 0.35;
      f.y += f.vy;
      return f.y - R < canvas.height;
    });
  }

  function bubblesLeft() {
    let n = 0;
    for (let r = 0; r < state.grid.length; r++) {
      for (let c = 0; c < state.grid[r].length; c++) {
        if (state.grid[r][c] !== null) n++;
      }
    }
    return n;
  }

  function updateHud() {
    $("#scoreEl").textContent = state.score;
    $("#leftEl").textContent = bubblesLeft();
    $("#bestEl").textContent = state.best;
  }

  function loadBest() {
    try {
      const v = parseInt(localStorage.getItem('bubbleshooter_best'), 10);
      if (!isNaN(v) && v > 0) return v;
    } catch (e) {}
    return 0;
  }

  function saveBest() {
    try { localStorage.setItem('bubbleshooter_best', String(state.best)); } catch (e) {}
  }

  function updateBestDisplays() {
    const el = document.getElementById('bestOnLevel');
    if (el) el.textContent = state.best;
  }

  function drawLauncher() {
    const cx = canvas.width / 2;
    const baseY = canvas.height - 40;
    // 炮管（随瞄准角转动）
    ctx.save();
    ctx.translate(cx, baseY);
    ctx.rotate(state.aimAngle + Math.PI / 2);
    ctx.fillStyle = "#a78bfa";
    ctx.fillRect(-4, -26, 8, 22);
    ctx.fillStyle = "#f9a8d4";
    ctx.fillRect(-5, -28, 10, 5);
    ctx.restore();
    // 底座
    ctx.beginPath();
    ctx.ellipse(cx, baseY + 16, 30, 10, 0, 0, Math.PI * 2);
    ctx.fillStyle = "#7c3aed";
    ctx.fill();
    ctx.strokeStyle = "#c4b5fd";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, baseY, 7, 0, Math.PI * 2);
    ctx.fillStyle = "#f9a8d4";
    ctx.fill();
  }

  function togglePause() {
    if (!state.running || state.gameOver) return;
    state.paused = !state.paused;
    $("#pauseBtn").textContent = state.paused ? "继续" : "暂停";
    if (state.paused) $("#pauseVeil").classList.remove("hidden");
    else $("#pauseVeil").classList.add("hidden");
  }

  $("#pauseBtn").addEventListener("click", togglePause);
  $("#resumeBtn").addEventListener("click", togglePause);
  updateBestDisplays();

  /* ======================================================================
   * Test bridge (window.BS)
   * ==================================================================== */
  window.BS = {
    getState: function () {
      return {
        phase: state.gameOver ? 'over' : (state.paused ? 'paused' : (state.running ? 'playing' : 'level')),
        level: state.level, score: state.score, best: state.best,
        bubblesLeft: bubblesLeft(), flying: !!state.flying, shots: state.shots,
        paused: state.paused, running: state.running, gameOver: state.gameOver,
        aimAngle: state.aimAngle, current: state.current, next: state.next,
        gridRows: state.grid.length, colors: cfg().colors, rows: cfg().rows
      };
    },
    start: function (level) { startGame(level || state.level); return window.BS.getState(); },
    shoot: function () { shoot(); return window.BS.getState(); },
    setAim: function (angle) { state.aimAngle = angle; return window.BS.getState(); },
    togglePause: function () { togglePause(); return window.BS.getState(); },
    setupCluster: function () {
      state.grid = [];
      for (let r = 0; r < 4; r++) state.grid.push(Array(colsInRow(r)).fill(null));
      state.grid[0][0] = 1;
      state.grid[0][7] = 2;
      state.grid[0][3] = 0;
      state.grid[0][4] = 0;
      state.current = 0;
      state.next = 1;
      state.aimAngle = -Math.PI / 2;
      state.score = 0;
      state.flying = null;
      state.gameOver = false;
      state.running = true;
      state.paused = false;
      updateHud();
      draw();
      return window.BS.getState();
    },
    clearBoard: function () {
      for (let r = 0; r < state.grid.length; r++) {
        for (let c = 0; c < state.grid[r].length; c++) state.grid[r][c] = null;
      }
      checkEnd();
      return window.BS.getState();
    },
    fillDanger: function () {
      state.grid = [];
      for (let r = 0; r < 15; r++) {
        const row = [];
        for (let c = 0; c < colsInRow(r); c++) row.push((r + c) % 3);
        state.grid.push(row);
      }
      checkEnd();
      return window.BS.getState();
    },
    reloadBest: function () { state.best = loadBest(); updateHud(); updateBestDisplays(); return window.BS.getState(); }
  };
})();
