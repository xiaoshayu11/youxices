(function () {
  'use strict';

  var splash = document.getElementById('splash');
  var canvas = document.getElementById('screen');

  function fail(msg) {
    if (!splash) { return; }
    splash.classList.remove('hidden');
    splash.classList.add('error');
    splash.innerHTML = '';
    var t = document.createElement('div');
    t.className = 'splash-title';
    t.textContent = 'ERROR';
    var s = document.createElement('div');
    s.className = 'splash-sub';
    s.textContent = msg;
    splash.appendChild(t);
    splash.appendChild(s);
  }

  /* --- audio can only start after a real user gesture ------------------- */
  function unlockAudio() {
    try {
      if (typeof AUDIO !== 'undefined' && AUDIO.unlock) { AUDIO.unlock(); }
    } catch (e) { /* audio is strictly optional */ }
  }
  window.addEventListener('keydown', unlockAudio);
  window.addEventListener('pointerdown', unlockAudio);
  window.addEventListener('touchstart', unlockAudio, { passive: true });

  /* --- the page should never scroll or bounce on a game surface --------- */
  window.addEventListener('touchmove', function (e) {
    if (e.target === canvas) { e.preventDefault(); }
  }, { passive: false });
  canvas.addEventListener('contextmenu', function (e) { e.preventDefault(); });

  function boot() {
    try {
      if (typeof GAME === 'undefined' || !GAME.boot) {
        fail('GAME NOT LOADED');
        return;
      }
      GAME.boot(canvas);
      canvas.focus();
    } catch (e) {
      fail(String((e && e.message) || e));
      if (window.console && console.error) { console.error(e); }
    }
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(boot, 0);
  } else {
    window.addEventListener('DOMContentLoaded', boot);
  }
})();
/* --- on-screen touch pad (mobile): arrows + drift button --------------- */
(function bindTouchPad() {
  function bind() {
    var pad = document.querySelector('.touch-pad');
    if (!pad || typeof INPUT === 'undefined' || !INPUT.setButton) { return; }
    var btns = pad.querySelectorAll('[data-btn]');
    var driftTimer = null, driftStart = 0;
    var DRIFT_MIN_HOLD = 350;
    function set(action, down) {
      if (action === 'handbrake') {
        if (down) {
          if (driftTimer) { clearTimeout(driftTimer); driftTimer = null; }
          driftStart = Date.now();
          INPUT.setButton('handbrake', true);
        } else {
          var held = Date.now() - driftStart;
          if (held >= DRIFT_MIN_HOLD) {
            INPUT.setButton('handbrake', false);
          } else {
            driftTimer = setTimeout(function () {
              driftTimer = null;
              INPUT.setButton('handbrake', false);
            }, DRIFT_MIN_HOLD - held);
          }
        }
        return;
      }
      INPUT.setButton(action, down);
    }
    function press(btn, down) {
      var a = btn.getAttribute('data-btn');
      if (!a) { return; }
      if (down) { btn.classList.add('pressed'); } else { btn.classList.remove('pressed'); }
      set(a, down);
    }
    function attach(btn) {
      btn.addEventListener('touchstart', function (e) {
        e.preventDefault();
        press(btn, true);
      }, { passive: false });
      btn.addEventListener('touchend', function (e) {
        e.preventDefault();
        press(btn, false);
      }, { passive: false });
      btn.addEventListener('touchcancel', function () { press(btn, false); });
      btn.addEventListener('mousedown', function (e) {
        e.preventDefault();
        press(btn, true);
      });
      btn.addEventListener('mouseup', function () { press(btn, false); });
      btn.addEventListener('mouseleave', function () { press(btn, false); });
      btn.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    }
    for (var i = 0; i < btns.length; i++) { attach(btns[i]); }
  }
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(bind, 0);
  } else {
    document.addEventListener('DOMContentLoaded', bind);
  }
})();
