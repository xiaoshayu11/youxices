/* 一杆进洞（Mini Golf）：按住球往回拖松手击球，5 个洞总杆数越少越好。
   物理（摩擦 0.985 / 沙坑 0.9 / 墙反弹 0.8 / 进洞判定）沿用上游 Pixel-Arcade minigolf.js，仅汉化与换主题。
   兼容修复：上游 ctx.roundRect 在旧 WebView 不可用，改为手写圆角路径；上游只用 pointer 事件，
   这里补 touch/mouse 事件并在拖拽时 preventDefault 防滚动。Best 改内存变量。 */
var MG_HOLES = [{"start": {"x": 50, "y": 200}, "hole": {"x": 330, "y": 200}, "walls": [{"x": 180, "y": 60, "w": 12, "h": 130}], "sands": []}, {"start": {"x": 50, "y": 340}, "hole": {"x": 330, "y": 70}, "walls": [{"x": 150, "y": 150, "w": 12, "h": 130}, {"x": 260, "y": 150, "w": 12, "h": 130}], "sands": [{"x": 170, "y": 290, "w": 80, "h": 60}]}, {"start": {"x": 50, "y": 200}, "hole": {"x": 190, "y": 60}, "walls": [{"x": 100, "y": 120, "w": 180, "h": 12}], "sands": [{"x": 120, "y": 240, "w": 70, "h": 50}]}, {"start": {"x": 340, "y": 350}, "hole": {"x": 40, "y": 50}, "walls": [{"x": 120, "y": 120, "w": 12, "h": 160}, {"x": 240, "y": 220, "w": 12, "h": 140}], "sands": [{"x": 150, "y": 60, "w": 90, "h": 40}]}, {"start": {"x": 60, "y": 60}, "hole": {"x": 320, "y": 340}, "walls": [{"x": 150, "y": 40, "w": 12, "h": 180}, {"x": 250, "y": 180, "w": 12, "h": 180}, {"x": 40, "y": 220, "w": 180, "h": 12}], "sands": [{"x": 180, "y": 130, "w": 60, "h": 60}]}];
var MG_W = 380, MG_H = 400;
var MG_PAR = 2;

var mgLevel = 0;
var mgStrokes = 0;
var mgTotal = 0;
var mgBest = 0;
var mgBall = {x: 50, y: 200, vx: 0, vy: 0, moving: false};
var mgDrag = null;
var mgWon = false;
var mgMsg = null;
var mgTimer = null;
var mgRaf = null;
var mgSfxClicks = 0;
var mgSfxWins = 0;

// ---- WebAudio 合成音效（无音频文件） ----
var mgAudioCtx = null;
function mgAudio() {
  if (typeof AudioContext === "undefined" && typeof webkitAudioContext === "undefined") return null;
  if (!mgAudioCtx) {
    var AC = (typeof AudioContext !== "undefined") ? AudioContext : webkitAudioContext;
    try { mgAudioCtx = new AC(); } catch (e) { return null; }
  }
  if (mgAudioCtx.state === "suspended") { mgAudioCtx.resume(); }
  return mgAudioCtx;
}
function mgTone(freq, dur, delay, type, gain) {
  var ctx = mgAudio();
  if (!ctx) return;
  var t = ctx.currentTime + (delay || 0);
  var osc = ctx.createOscillator();
  var g = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(gain || 0.12, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}
var sfx = {
  click: function () { mgSfxClicks++; mgTone(1200, 0.05, 0, "square", 0.04); },
  putt: function () { mgSfxClicks++; mgTone(700, 0.07, 0, "triangle", 0.14); mgTone(350, 0.09, 0.03, "sine", 0.08); },
  bounce: function () { mgSfxClicks++; mgTone(500, 0.05, 0, "square", 0.05); },
  win: function () { mgSfxWins++; mgTone(523, 0.14, 0, "sine", 0.12); mgTone(659, 0.14, 0.12, "sine", 0.12); mgTone(784, 0.26, 0.24, "sine", 0.12); }
};

function mgEl(id) { return document.getElementById(id); }
var mgCanvas = mgEl("mg-canvas");
var mgCtx = mgCanvas.getContext("2d");

function mgSetStatus(text, cls) {
  var el = mgEl("mg-status");
  el.textContent = text;
  el.className = "status " + cls;
}

function mgUpdateHud() {
  mgEl("mg-hole").textContent = (mgLevel + 1) + " / " + MG_HOLES.length;
  mgEl("mg-strokes").textContent = mgStrokes;
  mgEl("mg-total").textContent = mgTotal;
}

function mgLoadHole(i) {
  if (mgTimer) { clearTimeout(mgTimer); mgTimer = null; }
  mgLevel = i;
  mgStrokes = 0;
  mgBall = {x: MG_HOLES[i].start.x, y: MG_HOLES[i].start.y, vx: 0, vy: 0, moving: false};
  mgDrag = null;
  mgWon = false;
  mgMsg = null;
  mgSetStatus("第 " + (i + 1) + " 洞（共 " + MG_HOLES.length + " 洞）— 标准杆 " + MG_PAR, "info");
  mgUpdateHud();
  mgRender();
}

// 一帧物理（上游 tick 的运动部分，MG.step 可同步连跑多帧）
function mgPhysics() {
  if (!mgBall.moving) return;
  var h = MG_HOLES[mgLevel];
  var fr = 0.985;
  for (var si = 0; si < h.sands.length; si++) {
    var s = h.sands[si];
    if (mgBall.x > s.x && mgBall.x < s.x + s.w && mgBall.y > s.y && mgBall.y < s.y + s.h) fr = 0.9;
  }
  mgBall.vx *= fr;
  mgBall.vy *= fr;
  mgBall.x += mgBall.vx;
  mgBall.y += mgBall.vy;
  for (var wi = 0; wi < h.walls.length; wi++) {
    var w = h.walls[wi];
    if (mgBall.x > w.x - 7 && mgBall.x < w.x + w.w + 7 && mgBall.y > w.y - 7 && mgBall.y < w.y + w.h + 7) {
      var dl = Math.abs(mgBall.x - (w.x - 7)), dr = Math.abs(w.x + w.w + 7 - mgBall.x);
      var dtp = Math.abs(mgBall.y - (w.y - 7)), db = Math.abs(w.y + w.h + 7 - mgBall.y);
      var mm = Math.min(dl, dr, dtp, db);
      if (mm === dl) { mgBall.x = w.x - 7; mgBall.vx = -Math.abs(mgBall.vx) * 0.8; }
      else if (mm === dr) { mgBall.x = w.x + w.w + 7; mgBall.vx = Math.abs(mgBall.vx) * 0.8; }
      else if (mm === dtp) { mgBall.y = w.y - 7; mgBall.vy = -Math.abs(mgBall.vy) * 0.8; }
      else { mgBall.y = w.y + w.h + 7; mgBall.vy = Math.abs(mgBall.vy) * 0.8; }
      if (typeof sfx !== "undefined") sfx.bounce();
    }
  }
  if (mgBall.x < 14) { mgBall.x = 14; mgBall.vx = Math.abs(mgBall.vx) * 0.8; }
  if (mgBall.x > MG_W - 14) { mgBall.x = MG_W - 14; mgBall.vx = -Math.abs(mgBall.vx) * 0.8; }
  if (mgBall.y < 14) { mgBall.y = 14; mgBall.vy = Math.abs(mgBall.vy) * 0.8; }
  if (mgBall.y > MG_H - 14) { mgBall.y = MG_H - 14; mgBall.vy = -Math.abs(mgBall.vy) * 0.8; }
  var d = Math.hypot(mgBall.x - h.hole.x, mgBall.y - h.hole.y);
  var sp = Math.hypot(mgBall.vx, mgBall.vy);
  if (d < 12 && sp < 5.5) {
    mgBall.moving = false;
    mgBall.x = h.hole.x;
    mgBall.y = h.hole.y;
    mgHoleOut();
    return;
  }
  if (sp < 0.12) {
    mgBall.moving = false;
    mgBall.vx = mgBall.vy = 0;
  }
}

function mgTick() {
  mgPhysics();
  mgRender();
  mgRaf = requestAnimationFrame(mgTick);
}

function mgHoleOut() {
  mgWon = true;
  mgTotal += mgStrokes;
  if (typeof sfx !== "undefined") sfx.win();
  mgMsg = mgStrokes <= MG_PAR ? mgStrokes + " 杆进洞，标准杆以内！" : mgStrokes + " 杆进洞";
  mgSetStatus(mgMsg, "win");
  mgUpdateHud();
  mgTimer = setTimeout(function () {
    mgTimer = null;
    if (mgLevel + 1 < MG_HOLES.length) {
      mgLoadHole(mgLevel + 1);
    } else {
      var parTotal = MG_PAR * MG_HOLES.length;
      mgMsg = "5 洞打完！总杆数 " + mgTotal + "（标准杆 " + parTotal + "）";
      mgSetStatus(mgTotal <= parTotal ? "5 洞共 " + mgTotal + " 杆，标准杆以内，漂亮！" : "5 洞共 " + mgTotal + " 杆，继续加油！点「重新开始」再来一轮。", mgTotal <= parTotal ? "win" : "info");
      if (mgBest === 0 || mgTotal < mgBest) mgBest = mgTotal;
      mgRender();
    }
  }, 900);
}

// 松手击球与 MG.shoot 共用的击球函数
function mgDoShoot(vx, vy) {
  mgBall.vx = vx;
  mgBall.vy = vy;
  mgBall.moving = true;
  mgStrokes++;
  if (typeof sfx !== "undefined") sfx.putt();
  mgUpdateHud();
}

function mgPos(e) {
  var r = mgCanvas.getBoundingClientRect();
  var t = e;
  if (e.touches && e.touches.length) t = e.touches[0];
  else if (e.changedTouches && e.changedTouches.length) t = e.changedTouches[0];
  return {x: (t.clientX - r.left) * (MG_W / r.width), y: (t.clientY - r.top) * (MG_H / r.height)};
}
function mgDown(e) {
  if (mgBall.moving || mgWon) return;
  var p = mgPos(e);
  if (Math.hypot(p.x - mgBall.x, p.y - mgBall.y) < 40) {
    mgDrag = {x: p.x, y: p.y};
    if (e.preventDefault) e.preventDefault();
  }
}
function mgMove(e) {
  if (mgDrag) {
    if (e.preventDefault) e.preventDefault();
    var p = mgPos(e);
    mgDrag.x = p.x;
    mgDrag.y = p.y;
  }
}
function mgUp() {
  if (!mgDrag) return;
  var dx = mgBall.x - mgDrag.x, dy = mgBall.y - mgDrag.y;
  var d = Math.hypot(dx, dy);
  if (d > 8) {
    var pw = Math.min(11, d / 12);
    mgDoShoot((dx / d) * pw, (dy / d) * pw);
  }
  mgDrag = null;
}
mgCanvas.addEventListener("touchstart", mgDown, {passive: false});
mgCanvas.addEventListener("touchmove", mgMove, {passive: false});
mgCanvas.addEventListener("touchend", mgUp);
mgCanvas.addEventListener("touchcancel", mgUp);
mgCanvas.addEventListener("mousedown", mgDown);
mgCanvas.addEventListener("mousemove", mgMove);
window.addEventListener("mouseup", mgUp);

// 手写圆角矩形路径（旧 WebView 无 ctx.roundRect）
function mgRoundRectPath(x, y, w, h, r) {
  mgCtx.beginPath();
  mgCtx.moveTo(x + r, y);
  mgCtx.lineTo(x + w - r, y);
  mgCtx.arc(x + w - r, y + r, r, -Math.PI / 2, 0);
  mgCtx.lineTo(x + w, y + h - r);
  mgCtx.arc(x + w - r, y + h - r, r, 0, Math.PI / 2);
  mgCtx.lineTo(x + r, y + h);
  mgCtx.arc(x + r, y + h - r, r, Math.PI / 2, Math.PI);
  mgCtx.lineTo(x, y + r);
  mgCtx.arc(x + r, y + r, r, Math.PI, Math.PI * 1.5);
  mgCtx.closePath();
}

function mgRender() {
  var h = MG_HOLES[mgLevel];
  // 球场外圈（深绿）
  mgCtx.fillStyle = "#1e6b34";
  mgCtx.fillRect(0, 0, MG_W, MG_H);
  // 果岭（带剪草条纹）
  mgCtx.save();
  mgRoundRectPath(8, 8, MG_W - 16, MG_H - 16, 18);
  mgCtx.clip();
  mgCtx.fillStyle = "#3f9e4d";
  mgCtx.fillRect(8, 8, MG_W - 16, MG_H - 16);
  mgCtx.fillStyle = "rgba(255,255,255,0.06)";
  for (var sx = 8; sx < MG_W - 8; sx += 76) mgCtx.fillRect(sx, 8, 38, MG_H - 16);
  // 沙坑
  mgCtx.fillStyle = "#eed9a0";
  for (var i = 0; i < h.sands.length; i++) {
    var s = h.sands[i];
    mgCtx.fillRect(s.x, s.y, s.w, s.h);
  }
  // 墙体（木色）
  mgCtx.fillStyle = "#6b4f2a";
  for (var j = 0; j < h.walls.length; j++) {
    var w = h.walls[j];
    mgCtx.fillRect(w.x, w.y, w.w, w.h);
  }
  // 洞口
  mgCtx.fillStyle = "#111827";
  mgCtx.beginPath();
  mgCtx.arc(h.hole.x, h.hole.y, 11, 0, Math.PI * 2);
  mgCtx.fill();
  mgCtx.strokeStyle = "#f8fafc";
  mgCtx.lineWidth = 2;
  mgCtx.stroke();
  // 红旗
  mgCtx.strokeStyle = "#e2e8f0";
  mgCtx.lineWidth = 2;
  mgCtx.beginPath();
  mgCtx.moveTo(h.hole.x, h.hole.y);
  mgCtx.lineTo(h.hole.x, h.hole.y - 26);
  mgCtx.stroke();
  mgCtx.fillStyle = "#dc2626";
  mgCtx.beginPath();
  mgCtx.moveTo(h.hole.x, h.hole.y - 26);
  mgCtx.lineTo(h.hole.x + 20, h.hole.y - 20);
  mgCtx.lineTo(h.hole.x, h.hole.y - 14);
  mgCtx.closePath();
  mgCtx.fill();
  // 瞄准线
  if (mgDrag) {
    mgCtx.strokeStyle = "rgba(255,255,255,0.9)";
    mgCtx.lineWidth = 2;
    mgCtx.setLineDash([6, 6]);
    mgCtx.beginPath();
    mgCtx.moveTo(mgBall.x, mgBall.y);
    var pw = Math.min(11, Math.hypot(mgBall.x - mgDrag.x, mgBall.y - mgDrag.y) / 12);
    var ux = (mgBall.x - mgDrag.x), uy = (mgBall.y - mgDrag.y), ud = Math.hypot(ux, uy) || 1;
    mgCtx.lineTo(mgBall.x + ux / ud * pw * 10, mgBall.y + uy / ud * pw * 10);
    mgCtx.stroke();
    mgCtx.setLineDash([]);
  }
  // 球（带阴影）
  mgCtx.fillStyle = "rgba(0,0,0,0.25)";
  mgCtx.beginPath();
  mgCtx.arc(mgBall.x + 2, mgBall.y + 3, 7, 0, Math.PI * 2);
  mgCtx.fill();
  mgCtx.fillStyle = "#f8fafc";
  mgCtx.beginPath();
  mgCtx.arc(mgBall.x, mgBall.y, 7, 0, Math.PI * 2);
  mgCtx.fill();
  mgCtx.restore();
  // 果岭边框
  mgCtx.strokeStyle = "#14532d";
  mgCtx.lineWidth = 3;
  mgRoundRectPath(8, 8, MG_W - 16, MG_H - 16, 18);
  mgCtx.stroke();
  if (mgMsg) {
    mgCtx.fillStyle = "rgba(0,0,0,0.55)";
    mgCtx.fillRect(0, MG_H / 2 - 30, MG_W, 60);
    mgCtx.fillStyle = "#fff";
    mgCtx.font = "bold 18px sans-serif";
    mgCtx.textAlign = "center";
    mgCtx.fillText(mgMsg, MG_W / 2, MG_H / 2 + 6);
  }
}

mgEl("mg-restart").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  mgTotal = 0;
  mgLoadHole(0);
});
var mgScreen = "home";
mgEl("mg-start").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  mgScreen = "game";
  mgEl("mg-home").className = "mg-hidden";
  mgEl("mg-game").className = "";
  mgTotal = 0;
  mgLoadHole(0);
});
mgEl("mg-back").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  mgScreen = "home";
  mgEl("mg-game").className = "mg-hidden";
  mgEl("mg-home").className = "";
});
mgEl("mg-help-home").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  mgEl("mg-mask").className = "mg-mask open";
});
mgEl("mg-help").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  mgEl("mg-mask").className = "mg-mask open";
});
mgEl("mg-help-close").addEventListener("click", function () {
  mgEl("mg-mask").className = "mg-mask";
});
mgEl("mg-mask").addEventListener("click", function (e) {
  if (e.target === mgEl("mg-mask")) mgEl("mg-mask").className = "mg-mask";
});

var MG = {
  getState: function () {
    return {
      screen: mgScreen,
      level: mgLevel,
      strokes: mgStrokes,
      total: mgTotal,
      ballX: Math.round(mgBall.x * 100) / 100,
      ballY: Math.round(mgBall.y * 100) / 100,
      moving: mgBall.moving,
      won: mgWon,
      holeX: MG_HOLES[mgLevel].hole.x,
      holeY: MG_HOLES[mgLevel].hole.y,
      helpVisible: mgEl("mg-mask").className.indexOf("open") >= 0,
      sfxClicks: mgSfxClicks,
      sfxWins: mgSfxWins
    };
  },
  shoot: function (vx, vy) {
    if (!mgBall.moving && !mgWon) mgDoShoot(vx, vy);
    return MG.getState();
  },
  step: function (n) {
    for (var i = 0; i < n; i++) mgPhysics();
    mgRender();
    return MG.getState();
  }
};

mgLoadHole(0);
mgTick();
