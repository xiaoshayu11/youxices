/* 表情猎手（Emoji Catcher）：60 秒内在格子里找到与顶部目标相同的表情，点中得分。
   机制源自 he-is-talha 34-Emoji-Catcher-Game（MIT），表情为 emoji 字符（游戏内容本身）。 */
function bqEl(id) { return document.getElementById(id); }

/* ---- WebAudio 合成音效 ---- */
var bqAudioCtx = null;
function bqCtx() {
  if (!bqAudioCtx) {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    bqAudioCtx = new AC();
  }
  if (bqAudioCtx.state === "suspended") bqAudioCtx.resume();
  return bqAudioCtx;
}
function bqTone(freqFrom, freqTo, dur, type, vol, delay) {
  var ctx = bqCtx();
  if (!ctx) return;
  var t0 = ctx.currentTime + (delay || 0);
  var osc = ctx.createOscillator();
  var gain = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freqFrom, t0);
  osc.frequency.exponentialRampToValueAtTime(Math.max(freqTo, 1), t0 + dur);
  gain.gain.setValueAtTime(vol || 0.15, t0);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}
var sfx = {
  hit: function () { bqTone(660, 1040, 0.12, "sine", 0.18, 0); },
  miss: function () { bqTone(220, 150, 0.1, "triangle", 0.09, 0); },
  click: function () { bqTone(500, 700, 0.07, "sine", 0.1, 0); },
  end: function () {
    bqTone(523, 523, 0.14, "sine", 0.16, 0);
    bqTone(659, 659, 0.14, "sine", 0.16, 0.15);
    bqTone(784, 784, 0.22, "sine", 0.16, 0.3);
  }
};

/* ---- 游戏状态 ---- */
var BQ_CELLS = 10;
var BQ_DURATION = 60;
/* 自绘可爱动物组 v3（12 只小动物各一种表情，统一描边 #6b4f3a + 头顶高光 + 柔和腮红） */
function bqEye(x, y) {
  y = y || 54;
  return '<ellipse cx="' + x + '" cy="' + y + '" rx="5" ry="7.5" fill="#3a2e1f"/><circle cx="' + (x - 1.5) + '" cy="' + (y - 3) + '" r="1.9" fill="#ffffff"/><circle cx="' + (x + 1.5) + '" cy="' + (y + 3) + '" r="1" fill="#ffffff"/>';
}
var BQ_SHINE = '<ellipse cx="34" cy="38" rx="11" ry="6" fill="#ffffff" opacity="0.35" transform="rotate(-20 34 38)"/>';
var BQ_BLUSH = '<ellipse cx="25" cy="67" rx="7.5" ry="4.6" fill="#ffb3c6" opacity="0.75"/><ellipse cx="75" cy="67" rx="7.5" ry="4.6" fill="#ffb3c6" opacity="0.75"/>';
var BQ_FACES = [
  /* 猫咪·开心（闭眼笑） */
  '<svg viewBox="0 0 100 100"><path d="M24 32 L17 9 L41 17 Z" fill="#ffe5d9" stroke="#6b4f3a" stroke-width="3" stroke-linejoin="round"/><path d="M26 26 L22 14 L35 18.5 Z" fill="#ffb3c6"/><path d="M76 32 L83 9 L59 17 Z" fill="#ffe5d9" stroke="#6b4f3a" stroke-width="3" stroke-linejoin="round"/><path d="M74 26 L78 14 L65 18.5 Z" fill="#ffb3c6"/><circle cx="50" cy="56" r="36" fill="#ffe5d9" stroke="#6b4f3a" stroke-width="3"/>' + BQ_SHINE + BQ_BLUSH + '<path d="M30 54 Q36 46 42 54" fill="none" stroke="#3a2e1f" stroke-width="3.2" stroke-linecap="round"/><path d="M58 54 Q64 46 70 54" fill="none" stroke="#3a2e1f" stroke-width="3.2" stroke-linecap="round"/><path d="M46.5 64 L53.5 64 L50 68.5 Z" fill="#ff8fab" stroke="#6b4f3a" stroke-width="1.8" stroke-linejoin="round"/><path d="M43 70 Q46.5 75 50 70 Q53.5 75 57 70" fill="none" stroke="#3a2e1f" stroke-width="2.8" stroke-linecap="round"/><path d="M13 57 Q20 59 27 60 M14 68 Q21 67 28 66 M87 57 Q80 59 73 60 M86 68 Q79 67 72 66" fill="none" stroke="#6b4f3a" stroke-width="1.8" stroke-linecap="round"/></svg>',
  /* 狗狗·吐舌 */
  '<svg viewBox="0 0 100 100"><ellipse cx="15" cy="43" rx="9" ry="20" fill="#b08968" stroke="#6b4f3a" stroke-width="3"/><ellipse cx="16" cy="44" rx="4.5" ry="13" fill="#d9b48f"/><ellipse cx="85" cy="43" rx="9" ry="20" fill="#b08968" stroke="#6b4f3a" stroke-width="3"/><ellipse cx="84" cy="44" rx="4.5" ry="13" fill="#d9b48f"/><circle cx="50" cy="54" r="36" fill="#ffefc2" stroke="#6b4f3a" stroke-width="3"/>' + BQ_SHINE + BQ_BLUSH + bqEye(36) + bqEye(64) + '<ellipse cx="50" cy="67" rx="13" ry="9" fill="#ffffff" stroke="#6b4f3a" stroke-width="2.5"/><ellipse cx="50" cy="63" rx="5.5" ry="4" fill="#3a2e1f"/><path d="M44 70 L44 79 Q50 84 56 79 L56 70 Q50 74 44 70Z" fill="#ff8fab" stroke="#6b4f3a" stroke-width="2.2" stroke-linejoin="round"/><path d="M50 72 L50 80" stroke="#e56b8c" stroke-width="1.8" stroke-linecap="round"/></svg>',
  /* 兔子·惊讶 */
  '<svg viewBox="0 0 100 100"><ellipse cx="33" cy="13" rx="8" ry="16" fill="#ffffff" stroke="#6b4f3a" stroke-width="3"/><ellipse cx="33" cy="14" rx="4" ry="10.5" fill="#ffb3c6"/><ellipse cx="67" cy="13" rx="8" ry="16" fill="#ffffff" stroke="#6b4f3a" stroke-width="3"/><ellipse cx="67" cy="14" rx="4" ry="10.5" fill="#ffb3c6"/><circle cx="50" cy="58" r="34" fill="#ffffff" stroke="#6b4f3a" stroke-width="3"/>' + BQ_SHINE + BQ_BLUSH + '<path d="M29 44 Q37 39 45 44" fill="none" stroke="#3a2e1f" stroke-width="2.8" stroke-linecap="round"/><path d="M55 44 Q63 39 71 44" fill="none" stroke="#3a2e1f" stroke-width="2.8" stroke-linecap="round"/><circle cx="37" cy="54" r="6.5" fill="#ffffff" stroke="#3a2e1f" stroke-width="3"/><circle cx="63" cy="54" r="6.5" fill="#ffffff" stroke="#3a2e1f" stroke-width="3"/><circle cx="37" cy="55" r="2.8" fill="#3a2e1f"/><circle cx="63" cy="55" r="2.8" fill="#3a2e1f"/><ellipse cx="50" cy="71" rx="4.5" ry="5.5" fill="#3a2e1f"/><ellipse cx="50" cy="73" rx="2.4" ry="2.6" fill="#ff8fab"/></svg>',
  /* 熊猫·困 */
  '<svg viewBox="0 0 100 100"><circle cx="23" cy="25" r="11" fill="#3a2e1f"/><circle cx="77" cy="25" r="11" fill="#3a2e1f"/><circle cx="50" cy="55" r="36" fill="#ffffff" stroke="#6b4f3a" stroke-width="3"/>' + BQ_SHINE + '<ellipse cx="36" cy="52" rx="8.5" ry="10.5" fill="#3a2e1f" transform="rotate(-16 36 52)"/><ellipse cx="64" cy="52" rx="8.5" ry="10.5" fill="#3a2e1f" transform="rotate(16 64 52)"/><path d="M31 52 Q36 56.5 41 52" fill="none" stroke="#ffffff" stroke-width="2.8" stroke-linecap="round"/><path d="M59 52 Q64 56.5 69 52" fill="none" stroke="#ffffff" stroke-width="2.8" stroke-linecap="round"/>' + BQ_BLUSH + '<ellipse cx="50" cy="63" rx="5" ry="3.6" fill="#3a2e1f"/><circle cx="50" cy="72" r="3.4" fill="#3a2e1f"/><text x="75" y="28" font-size="13" fill="#4361ee" font-weight="bold">Z</text><text x="83" y="18" font-size="9" fill="#4361ee" font-weight="bold">Z</text></svg>',
  /* 小熊·哭 */
  '<svg viewBox="0 0 100 100"><circle cx="23" cy="26" r="11" fill="#b08968" stroke="#6b4f3a" stroke-width="3"/><circle cx="23" cy="26" r="5.5" fill="#ffefc2"/><circle cx="77" cy="26" r="11" fill="#b08968" stroke="#6b4f3a" stroke-width="3"/><circle cx="77" cy="26" r="5.5" fill="#ffefc2"/><circle cx="50" cy="55" r="36" fill="#c99b6d" stroke="#6b4f3a" stroke-width="3"/>' + BQ_SHINE + BQ_BLUSH + bqEye(36) + bqEye(64) + '<path d="M27 60 Q21 71 27 76 Q33 71 27 60Z" fill="#4cc9f0"/><path d="M73 60 Q67 71 73 76 Q79 71 73 60Z" fill="#4cc9f0"/><ellipse cx="50" cy="68" rx="13" ry="9" fill="#ffefc2" stroke="#6b4f3a" stroke-width="2.5"/><ellipse cx="50" cy="64" rx="5.5" ry="4" fill="#3a2e1f"/><path d="M42 74 Q46 70 50 74 Q54 78 58 74" fill="none" stroke="#3a2e1f" stroke-width="2.6" stroke-linecap="round"/></svg>',
  /* 小猪·爱心眼 */
  '<svg viewBox="0 0 100 100"><path d="M27 27 Q18 12 33 11 Q41 13 37 25 Z" fill="#ffb3c6" stroke="#6b4f3a" stroke-width="3" stroke-linejoin="round"/><path d="M73 27 Q82 12 67 11 Q59 13 63 25 Z" fill="#ffb3c6" stroke="#6b4f3a" stroke-width="3" stroke-linejoin="round"/><circle cx="50" cy="55" r="36" fill="#ffd6e0" stroke="#6b4f3a" stroke-width="3"/>' + BQ_SHINE + '<ellipse cx="24" cy="66" rx="7.5" ry="4.6" fill="#ff8fa3" opacity="0.85"/><ellipse cx="76" cy="66" rx="7.5" ry="4.6" fill="#ff8fa3" opacity="0.85"/><path d="M36 55 C30 47 23 51 26 58 C28 63 36 67 36 67 C36 67 44 63 46 58 C49 51 42 47 36 55Z" fill="#ff4d6d"/><path d="M64 55 C58 47 51 51 54 58 C56 63 64 67 64 67 C64 67 72 63 74 58 C77 51 70 47 64 55Z" fill="#ff4d6d"/><ellipse cx="50" cy="70" rx="11" ry="8" fill="#ffb3c6" stroke="#6b4f3a" stroke-width="2.5"/><ellipse cx="46" cy="70" rx="1.8" ry="2.6" fill="#c9184a"/><ellipse cx="54" cy="70" rx="1.8" ry="2.6" fill="#c9184a"/></svg>',
  /* 青蛙·大笑 */
  '<svg viewBox="0 0 100 100"><circle cx="32" cy="27" r="10" fill="#95d5b2" stroke="#52796f" stroke-width="3"/><circle cx="68" cy="27" r="10" fill="#95d5b2" stroke="#52796f" stroke-width="3"/><circle cx="50" cy="57" r="35" fill="#b7e4c7" stroke="#52796f" stroke-width="3"/>' + BQ_SHINE + BQ_BLUSH + '<path d="M27 28 Q32 23 37 28" fill="none" stroke="#3a2e1f" stroke-width="2.8" stroke-linecap="round"/><path d="M63 28 Q68 23 73 28" fill="none" stroke="#3a2e1f" stroke-width="2.8" stroke-linecap="round"/><circle cx="44" cy="52" r="1.6" fill="#52796f"/><circle cx="56" cy="52" r="1.6" fill="#52796f"/><path d="M31 62 Q50 84 69 62 Q50 71 31 62Z" fill="#3a2e1f"/><ellipse cx="50" cy="70" rx="8" ry="3.4" fill="#ff8fab"/></svg>',
  /* 小鸡·眨眼 */
  '<svg viewBox="0 0 100 100"><path d="M44 20 Q40 8 33 7 Q41 11 44 18 M50 19 Q50 6 58 4 Q54 11 53 18 M56 20 Q61 9 68 9 Q61 13 59 19" fill="none" stroke="#f4a261" stroke-width="3.5" stroke-linecap="round"/><circle cx="50" cy="56" r="36" fill="#ffe66d" stroke="#a97b00" stroke-width="3"/>' + BQ_SHINE + '<ellipse cx="25" cy="66" rx="7.5" ry="4.6" fill="#ffb703" opacity="0.8"/><ellipse cx="75" cy="66" rx="7.5" ry="4.6" fill="#ffb703" opacity="0.8"/><path d="M30 54 Q36 47 42 54" fill="none" stroke="#3a2e1f" stroke-width="3.2" stroke-linecap="round"/>' + bqEye(64) + '<path d="M43 64 L57 64 L50 73 Z" fill="#fb8500" stroke="#a97b00" stroke-width="2.4" stroke-linejoin="round"/><path d="M44 66 L56 66" stroke="#d96f00" stroke-width="1.8"/></svg>',
  /* 狐狸·得意 */
  '<svg viewBox="0 0 100 100"><path d="M23 33 L15 7 L43 17 Z" fill="#f4a261" stroke="#6b4f3a" stroke-width="3" stroke-linejoin="round"/><path d="M26 27 L22 13 L37 19 Z" fill="#3a2e1f"/><path d="M77 33 L85 7 L57 17 Z" fill="#f4a261" stroke="#6b4f3a" stroke-width="3" stroke-linejoin="round"/><path d="M74 27 L78 13 L63 19 Z" fill="#3a2e1f"/><circle cx="50" cy="56" r="36" fill="#f4a261" stroke="#6b4f3a" stroke-width="3"/>' + BQ_SHINE + '<path d="M25 60 Q29 83 50 84 Q71 83 75 60 Q63 71 50 71 Q37 71 25 60Z" fill="#ffffff"/>' + BQ_BLUSH + '<path d="M29 45 Q36 41 43 44" fill="none" stroke="#3a2e1f" stroke-width="2.8" stroke-linecap="round"/><path d="M57 42 Q64 38 71 42" fill="none" stroke="#3a2e1f" stroke-width="2.8" stroke-linecap="round"/><path d="M30 54 Q36 49 42 54" fill="none" stroke="#3a2e1f" stroke-width="3" stroke-linecap="round"/><path d="M58 54 Q64 49 70 54" fill="none" stroke="#3a2e1f" stroke-width="3" stroke-linecap="round"/><ellipse cx="50" cy="65" rx="5" ry="3.6" fill="#3a2e1f"/><path d="M42 74 Q54 79 62 71" fill="none" stroke="#3a2e1f" stroke-width="2.8" stroke-linecap="round"/></svg>',
  /* 考拉·呆 */
  '<svg viewBox="0 0 100 100"><circle cx="14" cy="44" r="12" fill="#ced4da" stroke="#6c757d" stroke-width="3"/><circle cx="10" cy="38" r="4" fill="#ffffff"/><circle cx="17" cy="50" r="4" fill="#ffffff"/><circle cx="86" cy="44" r="12" fill="#ced4da" stroke="#6c757d" stroke-width="3"/><circle cx="90" cy="38" r="4" fill="#ffffff"/><circle cx="83" cy="50" r="4" fill="#ffffff"/><circle cx="50" cy="55" r="35" fill="#dee2e6" stroke="#6c757d" stroke-width="3"/>' + BQ_SHINE + BQ_BLUSH + '<circle cx="35" cy="53" r="3.6" fill="#3a2e1f"/><circle cx="65" cy="53" r="3.6" fill="#3a2e1f"/><ellipse cx="50" cy="60" rx="6" ry="8.5" fill="#495057"/><path d="M44 78 L56 78" stroke="#3a2e1f" stroke-width="2.8" stroke-linecap="round"/></svg>',
  /* 企鹅·星星眼 */
  '<svg viewBox="0 0 100 100"><circle cx="50" cy="54" r="37" fill="#4361ee" stroke="#2b2d5c" stroke-width="3"/><path d="M50 17 Q47 9 42 7 M50 17 Q53 9 58 7" fill="none" stroke="#2b2d5c" stroke-width="2.6" stroke-linecap="round"/><ellipse cx="50" cy="60" rx="27" ry="28" fill="#ffffff"/>' + BQ_BLUSH + '<path d="M38 44 L40.5 50 L47 50 L41.8 54 L43.6 60 L38 56.4 L32.4 60 L34.2 54 L29 50 L35.5 50 Z" fill="#ff9f1c" stroke="#6b4f3a" stroke-width="1.8" stroke-linejoin="round"/><path d="M62 44 L64.5 50 L71 50 L65.8 54 L67.6 60 L62 56.4 L56.4 60 L58.2 54 L53 50 L59.5 50 Z" fill="#ff9f1c" stroke="#6b4f3a" stroke-width="1.8" stroke-linejoin="round"/><path d="M44 62 L56 62 L50 69 Z" fill="#fb8500" stroke="#a97b00" stroke-width="2.2" stroke-linejoin="round"/></svg>',
  /* 仓鼠·害羞 */
  '<svg viewBox="0 0 100 100"><circle cx="24" cy="25" r="10" fill="#ffe5d9" stroke="#6b4f3a" stroke-width="3"/><circle cx="24" cy="25" r="5" fill="#ffb3c6"/><circle cx="76" cy="25" r="10" fill="#ffe5d9" stroke="#6b4f3a" stroke-width="3"/><circle cx="76" cy="25" r="5" fill="#ffb3c6"/><circle cx="50" cy="56" r="36" fill="#fff1d6" stroke="#6b4f3a" stroke-width="3"/>' + BQ_SHINE + '<ellipse cx="21" cy="68" rx="10" ry="7" fill="#ff8fa3" opacity="0.9"/><ellipse cx="79" cy="68" rx="10" ry="7" fill="#ff8fa3" opacity="0.9"/><ellipse cx="39" cy="53" rx="5" ry="7.5" fill="#3a2e1f"/><circle cx="37.5" cy="50" r="1.9" fill="#ffffff"/><ellipse cx="67" cy="53" rx="5" ry="7.5" fill="#3a2e1f"/><circle cx="65.5" cy="50" r="1.9" fill="#ffffff"/><path d="M47 64 L53 64 L50 68 Z" fill="#ff8fab" stroke="#6b4f3a" stroke-width="1.8" stroke-linejoin="round"/><rect x="46" y="70" width="8" height="7" rx="2" fill="#ffffff" stroke="#6b4f3a" stroke-width="2.2"/><path d="M50 71 L50 76" stroke="#6b4f3a" stroke-width="1.6"/></svg>'
];
var bqScreen = "home";
var bqScore = 0;
var bqTimeLeft = BQ_DURATION;
var bqOver = false;
var bqTimerId = null;
var bqLastTick = 0;
var bqRoundTimer = null;
var bqTargetIdx = -1;
var bqTargetFace = -1;
var bqCellFaces = [];
var bqSfxClicks = 0;
var bqSfxWins = 0;
var bqSfxMiss = 0;

function bqUpdateHud() {
  bqEl("bq-score").textContent = bqScore;
  var t = Math.ceil(Math.max(bqTimeLeft, 0));
  bqEl("bq-time").textContent = t;
  var pct = Math.max(bqTimeLeft, 0) / BQ_DURATION * 100;
  bqEl("bq-timefill").style.width = pct + "%";
}

function bqClearTimers() {
  if (bqTimerId) { clearInterval(bqTimerId); bqTimerId = null; }
  if (bqRoundTimer) { clearTimeout(bqRoundTimer); bqRoundTimer = null; }
}

function bqNewRound() {
  var grid = bqEl("bq-grid");
  var cells = grid.children;
  bqTargetFace = Math.floor(Math.random() * BQ_FACES.length);
  bqTargetIdx = Math.floor(Math.random() * BQ_CELLS);
  bqEl("bq-target").innerHTML = BQ_FACES[bqTargetFace];
  bqCellFaces = [];
  for (var i = 0; i < cells.length; i++) {
    var cell = cells[i];
    cell.className = "bq-cell c" + (i % 6);
    if (i === bqTargetIdx) {
      bqCellFaces[i] = bqTargetFace;
    } else {
      var f = bqTargetFace;
      while (f === bqTargetFace) f = Math.floor(Math.random() * BQ_FACES.length);
      bqCellFaces[i] = f;
    }
    cell.innerHTML = BQ_FACES[bqCellFaces[i]];
    cell.setAttribute("data-idx", i);
  }
}

function bqTapCell(idx) {
  if (bqOver || bqScreen !== "game") return;
  var cells = bqEl("bq-grid").children;
  var cell = cells[idx];
  if (!cell) return;
  if (idx === bqTargetIdx) {
    bqScore++;
    bqSfxClicks++;
    if (typeof sfx !== "undefined") sfx.hit();
    cell.className = "bq-cell c" + (idx % 6) + " hit";
    bqUpdateHud();
    if (bqRoundTimer) clearTimeout(bqRoundTimer);
    bqRoundTimer = setTimeout(bqNewRound, 220);
  } else {
    bqSfxMiss++;
    if (typeof sfx !== "undefined") sfx.miss();
    cell.className = "bq-cell c" + (idx % 6);
    void cell.offsetWidth;
    cell.className = "bq-cell c" + (idx % 6) + " shake";
  }
}

function bqTick() {
  var now = Date.now();
  var dt = (now - bqLastTick) / 1000;
  bqLastTick = now;
  bqTimeLeft -= dt;
  if (bqTimeLeft <= 0) {
    bqTimeLeft = 0;
    bqUpdateHud();
    bqEnd();
    return;
  }
  bqUpdateHud();
}

function bqStart() {
  bqClearTimers();
  bqScore = 0;
  bqTimeLeft = BQ_DURATION;
  bqOver = false;
  bqEl("bq-over").className = "bq-over bq-hidden";
  bqNewRound();
  bqUpdateHud();
  bqLastTick = Date.now();
  bqTimerId = setInterval(bqTick, 200);
}

function bqEnd() {
  bqOver = true;
  bqClearTimers();
  bqSfxWins++;
  if (typeof sfx !== "undefined") sfx.end();
  bqEl("bq-final").textContent = bqScore;
  bqEl("bq-over").className = "bq-over";
}

function bqShowHome() {
  bqScreen = "home";
  bqClearTimers();
  bqEl("bq-game").className = "bq-hidden";
  bqEl("bq-home").className = "";
}

function bqShowGame() {
  bqScreen = "game";
  bqEl("bq-home").className = "bq-hidden";
  bqEl("bq-game").className = "";
  bqStart();
}

/* ---- 建格子 ---- */
function bqBuildGrid() {
  var grid = bqEl("bq-grid");
  for (var i = 0; i < BQ_CELLS; i++) {
    var cell = document.createElement("div");
    cell.className = "bq-cell c" + (i % 6);
    cell.setAttribute("data-idx", i);
    (function (idx) {
      var handler = function (e) {
        if (e && e.preventDefault) e.preventDefault();
        bqTapCell(idx);
      };
      cell.addEventListener("touchstart", handler);
      cell.addEventListener("click", handler);
    })(i);
    grid.appendChild(cell);
  }
}

/* ---- 事件绑定 ---- */
bqEl("bq-start").addEventListener("click", function () {
  bqCtx();
  if (typeof sfx !== "undefined") sfx.click();
  bqShowGame();
});
bqEl("bq-again").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  bqStart();
});
bqEl("bq-back").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  bqShowHome();
});
bqEl("bq-over-home").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  bqShowHome();
});
function bqOpenHelp() {
  if (typeof sfx !== "undefined") sfx.click();
  bqEl("bq-mask").className = "bq-mask open";
}
bqEl("bq-help").addEventListener("click", bqOpenHelp);
bqEl("bq-help-home").addEventListener("click", bqOpenHelp);
bqEl("bq-help-close").addEventListener("click", function () {
  bqEl("bq-mask").className = "bq-mask";
});
bqEl("bq-mask").addEventListener("click", function (e) {
  if (e.target === bqEl("bq-mask")) bqEl("bq-mask").className = "bq-mask";
});

/* ---- 测试桥 ---- */
/* 首页展示 5 个自绘表情 */
(function () {
  var spans = document.querySelectorAll(".bq-home-faces span");
  var show = [0, 1, 2, 6, 3];
  for (var i = 0; i < spans.length && i < show.length; i++) spans[i].innerHTML = BQ_FACES[show[i]];
})();

var BQ = {
  getState: function () {
    return {
      screen: bqScreen,
      score: bqScore,
      timeLeft: Math.round(bqTimeLeft * 10) / 10,
      target: bqTargetFace,
      targetIndex: bqTargetIdx,
      over: bqOver,
      helpVisible: bqEl("bq-mask").className.indexOf("open") >= 0,
      sfxClicks: bqSfxClicks,
      sfxWins: bqSfxWins,
      sfxMiss: bqSfxMiss
    };
  },
  targetPos: function () {
    var cells = bqEl("bq-grid").children;
    var cell = cells[bqTargetIdx];
    if (!cell) return null;
    var r = cell.getBoundingClientRect();
    return { index: bqTargetIdx, x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  },
  cellEmoji: function (i) {
    return (i >= 0 && i < bqCellFaces.length) ? bqCellFaces[i] : null;
  },
  setTimeLeft: function (s) {
    bqTimeLeft = s;
    bqLastTick = Date.now();
    bqUpdateHud();
    return BQ.getState();
  }
};

bqBuildGrid();
bqNewRound();
bqUpdateHud();
