/* 桥梁谜题（Hashi）：点两岛之间搭桥，数字为连到该岛的桥总数，全部连通通关。
   算法（可连判断/交叉检测/错误计数/检查判定）沿用上游 Pixel-Arcade hashi.js，仅汉化与换主题。 */
var HQ_PUZZLES = [{"size": 5, "islands": [{"r": 3, "c": 1, "n": 3}, {"r": 1, "c": 4, "n": 1}, {"r": 3, "c": 0, "n": 2}, {"r": 4, "c": 4, "n": 3}, {"r": 0, "c": 1, "n": 2}, {"r": 0, "c": 3, "n": 1}, {"r": 4, "c": 1, "n": 3}, {"r": 1, "c": 0, "n": 1}]}, {"size": 5, "islands": [{"r": 1, "c": 1, "n": 3}, {"r": 4, "c": 3, "n": 1}, {"r": 0, "c": 1, "n": 2}, {"r": 4, "c": 0, "n": 3}, {"r": 1, "c": 4, "n": 2}, {"r": 3, "c": 4, "n": 1}, {"r": 1, "c": 0, "n": 3}, {"r": 0, "c": 3, "n": 1}]}, {"size": 5, "islands": [{"r": 1, "c": 3, "n": 3}, {"r": 3, "c": 0, "n": 1}, {"r": 1, "c": 4, "n": 2}, {"r": 0, "c": 0, "n": 3}, {"r": 4, "c": 3, "n": 2}, {"r": 4, "c": 1, "n": 1}, {"r": 0, "c": 3, "n": 3}, {"r": 3, "c": 4, "n": 1}]}, {"size": 5, "islands": [{"r": 3, "c": 3, "n": 3}, {"r": 0, "c": 1, "n": 1}, {"r": 4, "c": 3, "n": 2}, {"r": 0, "c": 4, "n": 3}, {"r": 3, "c": 0, "n": 2}, {"r": 1, "c": 0, "n": 1}, {"r": 3, "c": 4, "n": 3}, {"r": 4, "c": 1, "n": 1}]}, {"size": 5, "islands": [{"r": 3, "c": 3, "n": 3}, {"r": 1, "c": 0, "n": 1}, {"r": 3, "c": 4, "n": 2}, {"r": 4, "c": 0, "n": 3}, {"r": 0, "c": 3, "n": 2}, {"r": 0, "c": 1, "n": 1}, {"r": 4, "c": 3, "n": 3}, {"r": 1, "c": 4, "n": 1}]}, {"size": 5, "islands": [{"r": 1, "c": 1, "n": 3}, {"r": 3, "c": 4, "n": 1}, {"r": 1, "c": 0, "n": 2}, {"r": 0, "c": 4, "n": 3}, {"r": 4, "c": 1, "n": 2}, {"r": 4, "c": 3, "n": 1}, {"r": 0, "c": 1, "n": 3}, {"r": 3, "c": 0, "n": 1}]}, {"size": 5, "islands": [{"r": 1, "c": 3, "n": 3}, {"r": 4, "c": 1, "n": 1}, {"r": 0, "c": 3, "n": 2}, {"r": 4, "c": 4, "n": 3}, {"r": 1, "c": 0, "n": 2}, {"r": 3, "c": 0, "n": 1}, {"r": 1, "c": 4, "n": 3}, {"r": 0, "c": 1, "n": 1}]}, {"size": 5, "islands": [{"r": 3, "c": 1, "n": 3}, {"r": 0, "c": 3, "n": 1}, {"r": 4, "c": 1, "n": 2}, {"r": 0, "c": 0, "n": 3}, {"r": 3, "c": 4, "n": 2}, {"r": 1, "c": 4, "n": 1}, {"r": 3, "c": 0, "n": 3}, {"r": 4, "c": 3, "n": 1}]}, {"size": 5, "islands": [{"r": 1, "c": 4, "n": 3}, {"r": 3, "c": 3, "n": 3}, {"r": 0, "c": 4, "n": 2}, {"r": 0, "c": 0, "n": 2}, {"r": 3, "c": 1, "n": 2}, {"r": 4, "c": 0, "n": 2}, {"r": 4, "c": 4, "n": 2}, {"r": 0, "c": 3, "n": 2}]}, {"size": 5, "islands": [{"r": 4, "c": 3, "n": 3}, {"r": 3, "c": 1, "n": 3}, {"r": 4, "c": 4, "n": 2}, {"r": 0, "c": 4, "n": 2}, {"r": 1, "c": 1, "n": 2}, {"r": 0, "c": 0, "n": 2}, {"r": 4, "c": 0, "n": 2}, {"r": 3, "c": 4, "n": 2}]}, {"size": 5, "islands": [{"r": 3, "c": 0, "n": 3}, {"r": 1, "c": 1, "n": 3}, {"r": 4, "c": 0, "n": 2}, {"r": 4, "c": 4, "n": 2}, {"r": 1, "c": 3, "n": 2}, {"r": 0, "c": 4, "n": 2}, {"r": 0, "c": 0, "n": 2}, {"r": 4, "c": 1, "n": 2}]}, {"size": 5, "islands": [{"r": 0, "c": 1, "n": 3}, {"r": 1, "c": 3, "n": 3}, {"r": 0, "c": 0, "n": 2}, {"r": 4, "c": 0, "n": 2}, {"r": 3, "c": 3, "n": 2}, {"r": 4, "c": 4, "n": 2}, {"r": 0, "c": 4, "n": 2}, {"r": 1, "c": 0, "n": 2}]}, {"size": 5, "islands": [{"r": 1, "c": 0, "n": 3}, {"r": 3, "c": 1, "n": 3}, {"r": 0, "c": 0, "n": 2}, {"r": 0, "c": 4, "n": 2}, {"r": 3, "c": 3, "n": 2}, {"r": 4, "c": 4, "n": 2}, {"r": 4, "c": 0, "n": 2}, {"r": 0, "c": 1, "n": 2}]}, {"size": 5, "islands": [{"r": 3, "c": 4, "n": 3}, {"r": 1, "c": 3, "n": 3}, {"r": 4, "c": 4, "n": 2}, {"r": 4, "c": 0, "n": 2}, {"r": 1, "c": 1, "n": 2}, {"r": 0, "c": 0, "n": 2}, {"r": 0, "c": 4, "n": 2}, {"r": 4, "c": 3, "n": 2}]}, {"size": 5, "islands": [{"r": 4, "c": 1, "n": 3}, {"r": 3, "c": 3, "n": 3}, {"r": 4, "c": 0, "n": 2}, {"r": 0, "c": 0, "n": 2}, {"r": 1, "c": 3, "n": 2}, {"r": 0, "c": 4, "n": 2}, {"r": 4, "c": 4, "n": 2}, {"r": 3, "c": 0, "n": 2}]}, {"size": 5, "islands": [{"r": 0, "c": 3, "n": 3}, {"r": 1, "c": 1, "n": 3}, {"r": 0, "c": 4, "n": 2}, {"r": 4, "c": 4, "n": 2}, {"r": 3, "c": 1, "n": 2}, {"r": 4, "c": 0, "n": 2}, {"r": 0, "c": 0, "n": 2}, {"r": 1, "c": 4, "n": 2}]}];

var hqPuzzleIndex = 0;
var hqPuzzle = null;
var hqBridges = {}; // "i-j"（岛屿下标对） -> 1 或 2
var hqOver = false;
var hqErrorCount = 0;
var hqSfxClicks = 0;
var hqSfxWins = 0;

// ---- WebAudio 合成音效（无音频文件） ----
var hqAudioCtx = null;
function hqAudio() {
  if (typeof AudioContext === "undefined" && typeof webkitAudioContext === "undefined") return null;
  if (!hqAudioCtx) {
    var AC = (typeof AudioContext !== "undefined") ? AudioContext : webkitAudioContext;
    try { hqAudioCtx = new AC(); } catch (e) { return null; }
  }
  if (hqAudioCtx.state === "suspended") { hqAudioCtx.resume(); }
  return hqAudioCtx;
}
function hqTone(freq, dur, delay, type, gain) {
  var ctx = hqAudio();
  if (!ctx) return;
  var t = ctx.currentTime + (delay || 0);
  var osc = ctx.createOscillator();
  var g = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(gain || 0.12, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}
var sfx = {
  click: function () { hqSfxClicks++; hqTone(1800, 0.05, 0, "square", 0.05); },
  error: function () { hqTone(160, 0.18, 0, "sawtooth", 0.08); },
  win: function () { hqSfxWins++; hqTone(523, 0.14, 0, "sine", 0.12); hqTone(659, 0.14, 0.12, "sine", 0.12); hqTone(784, 0.26, 0.24, "sine", 0.12); }
};

function hqEl(id) { return document.getElementById(id); }
var HQ_CELL = 62, HQ_PAD = 46;
function hqPos(r, c) { return [HQ_PAD + c * HQ_CELL, HQ_PAD + r * HQ_CELL]; }

function hqCanConnect(i, j) {
  var a = hqPuzzle.islands[i], b = hqPuzzle.islands[j];
  if (a.r === b.r) {
    var lo = Math.min(a.c, b.c), hi = Math.max(a.c, b.c);
    for (var k = 0; k < hqPuzzle.islands.length; k++) {
      if (k === i || k === j) continue;
      var o = hqPuzzle.islands[k];
      if (o.r === a.r && o.c > lo && o.c < hi) return false;
    }
    return "h";
  }
  if (a.c === b.c) {
    var lo2 = Math.min(a.r, b.r), hi2 = Math.max(a.r, b.r);
    for (var k2 = 0; k2 < hqPuzzle.islands.length; k2++) {
      if (k2 === i || k2 === j) continue;
      var o2 = hqPuzzle.islands[k2];
      if (o2.c === a.c && o2.r > lo2 && o2.r < hi2) return false;
    }
    return "v";
  }
  return false;
}

function hqBridgeKey(i, j) { return i < j ? i + "-" + j : j + "-" + i; }

function hqBridgesCross(i1, j1, i2, j2) {
  var a = hqPuzzle.islands[i1], b = hqPuzzle.islands[j1];
  var c = hqPuzzle.islands[i2], d = hqPuzzle.islands[j2];
  var aH = a.r === b.r, cH = c.r === d.r;
  if (aH === cH) return false;
  var h = aH ? [a, b] : [c, d];
  var v = aH ? [c, d] : [a, b];
  var hY = h[0].r;
  var vX = v[0].c;
  var hXLo = Math.min(h[0].c, h[1].c), hXHi = Math.max(h[0].c, h[1].c);
  var vYLo = Math.min(v[0].r, v[1].r), vYHi = Math.max(v[0].r, v[1].r);
  return hY > vYLo && hY < vYHi && vX > hXLo && vX < hXHi;
}

function hqErrors() {
  var errs = {};
  var size = 0;
  hqPuzzle.islands.forEach(function (isl, i) {
    var count = 0;
    Object.keys(hqBridges).forEach(function (k) {
      var ab = k.split("-");
      var a = Number(ab[0]), b = Number(ab[1]);
      if (a === i || b === i) count += hqBridges[k];
    });
    if (count > isl.n) { errs["island-" + i] = true; size++; }
  });
  var keys = Object.keys(hqBridges);
  for (var x = 0; x < keys.length; x++) {
    for (var y = x + 1; y < keys.length; y++) {
      var p1 = keys[x].split("-"), p2 = keys[y].split("-");
      if (hqBridgesCross(Number(p1[0]), Number(p1[1]), Number(p2[0]), Number(p2[1]))) {
        if (!errs[keys[x]]) { errs[keys[x]] = true; size++; }
        if (!errs[keys[y]]) { errs[keys[y]] = true; size++; }
      }
    }
  }
  return { set: errs, size: size };
}

function hqRender() {
  var svgEl = hqEl("hq-svg");
  var NS = "http://www.w3.org/2000/svg";
  svgEl.innerHTML = "";
  var errs = hqErrors();
  // 桥（先画可见线，岛屿盖在上面）
  Object.keys(hqBridges).forEach(function (k) {
    var n = hqBridges[k];
    var ab = k.split("-");
    var a = hqPuzzle.islands[Number(ab[0])], b = hqPuzzle.islands[Number(ab[1])];
    var pa = hqPos(a.r, a.c);
    var pb = hqPos(b.r, b.c);
    var isErr = !!errs.set[k];
    for (var layer = 0; layer < n; layer++) {
      var offset = (layer - (n - 1) / 2) * 9;
      var ln = document.createElementNS(NS, "line");
      if (a.r === b.r) {
        ln.setAttribute("x1", pa[0]);
        ln.setAttribute("y1", pa[1] + offset);
        ln.setAttribute("x2", pb[0]);
        ln.setAttribute("y2", pb[1] + offset);
      } else {
        ln.setAttribute("x1", pa[0] + offset);
        ln.setAttribute("y1", pa[1]);
        ln.setAttribute("x2", pb[0] + offset);
        ln.setAttribute("y2", pb[1]);
      }
      ln.setAttribute("stroke", isErr ? "#ff7a5c" : "#f5f0e6");
      ln.setAttribute("stroke-width", "4");
      ln.setAttribute("stroke-linecap", "round");
      svgEl.appendChild(ln);
    }
  });
  // 岛屿（沙色圆 + 深棕数字；超数标朱红）
  hqPuzzle.islands.forEach(function (isl, i) {
    var p = hqPos(isl.r, isl.c);
    var isErr = !!errs.set["island-" + i];
    var circle = document.createElementNS(NS, "circle");
    circle.setAttribute("cx", p[0]);
    circle.setAttribute("cy", p[1]);
    circle.setAttribute("r", 23);
    circle.setAttribute("fill", isErr ? "#e05a3a" : "#f2d492");
    circle.setAttribute("stroke", "#d9b96a");
    circle.setAttribute("stroke-width", "2");
    svgEl.appendChild(circle);
    var txt = document.createElementNS(NS, "text");
    txt.setAttribute("x", p[0]);
    txt.setAttribute("y", p[1] + 7);
    txt.setAttribute("text-anchor", "middle");
    txt.setAttribute("fill", isErr ? "#ffffff" : "#5a3d1e");
    txt.setAttribute("font-size", "20");
    txt.setAttribute("font-weight", "bold");
    txt.textContent = isl.n;
    svgEl.appendChild(txt);
  });
  // 透明粗线热区（最后画，始终在最上层）
  for (var i = 0; i < hqPuzzle.islands.length; i++) {
    for (var j = i + 1; j < hqPuzzle.islands.length; j++) {
      if (!hqCanConnect(i, j)) continue;
      (function (i, j) {
        var a = hqPuzzle.islands[i], b = hqPuzzle.islands[j];
        var pa = hqPos(a.r, a.c);
        var pb = hqPos(b.r, b.c);
        var hit = document.createElementNS(NS, "line");
        hit.setAttribute("x1", pa[0]);
        hit.setAttribute("y1", pa[1]);
        hit.setAttribute("x2", pb[0]);
        hit.setAttribute("y2", pb[1]);
        hit.setAttribute("stroke", "transparent");
        hit.setAttribute("stroke-width", "34");
        hit.setAttribute("data-bridge", hqBridgeKey(i, j));
        hit.style.cursor = "pointer";
        hit.addEventListener("click", function () {
          if (hqOver) return;
          var k = hqBridgeKey(i, j);
          var cur = hqBridges[k] || 0;
          if (cur === 0) hqBridges[k] = 1;
          else if (cur === 1) hqBridges[k] = 2;
          else delete hqBridges[k];
          if (typeof sfx !== "undefined") sfx.click();
          hqRender();
        });
        svgEl.appendChild(hit);
      })(i, j);
    }
  }
  var total = 0;
  for (var kk in hqBridges) total += hqBridges[kk];
  hqEl("hq-bridges").textContent = total;
  hqErrorCount = errs.size;
  hqEl("hq-errors").textContent = errs.size;
}

function hqSetStatus(text, cls) {
  var el = hqEl("hq-status");
  el.textContent = text;
  el.className = "status " + cls;
}

function hqCheck() {
  if (hqOver) return;
  var errs = hqErrors();
  if (errs.size > 0) {
    if (typeof sfx !== "undefined") sfx.error();
    hqSetStatus("有 " + errs.size + " 处错误（超数或交叉），先把红的改掉", "lose");
    return;
  }
  for (var i = 0; i < hqPuzzle.islands.length; i++) {
    var count = 0;
    Object.keys(hqBridges).forEach(function (k) {
      var ab = k.split("-");
      if (Number(ab[0]) === i || Number(ab[1]) === i) count += hqBridges[k];
    });
    if (count !== hqPuzzle.islands[i].n) {
      if (typeof sfx !== "undefined") sfx.error();
      hqSetStatus("第 " + (hqPuzzle.islands[i].r + 1) + " 行第 " + (hqPuzzle.islands[i].c + 1) + " 列的岛需要 " + hqPuzzle.islands[i].n + " 座桥，现在有 " + count + " 座", "lose");
      return;
    }
  }
  var adj = {};
  hqPuzzle.islands.forEach(function (_, idx) { adj[idx] = []; });
  Object.keys(hqBridges).forEach(function (k) {
    var ab = k.split("-");
    adj[Number(ab[0])].push(Number(ab[1]));
    adj[Number(ab[1])].push(Number(ab[0]));
  });
  var visited = { 0: true };
  var q = [0];
  var visitedCount = 1;
  while (q.length) {
    var cur = q.shift();
    adj[cur].forEach(function (n) {
      if (!visited[n]) {
        visited[n] = true;
        visitedCount++;
        q.push(n);
      }
    });
  }
  if (visitedCount !== hqPuzzle.islands.length) {
    if (typeof sfx !== "undefined") sfx.error();
    hqSetStatus("岛屿还没全部连通", "lose");
    return;
  }
  hqOver = true;
  if (typeof sfx !== "undefined") sfx.win();
  hqSetStatus("通关！所有岛屿连通了，点「换一题」继续。", "win");
}

function hqNewGame(idx) {
  hqPuzzleIndex = ((idx % HQ_PUZZLES.length) + HQ_PUZZLES.length) % HQ_PUZZLES.length;
  hqPuzzle = JSON.parse(JSON.stringify(HQ_PUZZLES[hqPuzzleIndex]));
  hqBridges = {};
  hqOver = false;
  hqEl("puzzleLabel").textContent = "第 " + (hqPuzzleIndex + 1) + " / " + HQ_PUZZLES.length + " 题";
  hqSetStatus("点两个岛屿之间搭桥，把所有岛连成一片。", "info");
  hqRender();
}

hqEl("hq-check").addEventListener("click", hqCheck);
hqEl("hq-clear").addEventListener("click", function () {
  if (hqOver) return;
  hqBridges = {};
  if (typeof sfx !== "undefined") sfx.click();
  hqSetStatus("已清空，重新搭吧。", "info");
  hqRender();
});
hqEl("hq-next").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  hqNewGame(hqPuzzleIndex + 1);
});
hqEl("hq-help").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  hqEl("hq-mask").style.display = "block";
});
hqEl("hq-help-close").addEventListener("click", function () {
  hqEl("hq-mask").style.display = "none";
});
hqEl("hq-mask").addEventListener("click", function (e) {
  if (e.target === hqEl("hq-mask")) hqEl("hq-mask").style.display = "none";
});

var HQ = {
  getState: function () {
    var total = 0;
    for (var k in hqBridges) total += hqBridges[k];
    return {
      puzzleIndex: hqPuzzleIndex,
      puzzleCount: HQ_PUZZLES.length,
      bridges: total,
      errors: hqErrorCount,
      solved: hqOver,
      helpVisible: hqEl("hq-mask").style.display === "block",
      sfxClicks: hqSfxClicks,
      sfxWins: hqSfxWins
    };
  }
};

hqNewGame(0);
