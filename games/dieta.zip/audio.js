/* 叠塔 · Web Audio 合成音效，无音频文件 */
window.SoundEngine = (function () {
  var ctx = null;
  var enabled = true;

  function ensure() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (AC) ctx = new AC();
    }
    if (ctx && ctx.state === "suspended") ctx.resume();
    return ctx;
  }

  function tone(freq, dur, type, gain, delay, slideTo) {
    if (!ctx) return;
    var t = ctx.currentTime + (delay || 0);
    var osc = ctx.createOscillator();
    var g = ctx.createGain();
    osc.type = type || "triangle";
    osc.frequency.setValueAtTime(freq, t);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain || 0.06, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  return {
    unlock: function () { ensure(); },
    setEnabled: function (v) {
      enabled = !!v;
      if (enabled) tone(660, 0.06, "square", 0.04);
    },
    isEnabled: function () { return enabled; },
    start: function () {
      if (!enabled || !ensure()) return;
      tone(523, 0.09, "triangle", 0.06, 0);
      tone(784, 0.14, "triangle", 0.06, 0.09);
    },
    place: function () {
      if (!enabled || !ensure()) return;
      tone(190, 0.09, "triangle", 0.09, 0, 120);
    },
    perfect: function () {
      if (!enabled || !ensure()) return;
      tone(880, 0.1, "sine", 0.07, 0);
      tone(1318, 0.18, "sine", 0.07, 0.09);
    },
    fail: function () {
      if (!enabled || !ensure()) return;
      tone(392, 0.15, "triangle", 0.06, 0);
      tone(262, 0.3, "triangle", 0.06, 0.16);
    }
  };
})();
