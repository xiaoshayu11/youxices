/* 纯 WebAudio 合成音效（无音频文件）。
 * 顶层 var sfx；调用处一律用 typeof sfx !== 'undefined' 做守卫。
 * 每种音效内部节流：同一音效在节流窗内重复触发只响一次（开火连续触发时防刷屏）。 */
var sfx = (function () {
  'use strict';
  var ctx = null;
  var lastPlay = {};
  function ensure() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }
  function tone(freq0, freq1, dur, type, vol, when) {
    var ac = ensure();
    if (!ac) return;
    var t0 = ac.currentTime + (when || 0);
    var o = ac.createOscillator();
    var g = ac.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq0, t0);
    if (freq1 && freq1 !== freq0) o.frequency.exponentialRampToValueAtTime(Math.max(freq1, 1), t0 + dur);
    g.gain.setValueAtTime(vol || 0.15, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    o.connect(g);
    g.connect(ac.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }
  function throttle(name, ms) {
    var now = Date.now();
    if (lastPlay[name] && now - lastPlay[name] < ms) return false;
    lastPlay[name] = now;
    return true;
  }
  return {
    build: function () { if (!throttle('build', 150)) return; tone(420, 660, 0.14, 'triangle', 0.18); },
    upgrade: function () { if (!throttle('upgrade', 200)) return; tone(520, 780, 0.12, 'triangle', 0.16); tone(780, 1040, 0.14, 'triangle', 0.16, 0.09); },
    sell: function () { if (!throttle('sell', 200)) return; tone(880, 660, 0.1, 'sine', 0.15); tone(660, 990, 0.12, 'sine', 0.15, 0.08); },
    shoot: function () { if (!throttle('shoot', 120)) return; tone(700, 320, 0.07, 'square', 0.07); },
    leak: function () { if (!throttle('leak', 200)) return; tone(320, 90, 0.35, 'sawtooth', 0.14); },
    wave: function () { if (!throttle('wave', 300)) return; tone(392, 392, 0.12, 'triangle', 0.16); tone(523, 523, 0.16, 'triangle', 0.16, 0.12); },
    win: function () { if (!throttle('win', 500)) return; tone(523, 523, 0.14, 'triangle', 0.17); tone(659, 659, 0.14, 'triangle', 0.17, 0.13); tone(784, 784, 0.22, 'triangle', 0.17, 0.26); },
    lose: function () { if (!throttle('lose', 500)) return; tone(392, 330, 0.2, 'sine', 0.17); tone(330, 196, 0.35, 'sine', 0.17, 0.18); }
  };
})();
