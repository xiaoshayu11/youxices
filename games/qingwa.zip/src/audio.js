/* 纯 WebAudio 合成音效（无音频文件）。
 * 顶层 var sfx；调用处一律用 typeof sfx !== 'undefined' 做守卫。
 * 每种音效内部节流：同一音效在节流窗内重复触发只响一次。 */
var sfx = (function () {
  'use strict';
  var ctx = null;
  var lastPlay = {};
  function ensure() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }
  function tone(freq0, freq1, dur, type, vol, delay) {
    var ac = ensure();
    if (!ac) return;
    var t0 = ac.currentTime + (delay || 0);
    var o = ac.createOscillator();
    var g = ac.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq0, t0);
    if (freq1 && freq1 !== freq0) o.frequency.exponentialRampToValueAtTime(Math.max(freq1, 1), t0 + dur);
    g.gain.setValueAtTime(vol || 0.15, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    o.connect(g);
    g.connect(ac.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }
  function throttle(name, ms) {
    var now = Date.now();
    if (lastPlay[name] && now - lastPlay[name] < ms) return false;
    lastPlay[name] = now;
    return true;
  }
  return {
    hop: function () { if (!throttle('hop', 80)) return; tone(500, 900, 0.09, 'triangle', 0.16); },
    death: function () { if (!throttle('death', 200)) return; tone(400, 80, 0.35, 'sine', 0.18); },
    home: function () { if (!throttle('home', 200)) return; tone(660, 990, 0.2, 'triangle', 0.18); },
    win: function () { if (!throttle('win', 500)) return; tone(523, 523, 0.12, 'triangle', 0.18); tone(659, 659, 0.12, 'triangle', 0.18, 0.12); tone(784, 784, 0.22, 'triangle', 0.18, 0.24); },
    warn: function () { if (!throttle('warn', 500)) return; tone(880, 880, 0.09, 'square', 0.1); tone(880, 880, 0.09, 'square', 0.1, 0.16); }
  };
})();
