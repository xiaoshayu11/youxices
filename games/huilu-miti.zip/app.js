/* 回路谜题（Slitherlink）：点边画线，围成单一闭合回路，数字为四周回路边数。
   算法（边切换/冲突计数/检查判定）沿用上游 Pixel-Arcade slitherlink.js，仅汉化与换主题。 */
var HL_PUZZLES = [{"clues": [[-1, 1, -1, 1], [1, 0, -1, 1], [-1, 0, 1, 1], [2, 1, 2, -1]], "sol": ["0,0,1,0", "1,0,2,0", "2,0,3,0", "3,0,4,0", "4,0,4,1", "4,1,4,2", "4,2,4,3", "3,3,4,3", "2,3,3,3", "1,3,2,3", "0,3,1,3", "0,2,0,3", "0,1,0,2", "0,0,0,1"]}, {"clues": [[2, -1, 1, -1], [1, 0, 0, 1], [2, 1, -1, -1], [-1, 1, 1, 1]], "sol": ["0,3,0,4", "0,2,0,3", "0,1,0,2", "0,0,0,1", "0,0,1,0", "1,0,2,0", "2,0,3,0", "3,0,3,1", "3,1,3,2", "3,2,3,3", "3,3,3,4", "2,4,3,4", "1,4,2,4", "0,4,1,4"]}, {"clues": [[-1, 2, 1, 2], [1, 1, 0, -1], [1, -1, 0, 1], [1, -1, 1, -1]], "sol": ["3,4,4,4", "2,4,3,4", "1,4,2,4", "0,4,1,4", "0,3,0,4", "0,2,0,3", "0,1,0,2", "0,1,1,1", "1,1,2,1", "2,1,3,1", "3,1,4,1", "4,1,4,2", "4,2,4,3", "4,3,4,4"]}, {"clues": [[1, 1, 1, -1], [-1, -1, 1, 2], [1, 0, 0, 1], [-1, 1, -1, 2]], "sol": ["4,0,4,1", "4,1,4,2", "4,2,4,3", "4,3,4,4", "3,4,4,4", "2,4,3,4", "1,4,2,4", "1,3,1,4", "1,2,1,3", "1,1,1,2", "1,0,1,1", "1,0,2,0", "2,0,3,0", "3,0,4,0"]}, {"clues": [[1, -1, 1, -1], [1, -1, 0, 1], [1, 1, 0, -1], [-1, 2, 1, 2]], "sol": ["0,4,1,4", "1,4,2,4", "2,4,3,4", "3,4,4,4", "4,3,4,4", "4,2,4,3", "4,1,4,2", "3,1,4,1", "2,1,3,1", "1,1,2,1", "0,1,1,1", "0,1,0,2", "0,2,0,3", "0,3,0,4"]}, {"clues": [[2, 1, 2, -1], [-1, 0, 1, 1], [1, 0, -1, 1], [-1, 1, -1, 1]], "sol": ["3,0,4,0", "2,0,3,0", "1,0,2,0", "0,0,1,0", "0,0,0,1", "0,1,0,2", "0,2,0,3", "0,3,1,3", "1,3,2,3", "2,3,3,3", "3,3,4,3", "4,2,4,3", "4,1,4,2", "4,0,4,1"]}, {"clues": [[-1, 1, -1, 2], [1, 0, 0, 1], [-1, -1, 1, 2], [1, 1, 1, -1]], "sol": ["0,0,0,1", "0,1,0,2", "0,2,0,3", "0,3,0,4", "0,4,1,4", "1,4,2,4", "2,4,3,4", "3,3,3,4", "3,2,3,3", "3,1,3,2", "3,0,3,1", "2,0,3,0", "1,0,2,0", "0,0,1,0"]}, {"clues": [[-1, 1, 1, 1], [2, 1, -1, -1], [1, 0, 0, 1], [2, -1, 1, -1]], "sol": ["4,3,4,4", "4,2,4,3", "4,1,4,2", "4,0,4,1", "3,0,4,0", "2,0,3,0", "1,0,2,0", "1,0,1,1", "1,1,1,2", "1,2,1,3", "1,3,1,4", "1,4,2,4", "2,4,3,4", "3,4,4,4"]}, {"clues": [[0, 1, 1, 1], [1, 2, -1, 2], [1, 1, 0, -1], [-1, 2, -1, 2]], "sol": ["1,1,2,1", "2,1,3,1", "3,1,4,1", "4,1,4,2", "4,2,4,3", "3,3,4,3", "3,3,3,4", "2,4,3,4", "1,4,2,4", "1,3,1,4", "1,2,1,3", "1,1,1,2"]}, {"clues": [[-1, 1, 1, 0], [2, 1, 2, 1], [-1, 0, -1, 1], [2, -1, 2, 1]], "sol": ["1,2,1,3", "1,1,1,2", "1,0,1,1", "1,0,2,0", "2,0,3,0", "3,0,3,1", "3,1,4,1", "4,1,4,2", "4,2,4,3", "3,3,4,3", "2,3,3,3", "1,3,2,3"]}, {"clues": [[2, -1, 2, -1], [-1, 0, 1, 1], [2, -1, 2, 1], [1, 1, 1, 0]], "sol": ["2,3,3,3", "1,3,2,3", "0,3,1,3", "0,2,0,3", "0,1,0,2", "0,1,1,1", "1,0,1,1", "1,0,2,0", "2,0,3,0", "3,0,3,1", "3,1,3,2", "3,2,3,3"]}, {"clues": [[1, 2, -1, 2], [1, -1, 0, -1], [1, 2, 1, 2], [0, 1, 1, -1]], "sol": ["3,1,3,2", "3,2,3,3", "3,3,3,4", "2,4,3,4", "1,4,2,4", "1,3,1,4", "0,3,1,3", "0,2,0,3", "0,1,0,2", "0,1,1,1", "1,1,2,1", "2,1,3,1"]}, {"clues": [[1, 1, 1, 0], [2, -1, 2, 1], [-1, 0, 1, 1], [2, -1, 2, -1]], "sol": ["1,3,2,3", "2,3,3,3", "3,3,4,3", "4,2,4,3", "4,1,4,2", "3,1,4,1", "3,0,3,1", "2,0,3,0", "1,0,2,0", "1,0,1,1", "1,1,1,2", "1,2,1,3"]}, {"clues": [[-1, 2, -1, 2], [1, 1, 0, -1], [1, 2, -1, 2], [0, 1, 1, 1]], "sol": ["2,1,3,1", "1,1,2,1", "0,1,1,1", "0,1,0,2", "0,2,0,3", "0,3,1,3", "1,3,1,4", "1,4,2,4", "2,4,3,4", "3,3,3,4", "3,2,3,3", "3,1,3,2"]}, {"clues": [[0, 1, 1, -1], [1, 2, 1, 2], [1, -1, 0, -1], [1, 2, -1, 2]], "sol": ["1,1,1,2", "1,2,1,3", "1,3,1,4", "1,4,2,4", "2,4,3,4", "3,3,3,4", "3,3,4,3", "4,2,4,3", "4,1,4,2", "3,1,4,1", "2,1,3,1", "1,1,2,1"]}, {"clues": [[2, -1, 2, 1], [-1, 0, -1, 1], [2, 1, 2, 1], [-1, 1, 1, 0]], "sol": ["3,2,3,3", "3,1,3,2", "3,0,3,1", "2,0,3,0", "1,0,2,0", "1,0,1,1", "0,1,1,1", "0,1,0,2", "0,2,0,3", "0,3,1,3", "1,3,2,3", "2,3,3,3"]}];
var HL_N = 4; // 4x4 线索格；5x5 点阵

var hlPuzzleIndex = 0;
var hlPuzzle = null;
var hlEdges = {}; // "r1,c1,r2,c2" -> 0/1
var hlOver = false;
var hlConflicts = 0;
var hlSfxClicks = 0;
var hlSfxWins = 0;

// ---- WebAudio 合成音效（无音频文件） ----
var hlAudioCtx = null;
function hlAudio() {
  if (typeof AudioContext === "undefined" && typeof webkitAudioContext === "undefined") return null;
  if (!hlAudioCtx) {
    var AC = (typeof AudioContext !== "undefined") ? AudioContext : webkitAudioContext;
    try { hlAudioCtx = new AC(); } catch (e) { return null; }
  }
  if (hlAudioCtx.state === "suspended") { hlAudioCtx.resume(); }
  return hlAudioCtx;
}
function hlTone(freq, dur, delay, type, gain) {
  var ctx = hlAudio();
  if (!ctx) return;
  var t = ctx.currentTime + (delay || 0);
  var osc = ctx.createOscillator();
  var g = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(gain || 0.12, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}
var sfx = {
  click: function () { hlSfxClicks++; hlTone(1800, 0.05, 0, "square", 0.05); },
  error: function () { hlTone(160, 0.18, 0, "sawtooth", 0.08); },
  win: function () { hlSfxWins++; hlTone(523, 0.14, 0, "sine", 0.12); hlTone(659, 0.14, 0.12, "sine", 0.12); hlTone(784, 0.26, 0.24, "sine", 0.12); }
};

function hlEl(id) { return document.getElementById(id); }
function hlEdgeKey(r1, c1, r2, c2) { return r1 + "," + c1 + "," + r2 + "," + c2; }
var HL_CELL = 68, HL_PAD = 34;
function hlDotPos(r, c) { return [HL_PAD + c * HL_CELL, HL_PAD + r * HL_CELL]; }

function hlRender() {
  var svgEl = hlEl("hl-svg");
  var NS = "http://www.w3.org/2000/svg";
  svgEl.innerHTML = "";
  // 点阵
  for (var r = 0; r <= HL_N; r++) {
    for (var c = 0; c <= HL_N; c++) {
      var pos = hlDotPos(r, c);
      var dot = document.createElementNS(NS, "circle");
      dot.setAttribute("cx", pos[0]);
      dot.setAttribute("cy", pos[1]);
      dot.setAttribute("r", 4);
      dot.setAttribute("fill", "#8a8578");
      svgEl.appendChild(dot);
    }
  }
  // 线索数字（四周已画边数超过数字时标朱红）
  for (var r2 = 0; r2 < HL_N; r2++) {
    for (var c2 = 0; c2 < HL_N; c2++) {
      var v = hlPuzzle.clues[r2][c2];
      if (v < 0) continue;
      var around0 = [
        hlEdgeKey(r2, c2, r2, c2 + 1),
        hlEdgeKey(r2 + 1, c2, r2 + 1, c2 + 1),
        hlEdgeKey(r2, c2, r2 + 1, c2),
        hlEdgeKey(r2, c2 + 1, r2 + 1, c2 + 1)
      ];
      var cnt0 = 0;
      for (var a = 0; a < 4; a++) if (hlEdges[around0[a]] === 1) cnt0++;
      var p2 = hlDotPos(r2, c2);
      var txt = document.createElementNS(NS, "text");
      txt.setAttribute("x", p2[0] + HL_CELL / 2);
      txt.setAttribute("y", p2[1] + HL_CELL / 2 + 9);
      txt.setAttribute("text-anchor", "middle");
      txt.setAttribute("fill", cnt0 > v ? "#c8402a" : "#5a5346");
      txt.setAttribute("font-size", "26");
      txt.setAttribute("font-weight", "bold");
      txt.textContent = v;
      svgEl.appendChild(txt);
    }
  }
  // 边（透明粗线热区 + 墨蓝可见线）
  function drawEdge(r1, c1, r2, c2) {
    var k = hlEdgeKey(r1, c1, r2, c2);
    var pa = hlDotPos(r1, c1);
    var pb = hlDotPos(r2, c2);
    if (hlEdges[k] === 1) {
      var ln = document.createElementNS(NS, "line");
      ln.setAttribute("x1", pa[0]);
      ln.setAttribute("y1", pa[1]);
      ln.setAttribute("x2", pb[0]);
      ln.setAttribute("y2", pb[1]);
      ln.setAttribute("stroke", "#2b3a55");
      ln.setAttribute("stroke-width", "5");
      ln.setAttribute("stroke-linecap", "round");
      svgEl.appendChild(ln);
    }
    var hit = document.createElementNS(NS, "line");
    hit.setAttribute("x1", pa[0]);
    hit.setAttribute("y1", pa[1]);
    hit.setAttribute("x2", pb[0]);
    hit.setAttribute("y2", pb[1]);
    hit.setAttribute("stroke", "transparent");
    hit.setAttribute("stroke-width", "30");
    hit.setAttribute("data-edge", k);
    hit.style.cursor = "pointer";
    hit.addEventListener("click", function () {
      if (hlOver) return;
      var cur = hlEdges[k] || 0;
      hlEdges[k] = (cur + 1) % 2;
      if (typeof sfx !== "undefined") sfx.click();
      hlRender();
    });
    svgEl.appendChild(hit);
  }
  for (var r3 = 0; r3 <= HL_N; r3++) {
    for (var c3 = 0; c3 <= HL_N; c3++) {
      if (c3 < HL_N) drawEdge(r3, c3, r3, c3 + 1);
      if (r3 < HL_N) drawEdge(r3, c3, r3 + 1, c3);
    }
  }
  // 计分板：已画边 + 冲突（线索格四周边数与数字不符的格数，沿用上游口径）
  var onEdges = 0;
  for (var kk in hlEdges) if (hlEdges[kk] === 1) onEdges++;
  hlEl("hl-edges").textContent = onEdges;
  var conflicts = 0;
  for (var r4 = 0; r4 < HL_N; r4++) {
    for (var c4 = 0; c4 < HL_N; c4++) {
      var v4 = hlPuzzle.clues[r4][c4];
      if (v4 < 0) continue;
      var around = [
        hlEdgeKey(r4, c4, r4, c4 + 1),
        hlEdgeKey(r4 + 1, c4, r4 + 1, c4 + 1),
        hlEdgeKey(r4, c4, r4 + 1, c4),
        hlEdgeKey(r4, c4 + 1, r4 + 1, c4 + 1)
      ];
      var count = 0;
      for (var b = 0; b < 4; b++) if (hlEdges[around[b]] === 1) count++;
      if (count !== v4) conflicts++;
    }
  }
  hlConflicts = conflicts;
  hlEl("hl-conflicts").textContent = conflicts;
}

function hlSetStatus(text, cls) {
  var el = hlEl("hl-status");
  el.textContent = text;
  el.className = "status " + cls;
}

function hlCheck() {
  if (hlOver) return;
  // 1) 线索计数
  for (var r = 0; r < HL_N; r++) {
    for (var c = 0; c < HL_N; c++) {
      var v = hlPuzzle.clues[r][c];
      if (v < 0) continue;
      var around = [hlEdgeKey(r, c, r, c + 1), hlEdgeKey(r + 1, c, r + 1, c + 1), hlEdgeKey(r, c, r + 1, c), hlEdgeKey(r, c + 1, r + 1, c + 1)];
      var count = 0;
      for (var i = 0; i < 4; i++) if (hlEdges[around[i]] === 1) count++;
      if (count !== v) {
        if (typeof sfx !== "undefined") sfx.error();
        hlSetStatus("第 " + (r + 1) + " 行第 " + (c + 1) + " 格应有 " + v + " 条边，现在有 " + count + " 条", "lose");
        return;
      }
    }
  }
  // 2) 每点度数须为 2
  var dotDegrees = {};
  for (var k in hlEdges) {
    if (hlEdges[k] !== 1) continue;
    var parts = k.split(",");
    var d1 = parts[0] + "," + parts[1], d2 = parts[2] + "," + parts[3];
    dotDegrees[d1] = (dotDegrees[d1] || 0) + 1;
    dotDegrees[d2] = (dotDegrees[d2] || 0) + 1;
  }
  var badDots = 0;
  for (var d in dotDegrees) if (dotDegrees[d] !== 2) badDots++;
  if (badDots > 0) {
    if (typeof sfx !== "undefined") sfx.error();
    hlSetStatus("有 " + badDots + " 个点连着的边不是 2 条，回路还没闭合", "lose");
    return;
  }
  // 3) 单一连通回路（BFS，沿用上游）
  var onDots = Object.keys(dotDegrees);
  if (onDots.length === 0) {
    if (typeof sfx !== "undefined") sfx.error();
    hlSetStatus("先画几条边再检查", "lose");
    return;
  }
  var visited = {};
  visited[onDots[0]] = true;
  var queue = [onDots[0]];
  var visitedCount = 1;
  while (queue.length) {
    var cur = queue.shift();
    var rc = cur.split(",");
    var cr = Number(rc[0]), cc = Number(rc[1]);
    var dirs = [[-1, 0], [1, 0], [0, -1], [0, 1]];
    for (var di = 0; di < 4; di++) {
      var dr = dirs[di][0], dc = dirs[di][1];
      var nr = cr + dr, nc = cc + dc;
      var ek = dr === -1 ? hlEdgeKey(nr, nc, cr, cc) : dr === 1 ? hlEdgeKey(cr, cc, nr, nc) : dc === -1 ? hlEdgeKey(cr, nc, cr, cc) : hlEdgeKey(cr, cc, cr, nc);
      if (hlEdges[ek] === 1) {
        var nd = nr + "," + nc;
        if (!visited[nd]) {
          visited[nd] = true;
          visitedCount++;
          queue.push(nd);
        }
      }
    }
  }
  if (visitedCount !== onDots.length) {
    if (typeof sfx !== "undefined") sfx.error();
    hlSetStatus("回路没有连成一条，还有分开的圈", "lose");
    return;
  }
  hlOver = true;
  if (typeof sfx !== "undefined") sfx.win();
  hlSetStatus("通关！回路完成了，点「换一题」继续。", "win");
}

function hlNewGame(idx) {
  hlPuzzleIndex = ((idx % HL_PUZZLES.length) + HL_PUZZLES.length) % HL_PUZZLES.length;
  hlPuzzle = JSON.parse(JSON.stringify(HL_PUZZLES[hlPuzzleIndex]));
  hlEdges = {};
  hlOver = false;
  hlEl("puzzleLabel").textContent = "第 " + (hlPuzzleIndex + 1) + " / " + HL_PUZZLES.length + " 题";
  hlSetStatus("点两点之间的边画线，围成一条单一闭合回路。", "info");
  hlRender();
}

hlEl("hl-check").addEventListener("click", hlCheck);
hlEl("hl-clear").addEventListener("click", function () {
  if (hlOver) return;
  hlEdges = {};
  if (typeof sfx !== "undefined") sfx.click();
  hlSetStatus("已清空，重新画吧。", "info");
  hlRender();
});
hlEl("hl-next").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  hlNewGame(hlPuzzleIndex + 1);
});
hlEl("hl-help").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  hlEl("hl-mask").style.display = "block";
});
hlEl("hl-help-close").addEventListener("click", function () {
  hlEl("hl-mask").style.display = "none";
});
hlEl("hl-mask").addEventListener("click", function (e) {
  if (e.target === hlEl("hl-mask")) hlEl("hl-mask").style.display = "none";
});

var HL = {
  getState: function () {
    var on = 0;
    for (var k in hlEdges) if (hlEdges[k] === 1) on++;
    return {
      puzzleIndex: hlPuzzleIndex,
      puzzleCount: HL_PUZZLES.length,
      edgesOn: on,
      conflicts: hlConflicts,
      solved: hlOver,
      helpVisible: hlEl("hl-mask").style.display === "block",
      sfxClicks: hlSfxClicks,
      sfxWins: hlSfxWins
    };
  }
};

hlNewGame(0);
