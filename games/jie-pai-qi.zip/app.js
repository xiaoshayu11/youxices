var audioContext = null;
var unlocked = false;
var isPlaying = false;      // Are we currently playing?
var startTime;              // The start time of the entire sequence.
var current16thNote;        // What note is currently last scheduled?
var tempo = 120.0;          // tempo (in beats per minute)
var lookahead = 25.0;       // How frequently to call scheduling function 
                            //(in milliseconds)
var scheduleAheadTime = 0.1;    // How far ahead to schedule audio (sec)
                            // This is calculated from lookahead, and overlaps 
                            // with next interval (in case the timer is late)
var nextNoteTime = 0.0;     // when the next note is due.
var noteResolution = 2;     // 0 == 16th, 1 == 8th, 2 == quarter note
var noteLength = 0.08;      // length of "beep" (in seconds)
var canvas,                 // the canvas element
    canvasContext;          // canvasContext is the canvas' context 2D
var last16thNoteDrawn = -1; // the last "box" we drew on the screen
var notesInQueue = [];      // the notes that have been put into the web audio,
                            // and may or may not have played yet. {note, time}
var timerWorker = null;     // The Web Worker used to fire timer messages


// First, let's shim the requestAnimationFrame API, with a setTimeout fallback
window.requestAnimFrame = window.requestAnimationFrame;

function nextNote() {
    // Advance current note and time by a 16th note...
    var secondsPerBeat = 60.0 / tempo;    // Notice this picks up the CURRENT 
                                          // tempo value to calculate beat length.
    nextNoteTime += 0.25 * secondsPerBeat;    // Add beat length to last beat time

    current16thNote++;    // Advance the beat number, wrap to zero
    if (current16thNote == 16) {
        current16thNote = 0;
    }
}

function scheduleNote( beatNumber, time ) {
    // push the note on the queue, even if we're not playing.
    notesInQueue.push( { note: beatNumber, time: time } );

    if ( (noteResolution==1) && (beatNumber%2))
        return; // we're not playing non-8th 16th notes
    if ( (noteResolution==2) && (beatNumber%4))
        return; // we're not playing non-quarter 8th notes

    // create an oscillator
    var osc = audioContext.createOscillator();
    var gainNode = audioContext.createGain();
    osc.connect( gainNode );
    gainNode.connect( audioContext.destination );
    if (beatNumber % 16 === 0)    // beat 0 == high pitch
        osc.frequency.value = 880.0;
    else if (beatNumber % 4 === 0 )    // quarter notes = medium pitch
        osc.frequency.value = 440.0;
    else                        // other 16th notes = low pitch
        osc.frequency.value = 220.0;

    gainNode.gain.setValueAtTime(0.5, time);
    gainNode.gain.exponentialRampToValueAtTime(0.001, time + noteLength);
    osc.start( time );
    osc.stop( time + noteLength + 0.02 );
}

function scheduler() {
    // while there are notes that will need to play before the next interval, 
    // schedule them and advance the pointer.
    while (nextNoteTime < audioContext.currentTime + scheduleAheadTime ) {
        scheduleNote( current16thNote, nextNoteTime );
        nextNote();
    }
}

function play() {
    if (!audioContext)
        audioContext = new AudioContext();
    if (audioContext.state === 'suspended')
        audioContext.resume();

    if (!unlocked) {
      // play silent buffer to unlock the audio
      var buffer = audioContext.createBuffer(1, 1, 22050);
      var node = audioContext.createBufferSource();
      node.buffer = buffer;
      node.start(0);
      unlocked = true;
    }

    isPlaying = !isPlaying;

    if (isPlaying) { // start playing
        current16thNote = 0;
        notesInQueue = [];
        jpBeatCount = 0;
        last16thNoteDrawn = -1;
        nextNoteTime = audioContext.currentTime;
        startTimer();
        return "stop";
    } else {
        stopTimer();
        return "play";
    }
}

var jpBeatTime = 0;      // audio time of the last quarter beat
var jpBeatCount = 0;     // quarter beats elapsed since start
var jpAngle = 0;         // current pendulum angle (rad)

function jpUpdateDots(currentNote) {
    var dots = document.querySelectorAll('.dot');
    var active = Math.floor(currentNote / 4) % 4;
    for (var i = 0; i < dots.length; i++) {
        if (i === active) dots[i].classList.add('on');
        else dots[i].classList.remove('on');
    }
}

function jpDrawPendulum(angle) {
    var W = canvas.width, H = canvas.height;
    var cx = W / 2;
    canvasContext.clearRect(0, 0, W, H);
    // case (trapezoid)
    var topW = 150, botW = 350, topY = 30, botY = H - 30;
    var grad = canvasContext.createLinearGradient(0, topY, 0, botY);
    grad.addColorStop(0, '#4a2d12');
    grad.addColorStop(1, '#241608');
    canvasContext.beginPath();
    canvasContext.moveTo(cx - topW / 2, topY);
    canvasContext.lineTo(cx + topW / 2, topY);
    canvasContext.lineTo(cx + botW / 2, botY);
    canvasContext.lineTo(cx - botW / 2, botY);
    canvasContext.closePath();
    canvasContext.fillStyle = grad;
    canvasContext.fill();
    canvasContext.strokeStyle = 'rgba(240,185,63,0.55)';
    canvasContext.lineWidth = 3;
    canvasContext.stroke();
    // inner panel
    canvasContext.beginPath();
    canvasContext.moveTo(cx - topW / 2 + 22, topY + 24);
    canvasContext.lineTo(cx + topW / 2 - 22, topY + 24);
    canvasContext.lineTo(cx + botW / 2 - 30, botY - 24);
    canvasContext.lineTo(cx - botW / 2 + 30, botY - 24);
    canvasContext.closePath();
    canvasContext.fillStyle = 'rgba(0,0,0,0.28)';
    canvasContext.fill();
    // pivot + rod + bob
    var pivotY = 120, rodLen = 300;
    var bobX = cx + Math.sin(angle) * rodLen;
    var bobY = pivotY + Math.cos(angle) * rodLen;
    canvasContext.beginPath();
    canvasContext.moveTo(cx, pivotY);
    canvasContext.lineTo(bobX, bobY);
    canvasContext.strokeStyle = '#e8c877';
    canvasContext.lineWidth = 7;
    canvasContext.stroke();
    var bobGrad = canvasContext.createRadialGradient(bobX - 8, bobY - 8, 4, bobX, bobY, 30);
    bobGrad.addColorStop(0, '#ffe9a8');
    bobGrad.addColorStop(1, '#d99a26');
    canvasContext.beginPath();
    canvasContext.arc(bobX, bobY, 27, 0, Math.PI * 2);
    canvasContext.fillStyle = bobGrad;
    canvasContext.fill();
    canvasContext.beginPath();
    canvasContext.arc(cx, pivotY, 13, 0, Math.PI * 2);
    canvasContext.fillStyle = '#f0b93f';
    canvasContext.fill();
}

function draw() {
    var currentNote = last16thNoteDrawn;
    if (audioContext && isPlaying) {
        var currentTime = audioContext.currentTime;
        while (notesInQueue.length && notesInQueue[0].time < currentTime) {
            currentNote = notesInQueue[0].note;
            if (currentNote % 4 === 0) { jpBeatTime = notesInQueue[0].time; jpBeatCount++; }
            notesInQueue.splice(0,1);
        }
        if (last16thNoteDrawn != currentNote) {
            last16thNoteDrawn = currentNote;
            jpUpdateDots(currentNote);
        }
        var spb = 60.0 / tempo;
        if (jpBeatCount > 0) {
            var phase = (jpBeatCount - 1) + (currentTime - jpBeatTime) / spb;
            jpAngle = -0.42 * Math.cos(Math.PI * phase);
        }
    } else {
        jpAngle += (0 - jpAngle) * 0.08;
    }
    jpDrawPendulum(jpAngle);
    requestAnimFrame(draw);
}

var timerID = null;

function startTimer() {
    if (timerWorker) timerWorker.postMessage("start");
    else if (!timerID) timerID = setInterval(scheduler, lookahead);
}

function stopTimer() {
    if (timerWorker) timerWorker.postMessage("stop");
    if (timerID) { clearInterval(timerID); timerID = null; }
}

function init(){
    canvas = document.getElementById('pendulum');
    canvasContext = canvas.getContext( '2d' );
    jpDrawPendulum(0);
    requestAnimFrame(draw);
    try {
        timerWorker = new Worker("metronomeworker.js");
        timerWorker.onmessage = function(e) {
            if (e.data == "tick") scheduler();
        };
        timerWorker.onerror = function() {
            timerWorker = null;
            if (isPlaying) startTimer();
        };
        timerWorker.postMessage({"interval":lookahead});
    } catch (e) {
        timerWorker = null;
    }
    jpBind();
}

if (document.readyState === 'complete') init();
else window.addEventListener("load", init);


// ---- 控件绑定 ----
function jpTempoMark(bpm) {
    if (bpm < 40) return '庄板 · Grave';
    if (bpm < 60) return '广板 · Largo';
    if (bpm < 66) return '小广板 · Larghetto';
    if (bpm < 76) return '柔板 · Adagio';
    if (bpm < 108) return '行板 · Andante';
    if (bpm < 120) return '中板 · Moderato';
    if (bpm < 168) return '快板 · Allegro';
    if (bpm < 176) return '活泼的快板 · Vivace';
    if (bpm < 200) return '急板 · Presto';
    return '最急板 · Prestissimo';
}

function jpSetTempo(v) {
    v = Math.round(v);
    if (v < 30) v = 30;
    if (v > 240) v = 240;
    tempo = v;
    document.getElementById('tempo').value = v;
    document.getElementById('bpmNum').textContent = v;
    document.getElementById('tempoMark').textContent = jpTempoMark(v);
}

var jpTaps = [];
function jpTap() {
    var now = performance.now();
    if (jpTaps.length && now - jpTaps[jpTaps.length - 1] > 2000) jpTaps = [];
    jpTaps.push(now);
    if (jpTaps.length > 5) jpTaps.shift();
    if (jpTaps.length >= 2) {
        var sum = 0;
        for (var i = 1; i < jpTaps.length; i++) sum += jpTaps[i] - jpTaps[i - 1];
        jpSetTempo(60000 / (sum / (jpTaps.length - 1)));
    }
}

function jpBind() {
    var playBtn = document.getElementById('playBtn');
    playBtn.addEventListener('click', function () {
        var label = play();
        playBtn.textContent = (label === 'stop') ? '停止' : '开始';
        if (isPlaying) playBtn.classList.add('playing');
        else {
            playBtn.classList.remove('playing');
            var dots = document.querySelectorAll('.dot');
            for (var i = 0; i < dots.length; i++) dots[i].classList.remove('on');
        }
    });
    document.getElementById('tempo').addEventListener('input', function () {
        jpSetTempo(parseFloat(this.value));
    });
    document.getElementById('minusBtn').addEventListener('click', function () { jpSetTempo(tempo - 1); });
    document.getElementById('plusBtn').addEventListener('click', function () { jpSetTempo(tempo + 1); });
    document.getElementById('tapBtn').addEventListener('click', jpTap);
    document.getElementById('helpBtn').addEventListener('click', function () {
        document.getElementById('helpOverlay').classList.add('active');
    });
    document.getElementById('helpCloseBtn').addEventListener('click', function () {
        document.getElementById('helpOverlay').classList.remove('active');
    });
    var segBtns = document.querySelectorAll('.seg-btn');
    for (var i = 0; i < segBtns.length; i++) {
        segBtns[i].addEventListener('click', function () {
            noteResolution = parseInt(this.getAttribute('data-res'), 10);
            for (var j = 0; j < segBtns.length; j++) segBtns[j].classList.remove('active');
            this.classList.add('active');
        });
    }
    jpSetTempo(120);
}

// ---- 测试桥 ----
window.JP = {
    getState: function () {
        return {
            playing: isPlaying,
            tempo: tempo,
            resolution: noteResolution,
            currentNote: last16thNoteDrawn,
            beat: last16thNoteDrawn >= 0 ? Math.floor(last16thNoteDrawn / 4) % 4 : -1,
            ctxState: audioContext ? audioContext.state : 'none',
            queueLen: notesInQueue.length,
            taps: jpTaps.length,
            angle: Math.round(jpAngle * 100) / 100,
            helpVisible: document.getElementById('helpOverlay').classList.contains('active')
        };
    }
};
