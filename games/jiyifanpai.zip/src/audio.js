/* 纯 WebAudio 合成音效（无音频文件）。
 * 顶层 var sfx；调用处一律用 typeof sfx !== 'undefined' 做守卫。
 * 每种音效内部节流：同一音效在节流窗内重复触发只响一次。 */
var sfx = (function () {
  'use strict';
  var ctx = null;
  var lastPlay = {};
  function ensure() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }
  function tone(freq0, freq1, dur, type, vol, when) {
    var ac = ensure();
    if (!ac) return;
    var t0 = ac.currentTime + (when || 0);
    var o = ac.createOscillator();
    var g = ac.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq0, t0);
    if (freq1 && freq1 !== freq0) o.frequency.exponentialRampToValueAtTime(Math.max(freq1, 1), t0 + dur);
    g.gain.setValueAtTime(vol || 0.15, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    o.connect(g);
    g.connect(ac.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }
  function throttle(name, ms) {
    var now = Date.now();
    if (lastPlay[name] && now - lastPlay[name] < ms) return false;
    lastPlay[name] = now;
    return true;
  }
  return {
    flip: function () { if (!throttle('flip', 60)) return; tone(520, 760, 0.07, 'triangle', 0.12); },
    match: function () { if (!throttle('match', 120)) return; tone(784, 784, 0.1, 'triangle', 0.16); tone(1175, 1175, 0.16, 'triangle', 0.16, 0.08); },
    miss: function () { if (!throttle('miss', 200)) return; tone(420, 240, 0.22, 'sine', 0.13); },
    win: function () { if (!throttle('win', 500)) return; tone(523, 523, 0.12, 'triangle', 0.17); tone(659, 659, 0.12, 'triangle', 0.17, 0.11); tone(784, 784, 0.12, 'triangle', 0.17, 0.22); tone(1046, 1046, 0.26, 'triangle', 0.17, 0.33); },
    best: function () { if (!throttle('best', 500)) return; tone(659, 659, 0.12, 'triangle', 0.17); tone(784, 784, 0.12, 'triangle', 0.17, 0.11); tone(988, 988, 0.12, 'triangle', 0.17, 0.22); tone(1318, 1318, 0.3, 'triangle', 0.17, 0.33); }
  };
})();
