const cards = document.querySelectorAll(".card");

let matched = 0;
let cardOne, cardTwo;
let disableDeck = false;
let steps = 0;
let elapsedSec = 0;
let timerId = null;
let started = false;
let paused = false;
let over = false;
let best = loadBest();

function flipCard({target: clickedCard}) {
    if(paused || over || preview) return;
    if(cardOne !== clickedCard && !disableDeck) {
        clickedCard.classList.add("flip");
        if (typeof sfx !== 'undefined') { sfx.flip(); }
        if(!started) { started = true; startTimer(); }
        if(!cardOne) {
            return cardOne = clickedCard;
        }
        cardTwo = clickedCard;
        steps++;
        updateHud();
        disableDeck = true;
        let cardOneImg = cardOne.querySelector(".back-view img").src,
        cardTwoImg = cardTwo.querySelector(".back-view img").src;
        matchCards(cardOneImg, cardTwoImg);
    }
}

function matchCards(img1, img2) {
    if(img1 === img2) {
        matched++;
        cardOne.classList.add("matched");
        cardTwo.classList.add("matched");
        spawnParticles(cardOne);
        spawnParticles(cardTwo);
        if (typeof sfx !== 'undefined') { sfx.match(); }
        updateHud();
        if(matched == 8) {
            setTimeout(winGame, 700);
        }
        cardOne.removeEventListener("click", flipCard);
        cardTwo.removeEventListener("click", flipCard);
        cardOne = cardTwo = "";
        return disableDeck = false;
    }
    setTimeout(() => {
        cardOne.classList.add("shake");
        cardTwo.classList.add("shake");
        if (typeof sfx !== 'undefined') { sfx.miss(); }
    }, 400);

    setTimeout(() => {
        cardOne.classList.remove("shake", "flip");
        cardTwo.classList.remove("shake", "flip");
        cardOne = cardTwo = "";
        disableDeck = false;
    }, 1200);
}

function shuffleCard() {
    matched = 0;
    disableDeck = false;
    cardOne = cardTwo = "";
    let arr = [1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8];
    arr.sort(() => Math.random() > 0.5 ? 1 : -1);
    cards.forEach((card, i) => {
        card.classList.remove("flip", "matched");
        let imgTag = card.querySelector(".back-view img");
        imgTag.src = `images/img-${arr[i]}.png`;
        card.addEventListener("click", flipCard);
    });
}

shuffleCard();
    
cards.forEach(card => {
    card.addEventListener("click", flipCard);
});

// ---------- 改编版新增：HUD / 计时 / 暂停 / 结算 / 粒子 ----------
const stepsEl = document.getElementById('stepsEl');
const pairsEl = document.getElementById('pairsEl');
const timeEl = document.getElementById('timeEl');
const bestEl = document.getElementById('bestEl');
const btnPause = document.getElementById('btnPause');
const pauseVeil = document.getElementById('pauseVeil');
const overlay = document.getElementById('overlay');

function loadBest() {
    try {
        const rawBest = localStorage.getItem('memorycard_best');
        if (rawBest) {
            const b = JSON.parse(rawBest);
            if (b && b.steps) return { steps: b.steps, time: b.time || 0 };
        }
    } catch (e) {}
    return { steps: 0, time: 0 };
}

function saveBest() {
    try { localStorage.setItem('memorycard_best', JSON.stringify(best)); } catch (e) {}
}

function fmtTime(sec) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return m + ':' + (s < 10 ? '0' : '') + s;
}

function updateHud() {
    stepsEl.textContent = String(steps);
    pairsEl.textContent = matched + '/8';
    timeEl.textContent = fmtTime(elapsedSec);
    bestEl.textContent = best.steps ? best.steps + '步' : '—';
}

function startTimer() {
    stopTimer();
    timerId = setInterval(() => {
        if (!paused && !over) { elapsedSec++; updateHud(); }
    }, 1000);
}

function stopTimer() {
    if (timerId) { clearInterval(timerId); timerId = null; }
}

function spawnParticles(cardEl) {
    const colors = ['#ffd94d', '#b388ff', '#80d8ff', '#ff8a80', '#a5d6a7', '#ffccbc'];
    for (let i = 0; i < 8; i++) {
        const p = document.createElement('span');
        p.className = 'particle';
        const ang = (Math.PI * 2 * i) / 8 + Math.random() * 0.6;
        const dist = 26 + Math.random() * 24;
        p.style.setProperty('--dx', (Math.cos(ang) * dist).toFixed(1) + 'px');
        p.style.setProperty('--dy', (Math.sin(ang) * dist).toFixed(1) + 'px');
        p.style.background = colors[i % colors.length];
        cardEl.appendChild(p);
        setTimeout(() => { if (p.parentNode) p.parentNode.removeChild(p); }, 650);
    }
}

function setPauseUI() {
    btnPause.textContent = paused ? '继续' : '暂停';
    if (paused) pauseVeil.classList.add('show'); else pauseVeil.classList.remove('show');
    if (preview) {
        // 明牌阶段暂停时把牌扣回去，免得隔着遮罩偷看
        cards.forEach(card => { if (paused) card.classList.remove('flip'); else card.classList.add('flip'); });
    }
}

function togglePause() {
    if (over) return;
    paused = !paused;
    setPauseUI();
}

function winGame() {
    over = true;
    stopTimer();
    const isRecord = !best.steps || steps < best.steps || (steps === best.steps && elapsedSec < best.time);
    if (isRecord) { best = { steps: steps, time: elapsedSec }; saveBest(); }
    if (typeof sfx !== 'undefined') { sfx.win(); if (isRecord) { sfx.best(); } }
    document.getElementById('dlgSteps').textContent = steps + ' 步';
    document.getElementById('dlgTime').textContent = fmtTime(elapsedSec);
    document.getElementById('dlgBest').textContent = best.steps + ' 步';
    document.getElementById('dlgRecord').style.display = isRecord ? 'block' : 'none';
    overlay.classList.add('show');
    updateHud();
}

function newGame() {
    overlay.classList.remove('show');
    stopPreview();
    steps = 0;
    elapsedSec = 0;
    started = false;
    paused = false;
    over = false;
    stopTimer();
    setPauseUI();
    shuffleCard();
    updateHud();
    startPreview();
}

btnPause.addEventListener('click', togglePause);
document.getElementById('btnResume').addEventListener('click', togglePause);
document.getElementById('btnNew').addEventListener('click', newGame);
document.getElementById('btnAgain').addEventListener('click', newGame);
document.getElementById('btnClose').addEventListener('click', () => overlay.classList.remove('show'));

// ---------- 开局明牌：先给 3 秒记住牌面，再翻回开始（2026-11-25 用户令加） ----------
const hintEl = document.querySelector('.hint');
const hintDefault = hintEl ? hintEl.textContent : '';
const PREVIEW_SEC = 3;
let preview = false;
let previewLeft = 0;
let previewTimer = null;

function updatePreviewHint() {
    if (hintEl) hintEl.textContent = '记住牌面位置！' + previewLeft + ' 秒后翻回';
}

function startPreview() {
    stopPreview();
    preview = true;
    previewLeft = PREVIEW_SEC;
    cards.forEach(card => card.classList.add('flip'));
    updatePreviewHint();
    previewTimer = setInterval(() => {
        if (paused) return;
        previewLeft--;
        if (previewLeft <= 0) { endPreview(); return; }
        updatePreviewHint();
    }, 1000);
}

function endPreview() {
    stopPreview();
    preview = false;
    cards.forEach(card => { if (!card.classList.contains('matched')) card.classList.remove('flip'); });
    if (hintEl) hintEl.textContent = hintDefault;
}

function stopPreview() {
    if (previewTimer) { clearInterval(previewTimer); previewTimer = null; }
}

updateHud();
startPreview();

/* ======================================================================
 * Test bridge (window.MC)
 * ==================================================================== */
window.MC = {
    getState: function () {
        const flippedIdx = [], matchedIdx = [], imgs = [];
        cards.forEach((c, i) => {
            const src = c.querySelector('.back-view img').src;
            const m = src.match(/img-(\d+)\.png/);
            imgs.push(m ? +m[1] : src);
            if (c.classList.contains('flip')) flippedIdx.push(i);
            if (c.classList.contains('matched')) matchedIdx.push(i);
        });
        return {
            phase: over ? 'over' : (paused ? 'paused' : (preview ? 'preview' : (started ? 'playing' : 'ready'))),
            steps: steps, matched: matched, pairs: 8,
            timeSec: elapsedSec, best: best.steps, bestTime: best.time,
            started: started, paused: paused, over: over, preview: preview,
            cards: imgs, flipped: flippedIdx, matchedCards: matchedIdx
        };
    },
    flipCard: function (i) {
        if (cards[i] && !cards[i].classList.contains('matched')) flipCard({ target: cards[i] });
        return window.MC.getState();
    },
    start: function () { newGame(); return window.MC.getState(); },
    skipPreview: function () { endPreview(); return window.MC.getState(); },
    togglePause: function () { togglePause(); return window.MC.getState(); },
    tick: function (sec) { elapsedSec += sec; updateHud(); return window.MC.getState(); },
    reloadBest: function () { best = loadBest(); updateHud(); return window.MC.getState(); }
};