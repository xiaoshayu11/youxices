//Colour Theme data
//palettes from colourlovers.com
//sixth colour is a random addition

var themes = [
	{
		name: "欢乐",
		colours: ["556270", "4ECDC4", "C7F464", "FF6B6B", "C44D58", "FFA661"]
	},
	{
		name: "莲池",
		colours: ["FF68AF", "F4FCE8", "C3FF68", "87D69B", "4E9689", "7ED0D6"]
	},
	{
		name: "瓜果",
		colours: ["D1F2A5", "EFFAB4", "FFC48C", "FF9F80", "F56991", "E99FBE"]
	},
	{
		name: "雨天",
		colours: ["F6E3AB", "B43F5A", "4B1D37", "70575B", "869B88", "C8AEAD"]
	},
	{
		name: "夜光",
		colours: ["5E4040", "F75BA0", "F797C1", "FFF3A4", "9DCD4F", "AF8585"]
	},
	{
		name: "青柠冰（困难）",
		colours: ["59A80F", "9ED54C", "C4ED68", "E2FF9E", "F0F2DD", "FFFFFF"]
	},
];
