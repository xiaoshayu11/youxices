var size = 14;    //the size of the grid
var turn;
var grid = [];    //internal grid
var original = [];
var cells = [];   //grid of jquery objects
var seen = [];    //marks seen positions during flooding
var computingMode = false;
var computerSolution;
var solverMode = false;
var solved = false;
var solveLabel;
var colours = [];

/**
 * Messages
 */
var successMsg = "你赢了电脑！";
var failMsg = "这局没能比电脑更少，再试一次吧！";

var soundOn = true;
function sound() {
  return window.SoundEngine || null;
}
function setStatus(text, cls) {
  var el = document.getElementById("status");
  el.textContent = text;
  el.className = "status" + (cls ? " " + cls : "");
}
function markActiveColour() {
  if (computingMode) return;
  $('.palette-colour').removeClass('active');
  $('.palette-colour[value="' + grid[0][0] + '"]').addClass('active');
}

/**
 * Clears seen grid
 */
function clearSeen() {
  for(var i = 0; i < size; i++)
    for(var j = 0; j < size; j++)
      seen[i][j] = false;
}

/**
 * Starts a new game
 */
function makeGrid() {

  solved = false;
  setStatus("在下方选个颜色，把整块棋盘染成同色。");
  
  //initialize grids
  for(var i = 0; i < size; i++) {
    grid[i] = [];
    original[i] = [];
    cells[i] = [];
    seen[i] = [];
  }

  //populate table: board width follows the container (mobile-safe)
  var boardW = Math.min(420, $('.container').width() || 420);
  var cellSize = Math.max(8, Math.floor(boardW / size));
  var $table = $('#grid'), $tr, $td, rand;
  $table.empty();
  $table.width(cellSize * size);
  for(var i = 0; i < size; i++) {
    $tr = $('<tr>');
    for(var j = 0; j < size; j++) {
      rand =  Math.floor(Math.random() * colours.length);
      $td = $('<td>');
      $td.addClass('cell');
      $tr.append($td);
      $td.css("background-color", '#' + colours[rand]);
      $td.height(cellSize);
      $td.width(cellSize);
      cells[i][j] = $td;
      grid[i][j] = rand;
      original[i][j] = rand;
    }
    $table.append($tr);
  } 
  computerSolution = computerSolve();
  updateTurn(0);
  markActiveColour();
}

/**
 * Makes the colour changing palette
 */
function makeControls() {
  var $palette = $('#palette');
  $palette.empty();
  for(var i = 0; i < colours.length; i++) {
    var $button = $('<button>');
    $button.addClass('palette-colour');
    $button.attr('value', i);
    $button.css('background-color', '#' + colours[i]);
    $palette.append($button);
  }

  $('.palette-colour').click(function() {
    flood(Number($(this).val()));
  });
  markActiveColour();
}

/**
 * Updates the turn text
 */
function updateTurn(n) {
  turn = n;
  $('#counter').html(n);
  if(n === 0) {
    $('#solve-btn').show();
  }
}

/**
 * Resets the game
 */
function reset() {
  solved = false;
  setStatus("在下方选个颜色，把整块棋盘染成同色。");
  for(var i = 0; i < size; i++) {
    for(var j = 0; j < size; j++) {
      grid[i][j] = original[i][j];
      if(!computingMode)
        cells[i][j].css('background-color', '#' + colours[grid[i][j]]);
    }
  }
  updateTurn(0);
  markActiveColour();
}

/**
 * Refreshes the board with a new color
 */
function refresh() {  
  for(var i = 0; i < size; i++)
    for(var j = 0; j < size; j++) {
      cells[i][j].css('background-color', '#' + colours[grid[i][j]]);
    }
}

function countConnected(i, j, c) {
  if(i < 0 || j < 0 || i >= size || j >= size || seen[i][j] || grid[i][j] != c) {
    return 0;
  }
  seen[i][j] = true;
  return countConnected(i, j - 1, c) +
    countConnected(i, j + 1, c) +
    countConnected(i - 1, j, c) +
    countConnected(i + 1, j, c) + 1;
}

/**
 * Recursive flooding helper function.
 * Returns the number of cells of the flooded colour connected to (0, 0)
 * at the end of flooding.
 */
function _flood(i, j, original, replace) {
  if(i < 0 || j < 0 || i >= size || j >= size || seen[i][j]) {
    return 0;
  }
  seen[i][j] = true;
  if (grid[i][j] === original) {
    grid[i][j] = replace;
    if(!computingMode) {
      cells[i][j].css('background-color', '#' + colours[replace]);
    }
    return 1 + _flood(i, j + 1, original, replace) +
      _flood(i, j - 1, original, replace) +
      _flood(i + 1, j, original, replace) +
      _flood(i - 1, j, original, replace);
  } else if (grid[i][j] === replace) {
    // Unmark this cell for countConnected.
    seen[i][j] = false;
    return countConnected(i, j, replace);
  }
  return 0;
}

/**
 * Floods the grid with a certain colour
 */
function flood(c) {
  if(grid[0][0] == c) {
    return false;
  }
  clearSeen();
  // Check if number of cells flooded is equal to size of grid.
  var countFlooded = _flood(0, 0, grid[0][0], c);
  var checkSolved = countFlooded === size * size;
  updateTurn(++turn);
  markActiveColour();

  if (!computingMode && !solverMode) {
    var se = sound();
    if (se) se.click();
    if(!solved && checkSolved) {
      if(turn <= computerSolution) {
        setStatus(successMsg + "只用了 " + turn + " 步！", "win");
        if (se) se.win();
      } else {
        setStatus("通关了！共用了 " + turn + " 步。", "win");
        if (se) se.win();
      }
      solved = true;
      $('#solve-btn').hide();
    } else if(computerSolution === turn) {
      setStatus(failMsg, "fail");
      if (se) se.fail();
    }
  }
  return checkSolved;
}

/**
 * Solver functions
 */

var list = [];
var computerSolution = -1;

function _inspect(i, j) { 
  if(i < 0 || j < 0 || i >= size || j >= size || seen[i][j]) {
    return;
  }
  if(grid[i][j] === grid[0][0]) {
    seen[i][j] = true;
    _inspect(i, j - 1);
    _inspect(i, j + 1);
    _inspect(i - 1, j);
    _inspect(i + 1, j);
  } else {
    list[grid[i][j]] += countConnected(i, j, grid[i][j]);
  }
}

function inspect() {
  clearSeen();
  for(var i = 0; i < colours.length; i++) {
    list[i] = 0;
  }
  _inspect(0, 0);
  var max = 0;
  for(var i = 0; i < colours.length; i++) {
    if(list[i] > list[max]){
      max = i;
    }
  }
  return max;
}

function floodMax() {
  var c = inspect();
  return flood(c);
}

function computerSolve() {
  computingMode = true;
  var computerSolution = 1;
  while(!floodMax()) {
    computerSolution++;
  }
  $('#computer-solution').html(computerSolution);
  reset();
  computingMode = false;
  return computerSolution;
}

/**
 * Solves the puzzle for the user
 */
function solve() {
  var $solve_button = $('#solve-btn');
  var robot = setInterval(function() {
    solverMode = true;
    var se = sound();
    if (se) se.tick();
    if(floodMax()) {
      clearInterval(robot);
      $solve_button.html(solveLabel);
      // 上游 solver 跑完不设完成状态，这里补上：标已解、报步数、藏按钮
      solved = true;
      setStatus("解开了！共用了 " + turn + " 步。", "win");
      if (se) se.win();
      $solve_button.hide();
    }
    solverMode = false;
  }, 500);
  $solve_button.html('停！').unbind().click(function() {
    clearInterval(robot);
    $solve_button.html(solveLabel).click(solve);
  });
}

$(document).ready(function() {

  $('[data-toggle="popover"]').popover();
  $('[data-toggle="tooltip"]').tooltip();

  colours = themes[0].colours;
  makeGrid();
  makeControls();
  solveLabel = $('#solve-btn').html();
  $('#solve-btn').click(solve);
  $('#new-game-btn').click(makeGrid);
  $('#reset-btn').click(reset);
  $('#sound-btn').click(function() {
    soundOn = !soundOn;
    $(this).text(soundOn ? '音效开' : '音效关');
    var se = sound();
    if (se) se.setEnabled(soundOn);
  });

  $themes = $('#themes');
  for(var i = 0; i < themes.length; i++) {
      $option = $('<option>');
      $option.val(i);
      $option.text(themes[i].name);
    $themes.append($option);
  }

  $('#themes').change(function() {
    colours = themes[Number($(this).find('option:selected').val())].colours;
    refresh();
    makeControls();
  });

  $('#size').change(function() {
    size = Number($(this).find('option:selected').val());
    makeGrid();
  });

});

