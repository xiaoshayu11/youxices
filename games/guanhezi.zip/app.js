/* 关盒子（Shut the Box）：掷骰后选牌凑齐点数翻下，九张全关获胜。
   核心 subset-sum 判定 combos 与单骰规则源自 Pixel-Arcade shutthebox.js（MIT）。 */
function ghEl(id) { return document.getElementById(id); }

/* ---- WebAudio 合成音效 ---- */
var ghAudioCtx = null;
function ghCtx() {
  if (!ghAudioCtx) {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ghAudioCtx = new AC();
  }
  if (ghAudioCtx.state === "suspended") ghAudioCtx.resume();
  return ghAudioCtx;
}
function ghTone(freqFrom, freqTo, dur, type, vol, delay) {
  var ctx = ghCtx();
  if (!ctx) return;
  var t0 = ctx.currentTime + (delay || 0);
  var osc = ctx.createOscillator();
  var gain = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freqFrom, t0);
  osc.frequency.exponentialRampToValueAtTime(Math.max(freqTo, 1), t0 + dur);
  gain.gain.setValueAtTime(vol || 0.15, t0);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}
var sfx = {
  roll: function () {
    ghTone(300, 180, 0.06, "square", 0.07, 0);
    ghTone(340, 200, 0.06, "square", 0.07, 0.12);
    ghTone(280, 160, 0.06, "square", 0.07, 0.24);
    ghTone(320, 190, 0.06, "square", 0.07, 0.36);
  },
  click: function () { ghTone(500, 700, 0.07, "sine", 0.1, 0); },
  flip: function () { ghTone(700, 420, 0.1, "triangle", 0.16, 0); },
  bad: function () { ghTone(220, 150, 0.14, "triangle", 0.12, 0); },
  win: function () {
    ghTone(523, 523, 0.14, "sine", 0.16, 0);
    ghTone(659, 659, 0.14, "sine", 0.16, 0.15);
    ghTone(784, 784, 0.14, "sine", 0.16, 0.3);
    ghTone(1047, 1047, 0.26, "sine", 0.16, 0.45);
  },
  lose: function () {
    ghTone(392, 392, 0.16, "sine", 0.14, 0);
    ghTone(330, 330, 0.16, "sine", 0.14, 0.18);
    ghTone(262, 262, 0.3, "sine", 0.14, 0.36);
  }
};

/* ---- 上游核心判定：所有和为 target 的子集（原文提取） ---- */
function combos(nums, target) { // all subsets summing to target
  const out = [];
  const rec = (start, left, acc) => {
    if (left === 0) {
      out.push(acc.slice());
      return;
    }
    for (let i = start; i < nums.length; i++) {
      if (nums[i] > left) break;
      acc.push(nums[i]);
      rec(i + 1, left - nums[i], acc);
      acc.pop();
    }
  };
  rec(0, target, []);
  return out;
}

/* ---- 游戏状态 ---- */
var ghScreen = "home";
var ghTiles = [];
var ghSelected = {};
var ghD1 = 0, ghD2 = 0, ghRoll = null, ghUseOne = false;
var ghOver = false, ghWon = false, ghRounds = 0;
var ghRolling = false;
var ghSfxClicks = 0, ghSfxWins = 0, ghSfxRolls = 0, ghSfxFlips = 0;

var GH_PIPS = {
  1: ["gh-p-c"],
  2: ["gh-p-tl", "gh-p-br"],
  3: ["gh-p-tl", "gh-p-c", "gh-p-br"],
  4: ["gh-p-tl", "gh-p-tr", "gh-p-bl", "gh-p-br"],
  5: ["gh-p-tl", "gh-p-tr", "gh-p-c", "gh-p-bl", "gh-p-br"],
  6: ["gh-p-tl", "gh-p-ml", "gh-p-bl", "gh-p-tr", "gh-p-mr", "gh-p-br"]
};

function ghOpenTiles() {
  var o = [];
  for (var i = 1; i <= 9; i++) if (ghTiles[i]) o.push(i);
  return o;
}
function ghScore() {
  var open = ghOpenTiles(), s = 0;
  for (var i = 0; i < open.length; i++) s += open[i];
  return s;
}
function ghSelSum() {
  var s = 0;
  for (var n in ghSelected) if (ghSelected[n]) s += parseInt(n, 10);
  return s;
}
function ghSelList() {
  var o = [];
  for (var n in ghSelected) if (ghSelected[n]) o.push(parseInt(n, 10));
  o.sort(function (a, b) { return a - b; });
  return o;
}

function ghDieHtml(v) {
  if (!v || !GH_PIPS[v]) return "";
  var h = "";
  for (var i = 0; i < GH_PIPS[v].length; i++) h += '<span class="gh-pip ' + GH_PIPS[v][i] + '"></span>';
  return h;
}

function ghRender() {
  var tilesEl = ghEl("gh-tiles");
  var kids = tilesEl.children;
  for (var i = 0; i < kids.length; i++) {
    var n = parseInt(kids[i].getAttribute("data-n"), 10);
    var cls = "gh-tile";
    if (!ghTiles[n]) cls += " shut";
    else if (ghSelected[n]) cls += " sel";
    kids[i].className = cls;
    kids[i].children[0].textContent = ghTiles[n] ? n : "—";
  }
  var die1 = ghEl("gh-die1"), die2 = ghEl("gh-die2");
  die1.innerHTML = ghDieHtml(ghD1);
  die2.innerHTML = ghDieHtml(ghD2);
  die2.className = "gh-die" + (ghUseOne && ghD1 ? " gh-die-hide" : "") + (ghRolling ? " rolling" : "");
  die1.className = "gh-die" + (ghRolling ? " rolling" : "");
  ghEl("gh-dice-note").textContent = (ghUseOne && ghD1 && !ghOver) ? "只剩下小牌，只掷一颗骰子" : "";
  var st = ghEl("gh-status");
  var text, cls = "gh-status";
  if (ghOver && ghWon) { text = "全关上了！完美获胜！"; cls += " win"; }
  else if (ghOver) { text = "掷出 " + ghRoll + "，没有能凑齐的组合，本局结束"; cls += " lose"; }
  else if (ghRoll === null) { text = ghRounds === 0 ? "掷骰子开始" : "继续掷骰子"; }
  else {
    var diceTxt = ghUseOne ? ("" + ghD1) : (ghD1 + "+" + ghD2 + "=" + ghRoll);
    text = "掷出 " + diceTxt + "，选牌凑齐 " + ghRoll + "（已选 " + ghSelSum() + "）";
  }
  st.textContent = text;
  st.className = cls;
  ghEl("gh-score-line").textContent = "剩余 " + ghScore() + " 分 · 已掷 " + ghRounds + " 次";
  ghEl("gh-roll").disabled = ghOver || ghRoll !== null || ghRolling;
  ghEl("gh-ok").disabled = ghOver || ghRoll === null || ghRolling;
}

function ghNewGame() {
  ghTiles = [];
  for (var i = 0; i <= 9; i++) ghTiles[i] = i >= 1 && i <= 9;
  ghSelected = {};
  ghD1 = 0; ghD2 = 0; ghRoll = null; ghUseOne = false;
  ghOver = false; ghWon = false; ghRounds = 0; ghRolling = false;
  ghRender();
}

function ghApplyRoll(a, b) {
  var open = ghOpenTiles();
  ghD1 = a; ghD2 = b;
  ghUseOne = open.length <= 6 && open.every(function (n) { return n <= 6; });
  ghRoll = ghUseOne ? ghD1 : ghD1 + ghD2;
  if (!combos(open, ghRoll).length) {
    ghOver = true;
    ghWon = false;
    if (typeof sfx !== "undefined") sfx.lose();
  }
  ghRender();
}

function ghDoRollAnimated() {
  if (ghOver || ghRoll !== null || ghRolling) return;
  ghCtx();
  ghRolling = true;
  ghSfxRolls++;
  if (typeof sfx !== "undefined") sfx.roll();
  var cycles = 0;
  ghD1 = 1 + Math.floor(Math.random() * 6);
  ghD2 = 1 + Math.floor(Math.random() * 6);
  ghRender();
  var iv = setInterval(function () {
    cycles++;
    ghD1 = 1 + Math.floor(Math.random() * 6);
    ghD2 = 1 + Math.floor(Math.random() * 6);
    ghRender();
    if (cycles >= 6) {
      clearInterval(iv);
      ghRolling = false;
      ghApplyRoll(1 + Math.floor(Math.random() * 6), 1 + Math.floor(Math.random() * 6));
    }
  }, 80);
}

function ghToggleTile(n) {
  if (ghOver || ghRoll === null || ghRolling) return;
  if (!ghTiles[n]) return;
  if (ghSelected[n]) delete ghSelected[n];
  else ghSelected[n] = true;
  ghSfxClicks++;
  if (typeof sfx !== "undefined") sfx.click();
  ghRender();
}

function ghConfirm() {
  if (ghOver || ghRoll === null || ghRolling) return;
  if (ghSelSum() !== ghRoll) {
    if (typeof sfx !== "undefined") sfx.bad();
    var t = ghEl("gh-tiles");
    t.className = "gh-tiles shake";
    setTimeout(function () { t.className = "gh-tiles"; }, 320);
    return;
  }
  var sel = ghSelList();
  for (var i = 0; i < sel.length; i++) ghTiles[sel[i]] = false;
  ghSelected = {};
  ghRoll = null;
  ghRounds++;
  ghSfxFlips++;
  if (typeof sfx !== "undefined") sfx.flip();
  if (ghOpenTiles().length === 0) {
    ghOver = true;
    ghWon = true;
    ghSfxWins++;
    if (typeof sfx !== "undefined") sfx.win();
  }
  ghRender();
}

function ghShowHome() {
  ghScreen = "home";
  ghEl("gh-game").className = "gh-hidden";
  ghEl("gh-home").className = "";
}
function ghShowGame() {
  ghScreen = "game";
  ghEl("gh-home").className = "gh-hidden";
  ghEl("gh-game").className = "";
  ghNewGame();
}

/* ---- 事件绑定 ---- */
ghEl("gh-start").addEventListener("click", function () {
  ghCtx();
  if (typeof sfx !== "undefined") sfx.click();
  ghShowGame();
});
ghEl("gh-back").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  ghShowHome();
});
ghEl("gh-roll").addEventListener("click", ghDoRollAnimated);
ghEl("gh-ok").addEventListener("click", ghConfirm);
ghEl("gh-new").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  ghNewGame();
});
function ghOpenHelp() {
  if (typeof sfx !== "undefined") sfx.click();
  ghEl("gh-mask").className = "gh-mask open";
}
ghEl("gh-help").addEventListener("click", ghOpenHelp);
ghEl("gh-help-home").addEventListener("click", ghOpenHelp);
ghEl("gh-help-close").addEventListener("click", function () {
  ghEl("gh-mask").className = "gh-mask";
});
ghEl("gh-mask").addEventListener("click", function (e) {
  if (e.target === ghEl("gh-mask")) ghEl("gh-mask").className = "gh-mask";
});
function ghTileTap(e) {
  var t = e.target;
  while (t && !(t.getAttribute && t.getAttribute("data-n"))) t = t.parentNode;
  if (!t) return;
  if (e.preventDefault) e.preventDefault();
  ghToggleTile(parseInt(t.getAttribute("data-n"), 10));
}
ghEl("gh-tiles").addEventListener("touchstart", ghTileTap);
ghEl("gh-tiles").addEventListener("click", ghTileTap);

/* ---- 测试桥 ---- */
var GH = {
  getState: function () {
    var down = [];
    for (var i = 1; i <= 9; i++) if (!ghTiles[i]) down.push(i);
    return {
      screen: ghScreen,
      dice: [ghD1, ghD2],
      roll: ghRoll,
      useOne: ghUseOne,
      tilesDown: down,
      selected: ghSelList(),
      score: ghScore(),
      over: ghOver,
      won: ghWon,
      rounds: ghRounds,
      rolling: ghRolling,
      helpVisible: ghEl("gh-mask").className.indexOf("open") >= 0,
      sfxClicks: ghSfxClicks,
      sfxWins: ghSfxWins,
      sfxRolls: ghSfxRolls,
      sfxFlips: ghSfxFlips
    };
  },
  setDice: function (a, b) {
    if (ghOver || ghRoll !== null || ghRolling || ghScreen !== "game") return GH.getState();
    ghApplyRoll(a, b);
    return GH.getState();
  }
};

ghNewGame();
