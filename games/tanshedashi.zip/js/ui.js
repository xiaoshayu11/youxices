// 界面：音效开关 + 最佳成绩显示
(function () {
  var bestEl = document.getElementById('bestScore');
  if (bestEl) bestEl.textContent = '最佳 ' + bestScore;
  var btn = document.getElementById('soundBtn');
  if (!btn) return;
  var ICON_ON = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4z" fill="#fff" stroke="none"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>';
  var ICON_OFF = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4z" fill="#fff" stroke="none"/><line x1="16" y1="9" x2="22" y2="15"/><line x1="22" y1="9" x2="16" y2="15"/></svg>';
  var render = function () { btn.innerHTML = isSoundOn() ? ICON_ON : ICON_OFF; };
  var toggle = function () { setSoundOn(!isSoundOn()); render(); };
  btn.addEventListener('mousedown', function (e) { e.stopPropagation(); });
  btn.addEventListener('touchstart', function (e) { e.stopPropagation(); e.preventDefault(); toggle(); }, { passive: false });
  btn.addEventListener('click', function (e) { e.stopPropagation(); toggle(); });
  render();
})();
