const canvas = document.getElementById('mainGame');
const ctx = canvas.getContext('2d');

// Lives
const LIVES = 3;
let numLives = LIVES;
let gameOver = false; 
let status;
let score = 0;

// 最佳成绩（localStorage，失败时退回内存）
const Store = (() => {
  try { const t = '__t'; localStorage.setItem(t, '1'); localStorage.removeItem(t); return localStorage; }
  catch (e) { const mm = {}; return { getItem: function (k) { return k in mm ? mm[k] : null; }, setItem: function (k, v) { mm[k] = String(v); }, removeItem: function (k) { delete mm[k]; } }; }
})();
let bestScore = parseInt(Store.getItem('breakout-best') || '0', 10) || 0;
const saveBestScore = () => {
  if (score > bestScore) { bestScore = score; Store.setItem('breakout-best', String(bestScore)); }
  const el = document.getElementById('bestScore');
  if (el) el.textContent = '最佳 ' + bestScore;
};


window.onload = () => {
    addHoldKeyListener('ArrowLeft');
    addHoldKeyListener('ArrowRight');
    addEventListener('mousedown', mouseClickHandle);
    //debug 
    // addEventListener('keydown', (evt) => {
    //    if(evt.key == 'n'){
    //    		level++;
    //       if(level >= levels.length){
    //         level = 0;
    //       }
    //    		bricks = levels[level].slice();
    //    }

    //    if(evt.key == 'm'){
    //      multiBall = !multiBall;
    //    }
    //     if(evt.key == 'c'){
    //      cannon = !cannon;
    //    }
    // });
    loadImages();
};

const loadingDoneSoStartGame = () => {
	  window.__gameStarted = true;
	  // these next few lines set up our game logic and render to happen 30 times per second
	    const FRAMES_PER_SECOND = 50;
      setInterval(mainGame, 1000 / FRAMES_PER_SECOND);
       for(let i = 0; i < balls.length; i++ ){
             setInterval(balls[i].speedIncrement(0.03), 1000)
        }
       
     ;

};


