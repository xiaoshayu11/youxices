const heldKeys = {};

const addHoldKeyListener = keyname => {
    addEventListener('keydown', ({ code }) => {
        if (code === keyname) {
            heldKeys[keyname] = true;
        }
    });
    addEventListener('keyup', ({ code }) => {
        if (code === keyname) {
            heldKeys[keyname] = false;
        }         
    });
};

const mouseClickHandle = () => {

    if (gameOver){
      gameOverReset();
    }
    
    else if(ballplayerconnect){
          

          if(heldKeys['ArrowLeft'] == true){
                balls[0].velocityX = INITIAL_BALL_XV ;
              }
              else if(heldKeys['ArrowRight'] == true){
                balls[0].velocityX = -INITIAL_BALL_XV ;
              }

          ballplayerconnect = false;
    }  

    if(cannon){
      fireBullets = true;
    }
}



// 触摸与鼠标挡板控制（手机端主力操作）
const canvasXFromEvent = (evt) => {
  const rect = canvas.getBoundingClientRect();
  const clientX = evt.touches ? evt.touches[0].clientX : evt.clientX;
  return (clientX - rect.left) * (canvas.width / rect.width);
};

canvas.addEventListener('touchstart', (evt) => {
  evt.preventDefault();
  const x = canvasXFromEvent(evt);
  pointerPaddleX = x;
  if (ballplayerconnect && balls.length > 0) {
    balls[0].velocityX = x < balls[0].x ? INITIAL_BALL_XV : -INITIAL_BALL_XV;
  }
  mouseClickHandle();
}, { passive: false });

canvas.addEventListener('touchmove', (evt) => {
  evt.preventDefault();
  pointerPaddleX = canvasXFromEvent(evt);
}, { passive: false });

const clearPointer = () => { pointerPaddleX = null; };
canvas.addEventListener('touchend', clearPointer);
canvas.addEventListener('touchcancel', clearPointer);
canvas.addEventListener('mousemove', (evt) => { pointerPaddleX = canvasXFromEvent(evt); });
canvas.addEventListener('mouseleave', clearPointer);
