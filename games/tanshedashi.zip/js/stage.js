//Bricks
//These will be set of coordinates which will be displayed via loop
//Different levels can be loaded based on this map which will be stored in different file

const BRICK_HEIGHT = 23;
const BRICK_WIDTH = 22;
const BRICK_GAP = 2;
const BRICK_COLS = 16;
const BRICK_ROWS = 12;
const CANNON_WIDTH = 10;
const CANNON_HEIGHT = 36;
let cannon = false;
let fireBullets = false;
let level = 0;
let  bricks = levels[level].slice();

balls.push(new Ball())

const countBricks = () => {
    let brickCount = 0;
    for(let i=0;i<bricks.length;i++){
        if(bricks[i]) brickCount++;  
    }
    return brickCount;
}

let bricksLeft = countBricks();

const mainGame = () => {

    if(!gameOver) { 
        ctx.drawImage(skyPic, 0, 0, canvas.width, canvas.height);
        drawBricks();
        updatePaddlePosition();
        ctx.drawImage(paddlePic, paddle_X, PADDLE_Y, PADDLE_WIDTH, PADDLE_HEIGHT);

        if(multiBall && balls.length == 1){
            let ball1 = new Ball();
            let ball2 = new Ball();            
            balls.push(ball1);
            balls.push(ball2);

            for(let i = 1; i <= 2; i++){
                balls[i].velocityX = balls[0].velocityX  + (Math.ceil(Math.random() * 3) - Math.ceil(Math.random() * 3))
                balls[i].velocityY = balls[0].velocityX  + (Math.ceil(Math.random() * 3) - Math.ceil(Math.random() * 3))
                balls[i].x = balls[0].x;
                balls[i].y = balls[0].y;
            }

            multiBall = false;
        }

        //displaying all balls.
        for(let i = 0; i < balls.length; i++ ){
            if(!balls[i].useless){
                balls[i].updatePosition();
                if(redBall){
                    ctx.drawImage(redBallPic, balls[i].x - BALL_DIA / 2, balls[i].y - BALL_DIA / 2, BALL_DIA, BALL_DIA);
                }
                else{
                    ctx.drawImage(ballPic, balls[i].x - BALL_DIA / 2, balls[i].y - BALL_DIA / 2, BALL_DIA, BALL_DIA);
                }
            }
            else{
                balls.splice(i,1);
            }            
        }

        //powerup display
        if(powerups.length > 0){

            //draw it.
            for(let i = 0 ;i < powerups.length; i++){
                if(!powerups[i].useless){
                    powerups[i].move();
                }
                else if(powerups[i].useless){
                    powerups.splice(i,1);
                }                
            }
        }

        if(cannon){
            ctx.drawImage(cannonPic, paddle_X + PADDLE_WIDTH/4, PADDLE_Y - CANNON_HEIGHT, CANNON_WIDTH, CANNON_HEIGHT);
        }

        if(fireBullets && bullets.length < 1){
            bullets.push(new Bullet());
            fireBullets = false;
        }

        if(bullets.length == 1){
            bullets[0].draw();
        }

        let lifePicOffset = 0
        for(let i = 0; i < numLives ; i++){
            ctx.drawImage(lifePic, canvas.width - 28 - lifePicOffset, 12, 16, 14);
            lifePicOffset += 20;
        }
        colorText('分数 ' + score, 12, 24, "white", '14px sans-serif');
        colorText('第 ' + (level + 1) + ' 关', canvas.width / 2, 24, "white", '14px sans-serif', 'center');
    }
    else {
        // colorRect(0, 0, canvas.width, canvas.height,BRICK_COLOR);
        ctx.drawImage(skyPic, 0, 0, canvas.width, canvas.height);
        colorText(status, canvas.width / 2, canvas.height / 3, "white", '34px sans-serif', 'center');
        colorText('最终得分 ' + score, canvas.width / 2, canvas.height / 2 - 40, "white", '20px sans-serif', 'center');
        colorText('最佳 ' + bestScore, canvas.width / 2, canvas.height / 2 - 8, "white", '18px sans-serif', 'center');
        colorText('点一下再玩一次', canvas.width / 2, canvas.height / 2 + 30, "white", '16px sans-serif', 'center');
    }
    
}


const rowColToArrayIndex = (col, row) => {

    return col + BRICK_COLS* row;

}


const drawBricks = () => {

    let brickLeftEdgeX = 0;
    let brickTopEdgeY = 0;
    for(let eachRow=0;eachRow<BRICK_ROWS;eachRow++) {
        brickLeftEdgeX = 0;
        for(let eachCol=0;eachCol<BRICK_COLS;eachCol++) {
            let arrayIndex = rowColToArrayIndex(eachCol, eachRow);
            if(bricks[arrayIndex] == 1) {
                ctx.drawImage(brick1Pic, brickLeftEdgeX, brickTopEdgeY, BRICK_WIDTH, BRICK_HEIGHT);               
            } 
            if(bricks[arrayIndex] == 2) {               
                ctx.drawImage(brick2Pic, brickLeftEdgeX, brickTopEdgeY, BRICK_WIDTH, BRICK_HEIGHT);               
            } 
            if(bricks[arrayIndex] == 3) {                
                ctx.drawImage(brick3Pic, brickLeftEdgeX, brickTopEdgeY, BRICK_WIDTH, BRICK_HEIGHT);               
            } 
            brickLeftEdgeX += BRICK_WIDTH; 
        } 
        brickTopEdgeY += BRICK_HEIGHT;
    } 

}; 



const isBrickAtColRow = (col, row) => {

    if(col >= 0 && col < BRICK_COLS && row >= 0 && row < BRICK_ROWS) {
         let brickIndexUnderCoord = rowColToArrayIndex(col, row);
         return bricks[brickIndexUnderCoord];
    } else {
        return false;
    }

}

const lifeLossReset = () => {

    balls[0].reset();
    gameOver = false;
    ballplayerconnect = true; 

}; //gameReset


const gameOverReset = () => {

    level = 0;
    score = 0;
    initializeBricks();
    paddle_X = canvas.width / 2 - PADDLE_WIDTH / 2;
    lifeLossReset();
    numLives = LIVES;
    cannon = false;
    fireBullets = false;
    stickyBall = false;
    redBall = false;
    multiBall = false;
    bonusLifeEligible = true;
    powerups.length = 0;
    bullets.length = 0;
    balls.splice(1);

};


const goToNextLevel = () => {

    if (level + 1 >= levels.length) {
        gameOver = true;
        status = "全部通关！";
        saveBestScore();
        return;
    }
    lifeLossReset();
    level++;
    initializeBricks();
    paddle_X = canvas.width / 2 - PADDLE_WIDTH / 2;
    numLives = LIVES;

}


const initializeBricks = () => {

    bricks = levels[level].slice();
    bricksLeft = countBricks();

}

const scoreHandling = () => {

     if(score>= 10000 && bonusLifeEligible){
        numLives += 1;
        bonusLifeEligible = false;
    }

}




