// WebAudio 合成音效（上游用 mp3/ogg 文件，小红书白名单不含音频文件，改合成）
let __audioCtx = null;
let __soundOn = true;

const setSoundOn = (on) => { __soundOn = !!on; };
const isSoundOn = () => __soundOn;

const ensureAudio = () => {
  if (!__audioCtx) {
    try { __audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch (e) { __audioCtx = null; }
  }
  if (__audioCtx && __audioCtx.state === 'suspended') __audioCtx.resume();
  return __audioCtx;
};

const tone = (freq, dur, type, vol, when, slideTo) => {
  const ctx = ensureAudio();
  if (!ctx) return;
  const t0 = ctx.currentTime + (when || 0);
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type || 'sine';
  osc.frequency.setValueAtTime(freq, t0);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
  gain.gain.setValueAtTime(vol || 0.12, t0);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
};

const SOUND_MAP = {
  hit: function () { tone(520, 0.06, 'sine', 0.15); },
  brick: function () { tone(880, 0.05, 'square', 0.07); tone(1320, 0.04, 'square', 0.05, 0.02); },
  miss: function () { tone(320, 0.25, 'sine', 0.18, 0, 120); },
  powerup: function () { [660, 880, 1100, 1320].forEach(function (f, i) { tone(f, 0.09, 'triangle', 0.11, i * 0.07); }); }
};

// 与上游同名同接口：new soundOverlapsClass("audio/hit") 后调 .play()
function soundOverlapsClass(filenameWithPath) {
  const name = filenameWithPath.split('/').pop();
  this.play = function () {
    if (!__soundOn) return;
    const fn = SOUND_MAP[name];
    if (fn) fn();
  };
}
