// Paddle Properties
const PADDLE_WIDTH = 64;
const PADDLE_HEIGHT = 16;
const PADDLE_XV = 8;
const PADDLE_GAP = 10;
const PADDLE_BOTTOM = 60;
const PADDLE_Y = canvas.height - PADDLE_HEIGHT - PADDLE_BOTTOM;
let paddle_X = canvas.width / 2 - PADDLE_WIDTH / 2;
let pointerPaddleX = null;

const updatePaddlePosition = () => {
    if (pointerPaddleX !== null) {
        paddle_X = Math.max(0, Math.min(canvas.width - PADDLE_WIDTH, pointerPaddleX - PADDLE_WIDTH / 2));
        return;
    }
    if (heldKeys['ArrowLeft'] && paddle_X > 0) {
        paddle_X -= PADDLE_XV;
    }

    if (heldKeys['ArrowRight'] && paddle_X + PADDLE_WIDTH < canvas.width) {
        paddle_X += PADDLE_XV;
    }
};
