/* 纯 WebAudio 合成音效（无音频文件）。
 * 顶层 var sfx；调用处一律用 typeof sfx !== 'undefined' 做守卫。
 * 每种音效内部节流：同一音效在节流窗内重复触发只响一次。 */
var sfx = (function () {
  'use strict';
  var ctx = null;
  var lastPlay = {};
  function ensure() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }
  function tone(freq0, freq1, dur, type, vol, when) {
    var ac = ensure();
    if (!ac) return;
    var t0 = ac.currentTime + (when || 0);
    var o = ac.createOscillator();
    var g = ac.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq0, t0);
    if (freq1 && freq1 !== freq0) o.frequency.exponentialRampToValueAtTime(Math.max(freq1, 1), t0 + dur);
    g.gain.setValueAtTime(vol || 0.15, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    o.connect(g);
    g.connect(ac.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }
  function throttle(name, ms) {
    var now = Date.now();
    if (lastPlay[name] && now - lastPlay[name] < ms) return false;
    lastPlay[name] = now;
    return true;
  }
  return {
    shoot: function () { if (!throttle('shoot', 70)) return; tone(880, 440, 0.08, 'square', 0.08); },
    hit: function () { if (!throttle('hit', 90)) return; tone(300, 90, 0.14, 'sawtooth', 0.13); },
    boom: function () { if (!throttle('boom', 150)) return; tone(160, 40, 0.35, 'sawtooth', 0.18); tone(90, 30, 0.4, 'triangle', 0.16, 0.03); },
    hurt: function () { if (!throttle('hurt', 200)) return; tone(220, 70, 0.28, 'square', 0.16); },
    clear: function () { if (!throttle('clear', 500)) return; tone(523, 523, 0.12, 'triangle', 0.17); tone(659, 659, 0.12, 'triangle', 0.17, 0.11); tone(784, 784, 0.12, 'triangle', 0.17, 0.22); tone(1046, 1046, 0.26, 'triangle', 0.17, 0.33); },
    over: function () { if (!throttle('over', 500)) return; tone(392, 392, 0.16, 'triangle', 0.16); tone(330, 330, 0.16, 'triangle', 0.16, 0.15); tone(262, 262, 0.16, 'triangle', 0.16, 0.3); tone(196, 160, 0.34, 'triangle', 0.16, 0.45); }
  };
})();
