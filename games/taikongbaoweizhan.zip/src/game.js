(function () {
  "use strict";

  const LEVELS = {
    easy: { rows: 3, cols: 8, speed: 0.6, lives: 3, fireChance: 0.0012, maxBullets: 5 },
    medium: { rows: 4, cols: 10, speed: 0.9, lives: 3, fireChance: 0.005, maxBullets: 8 },
    hard: { rows: 5, cols: 11, speed: 1.3, lives: 2, fireChance: 0.012, maxBullets: 12 },
  };

  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");

  let state = {
    level: "easy",
    score: 0,
    lives: 3,
    wave: 1,
    running: false,
    gameOver: false,
    ship: { x: 220, y: 600, w: 40, h: 16 },
    bullets: [],
    enemyBullets: [],
    aliens: [],
    bunkers: [],
    dir: 1,
    stepTimer: 0,
    keys: { left: false, right: false },
    shootCooldown: 0,
    paused: false,
    invuln: 0,
    particles: [],
    frame: 0,
    best: loadBest(),
  };

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];

  function cfg() {
    return LEVELS[state.level];
  }

  function createAliens() {
    const { rows, cols } = cfg();
    const aliens = [];
    const gapX = Math.min(42, (canvas.width - 40) / cols);
    const startX = (canvas.width - cols * gapX) / 2 + 10;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        aliens.push({
          x: startX + c * gapX,
          y: 40 + r * 36 + (state.wave - 1) * 8,
          w: 28,
          h: 20,
          alive: true,
          row: r,
        });
      }
    }
    return aliens;
  }

  function createBunkers() {
    const bunkers = [];
    const positions = [70, 200, 330];
    positions.forEach((bx) => {
      for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 5; c++) {
          if (r === 2 && c > 0 && c < 4) continue;
          bunkers.push({ x: bx + c * 12, y: 520 + r * 10, w: 11, h: 9, hp: 3 });
        }
      }
    });
    return bunkers;
  }

  function updateHud() {
    $("#scoreEl").textContent = state.score;
    $("#livesEl").textContent = state.lives;
    $("#waveEl").textContent = state.wave;
    $("#bestEl").textContent = state.best;
  }

  function resetRound(full) {
    if (full) {
      state.score = 0;
      state.lives = cfg().lives;
      state.wave = 1;
    }
    state.ship.x = canvas.width / 2 - 20;
    state.bullets = [];
    state.enemyBullets = [];
    state.aliens = createAliens();
    state.bunkers = createBunkers();
    state.dir = 1;
    state.stepTimer = 0;
    state.shootCooldown = 0;
    state.gameOver = false;
    state.running = true;
    state.paused = false;
    state.invuln = 0;
    state.particles = [];
    updateHud();
    $("#resultOverlay").classList.add("hidden");
    $("#pauseVeil").classList.add("hidden");
    $("#pauseBtn").textContent = "暂停";
  }

  function aliveAliens() {
    return state.aliens.filter((a) => a.alive);
  }

  function firePlayer() {
    if (state.shootCooldown > 0 || !state.running || state.paused) return;
    state.bullets.push({
      x: state.ship.x + state.ship.w / 2 - 2,
      y: state.ship.y,
      w: 4,
      h: 10,
      vy: -8,
    });
    state.shootCooldown = 12;
    if (typeof sfx !== 'undefined') { sfx.shoot(); }
  }

  function hit(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  function endGame(won) {
    if (state.gameOver) return;
    state.running = false;
    state.gameOver = true;
    state.paused = false;
    $("#pauseVeil").classList.add("hidden");
    $("#pauseBtn").textContent = "暂停";
    const isRecord = state.score > state.best;
    if (isRecord) { state.best = state.score; saveBest(); }
    if (won) {
      state.wave++;
      $("#resultTitle").textContent = "第 " + (state.wave - 1) + " 波已击退！";
      $("#playAgainBtn").textContent = "下一波";
      if (typeof sfx !== 'undefined') { sfx.clear(); }
    } else {
      $("#resultTitle").textContent = "防线失守";
      $("#playAgainBtn").textContent = "再来一局";
      if (typeof sfx !== 'undefined') { sfx.over(); }
    }
    $("#resultMsg").textContent = "得分：" + state.score;
    $("#resultBest").textContent = "最高分：" + state.best;
    $("#resultRecord").style.display = isRecord ? "block" : "none";
    $("#resultOverlay").classList.remove("hidden");
    updateHud();
    updateBestDisplays();
  }

  function update() {
    if (!state.running || state.paused) return;
    state.frame++;
    if (state.invuln > 0) state.invuln--;
    state.particles = state.particles.filter((p) => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.05;
      p.life--;
      return p.life > 0;
    });
    const c = cfg();
    const speed = c.speed * (1 + (state.wave - 1) * 0.15);

    if (state.keys.left) state.ship.x -= 5;
    if (state.keys.right) state.ship.x += 5;
    state.ship.x = Math.max(8, Math.min(canvas.width - state.ship.w - 8, state.ship.x));
    if (state.shootCooldown > 0) state.shootCooldown--;

    state.stepTimer++;
    if (state.stepTimer > Math.max(18, 40 - speed * 10)) {
      state.stepTimer = 0;
      let hitEdge = false;
      const living = aliveAliens();
      living.forEach((a) => {
        a.x += state.dir * 12 * Math.min(speed, 2);
        if (a.x < 8 || a.x + a.w > canvas.width - 8) hitEdge = true;
      });
      if (hitEdge) {
        state.dir *= -1;
        living.forEach((a) => {
          a.y += 16;
        });
      }
    }

    const livingAfter = aliveAliens();
    livingAfter.forEach((a) => {
      if (state.enemyBullets.length < c.maxBullets && Math.random() < c.fireChance * (1 + state.wave * 0.1)) {
        state.enemyBullets.push({
          x: a.x + a.w / 2 - 2,
          y: a.y + a.h,
          w: 4,
          h: 10,
          vy: 4 + speed,
        });
      }
      if (a.y + a.h >= state.ship.y) {
        endGame(false);
      }
    });

    state.bullets.forEach((b) => {
      b.y += b.vy;
    });
    state.enemyBullets.forEach((b) => {
      b.y += b.vy;
    });

    // player bullets vs aliens / bunkers
    state.bullets = state.bullets.filter((b) => {
      if (b.y + b.h < 0) return false;
      for (const a of state.aliens) {
        if (a.alive && hit(b, a)) {
          a.alive = false;
          state.score += 10;
          spawnExplosion(a.x + a.w / 2, a.y + a.h / 2, rowColor(a), 10);
          if (typeof sfx !== 'undefined') { sfx.hit(); }
          updateHud();
          return false;
        }
      }
      for (const bk of state.bunkers) {
        if (bk.hp > 0 && hit(b, bk)) {
          bk.hp--;
          if (bk.hp === 0) {
            spawnExplosion(bk.x + bk.w / 2, bk.y + bk.h / 2, "#22c55e", 6);
            if (typeof sfx !== 'undefined') { sfx.boom(); }
          }
          return false;
        }
      }
      return true;
    });

    state.enemyBullets = state.enemyBullets.filter((b) => {
      if (b.y > canvas.height) return false;
      if (state.invuln <= 0 && hit(b, state.ship)) {
        state.lives--;
        state.invuln = 60;
        spawnExplosion(state.ship.x + state.ship.w / 2, state.ship.y + 8, "#fbbf24", 14);
        if (typeof sfx !== 'undefined') { sfx.hurt(); }
        updateHud();
        if (state.lives <= 0) endGame(false);
        return false;
      }
      for (const bk of state.bunkers) {
        if (bk.hp > 0 && hit(b, bk)) {
          bk.hp--;
          if (bk.hp === 0) {
            spawnExplosion(bk.x + bk.w / 2, bk.y + bk.h / 2, "#22c55e", 6);
            if (typeof sfx !== 'undefined') { sfx.boom(); }
          }
          return false;
        }
      }
      return true;
    });

    if (aliveAliens().length === 0) endGame(true);
  }

  function draw() {
    // 深空底：竖向渐变 + 星云 + 闪烁星点
    const bgGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    bgGrad.addColorStop(0, "#050816");
    bgGrad.addColorStop(0.55, "#0a1030");
    bgGrad.addColorStop(1, "#050816");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    let neb = ctx.createRadialGradient(110, 140, 10, 110, 140, 190);
    neb.addColorStop(0, "rgba(124,58,237,0.20)");
    neb.addColorStop(1, "rgba(124,58,237,0)");
    ctx.fillStyle = neb;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    neb = ctx.createRadialGradient(390, 430, 10, 390, 430, 210);
    neb.addColorStop(0, "rgba(37,99,235,0.16)");
    neb.addColorStop(1, "rgba(37,99,235,0)");
    ctx.fillStyle = neb;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    STARS.forEach((s) => {
      const tw = 0.35 + 0.3 * Math.sin(state.frame * 0.05 + s.ph);
      ctx.fillStyle = "rgba(255,255,255," + tw.toFixed(2) + ")";
      ctx.fillRect(s.x, s.y, s.s, s.s);
    });

    // 掩体（霓虹绿，按耐久变色）
    state.bunkers.forEach((bk) => {
      if (bk.hp <= 0) return;
      ctx.fillStyle = bk.hp === 3 ? "#22c55e" : bk.hp === 2 ? "#84cc16" : "#a3e635";
      ctx.fillRect(bk.x, bk.y, bk.w, bk.h);
      ctx.fillStyle = "rgba(255,255,255,0.25)";
      ctx.fillRect(bk.x, bk.y, bk.w, 2);
    });

    // 外星人（像素侵略者位图，按行霓虹色，双帧摆腿）
    state.aliens.forEach((a) => {
      if (a.alive) drawInvader(a);
    });

    // 星舰（无敌时闪烁）
    if (!(state.invuln > 0 && Math.floor(state.frame / 4) % 2 === 0)) drawShip();

    // 子弹（发光）
    ctx.shadowBlur = 8;
    ctx.shadowColor = "#22d3ee";
    ctx.fillStyle = "#a5f3fc";
    state.bullets.forEach((b) => ctx.fillRect(b.x, b.y, b.w, b.h));
    ctx.shadowColor = "#ef4444";
    ctx.fillStyle = "#fca5a5";
    state.enemyBullets.forEach((b) => ctx.fillRect(b.x, b.y, b.w, b.h));
    ctx.shadowBlur = 0;

    // 爆炸粒子
    state.particles.forEach((p) => {
      ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, p.size, p.size);
    });
    ctx.globalAlpha = 1;
  }

  function loop() {
    update();
    draw();
    if (state.running) requestAnimationFrame(loop);
  }

  function startGame(level) {
    state.level = level;
    $("#levelScreen").classList.add("hidden");
    $("#gameScreen").classList.remove("hidden");
    $("#levelBadge").textContent = level === "easy" ? "简单" : level === "medium" ? "普通" : "困难";
    resetRound(true);
    requestAnimationFrame(loop);
  }

  function goToLevelScreen() {
    state.running = false;
    state.paused = false;
    $("#gameScreen").classList.add("hidden");
    $("#resultOverlay").classList.add("hidden");
    $("#pauseVeil").classList.add("hidden");
    $("#pauseBtn").textContent = "暂停";
    $("#levelScreen").classList.remove("hidden");
    updateBestDisplays();
  }

  document.addEventListener("DOMContentLoaded", () => {
    $$(".level-btn").forEach((btn) => btn.addEventListener("click", () => startGame(btn.dataset.level)));
    $("#newGameBtn").addEventListener("click", () => {
      const needsRestart = !state.running;
      resetRound(true);
      if (needsRestart) requestAnimationFrame(loop);
    });
    $("#changeLevelBtn").addEventListener("click", goToLevelScreen);
    $("#playAgainBtn").addEventListener("click", () => {
      const nextWave = $("#playAgainBtn").textContent === "下一波";
      const needsRestart = !state.running;
      resetRound(!nextWave);
      if (needsRestart) requestAnimationFrame(loop);
    });
    $("#changeLevelFromResultBtn").addEventListener("click", goToLevelScreen);

    window.addEventListener("keydown", (e) => {
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") state.keys.left = true;
      if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") state.keys.right = true;
      if (e.key === " " || e.key === "Spacebar") {
        e.preventDefault();
        firePlayer();
      }
    });
    window.addEventListener("keyup", (e) => {
      if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") state.keys.left = false;
      if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") state.keys.right = false;
    });

    const bindHold = (el, key) => {
      el.addEventListener("touchstart", (e) => {
        e.preventDefault();
        state.keys[key] = true;
      });
      el.addEventListener("touchend", () => {
        state.keys[key] = false;
      });
      el.addEventListener("mousedown", () => {
        state.keys[key] = true;
      });
      el.addEventListener("mouseup", () => {
        state.keys[key] = false;
      });
      el.addEventListener("mouseleave", () => {
        state.keys[key] = false;
      });
    };
    bindHold($("#leftBtn"), "left");
    bindHold($("#rightBtn"), "right");
    $("#fireBtn").addEventListener("click", firePlayer);
    $("#fireBtn").addEventListener("touchstart", (e) => {
      e.preventDefault();
      firePlayer();
    });

    $("#helpBtnLevel").addEventListener("click", () => $("#helpOverlay").classList.remove("hidden"));
    $("#helpBtnGame").addEventListener("click", () => $("#helpOverlay").classList.remove("hidden"));
    $("#helpClose").addEventListener("click", () => $("#helpOverlay").classList.add("hidden"));
    $("#helpOverlay").addEventListener("click", (e) => {
      if (e.target.id === "helpOverlay") $("#helpOverlay").classList.add("hidden");
    });
  });
  // ---------- 改编版新增：最高分 / 粒子 / 精灵 / 暂停 ----------
  const ROW_COLORS = ["#39ff6a", "#22d3ee", "#a3e635", "#2dd4bf", "#4ade80"];
  const INVADER_A = [
    "00100000100",
    "00010001000",
    "00111111100",
    "01101110110",
    "11111111111",
    "10111111101",
    "10100000101",
    "00011011000",
  ];
  const INVADER_B = [
    "00100000100",
    "10010001001",
    "10111111101",
    "11101110111",
    "11111111111",
    "01111111110",
    "00100000100",
    "01000000010",
  ];
  const STARS = [];
  for (let i = 0; i < 70; i++) {
    STARS.push({ x: (i * 97 + 31) % 480, y: (i * 61 + 17) % 640, s: i % 5 === 0 ? 2 : 1, ph: i * 0.7 });
  }

  function rowColor(a) {
    return ROW_COLORS[(a.row || 0) % ROW_COLORS.length];
  }

  function spawnExplosion(x, y, color, n) {
    for (let i = 0; i < n; i++) {
      const ang = (Math.PI * 2 * i) / n + Math.random() * 0.6;
      const spd = 0.6 + Math.random() * 1.8;
      state.particles.push({
        x: x, y: y,
        vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd - 0.4,
        life: 22 + Math.floor(Math.random() * 14), maxLife: 36,
        color: color, size: 2 + Math.floor(Math.random() * 3),
      });
    }
  }

  function loadBest() {
    try {
      const v = parseInt(localStorage.getItem('spaceinvaders_best'), 10);
      if (!isNaN(v) && v > 0) return v;
    } catch (e) {}
    return 0;
  }

  function saveBest() {
    try { localStorage.setItem('spaceinvaders_best', String(state.best)); } catch (e) {}
  }

  function updateBestDisplays() {
    const el = document.getElementById('bestOnLevel');
    if (el) el.textContent = state.best;
  }

  function drawInvader(a) {
    const bmp = Math.floor(state.frame / 30) % 2 === 0 ? INVADER_A : INVADER_B;
    const px = a.w / 11;
    ctx.fillStyle = rowColor(a);
    for (let r = 0; r < bmp.length; r++) {
      for (let c = 0; c < 11; c++) {
        if (bmp[r][c] === "1") ctx.fillRect(a.x + c * px, a.y + r * (a.h / 8), px + 0.5, a.h / 8 + 0.5);
      }
    }
  }

  function drawShip() {
    const s = state.ship;
    const cx = s.x + s.w / 2;
    // 引擎火焰（帧间抖动）
    const flame = 6 + (state.frame % 4);
    ctx.fillStyle = "#f59e0b";
    ctx.beginPath();
    ctx.moveTo(cx - 4, s.y + s.h - 2);
    ctx.lineTo(cx + 4, s.y + s.h - 2);
    ctx.lineTo(cx, s.y + s.h - 2 + flame);
    ctx.closePath();
    ctx.fill();
    // 机身
    ctx.fillStyle = "#bae6fd";
    ctx.beginPath();
    ctx.moveTo(cx, s.y - 10);
    ctx.lineTo(s.x + 6, s.y + 6);
    ctx.lineTo(s.x + 2, s.y + s.h - 2);
    ctx.lineTo(s.x + 12, s.y + s.h - 6);
    ctx.lineTo(s.x + s.w - 12, s.y + s.h - 6);
    ctx.lineTo(s.x + s.w - 2, s.y + s.h - 2);
    ctx.lineTo(s.x + s.w - 6, s.y + 6);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "#38bdf8";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    // 驾驶舱
    ctx.fillStyle = "#22d3ee";
    ctx.beginPath();
    ctx.arc(cx, s.y + 2, 3.5, 0, Math.PI * 2);
    ctx.fill();
  }

  function togglePause() {
    if (!state.running || state.gameOver) return;
    state.paused = !state.paused;
    $("#pauseBtn").textContent = state.paused ? "继续" : "暂停";
    if (state.paused) $("#pauseVeil").classList.remove("hidden");
    else $("#pauseVeil").classList.add("hidden");
  }

  $("#pauseBtn").addEventListener("click", togglePause);
  $("#resumeBtn").addEventListener("click", togglePause);
  updateBestDisplays();

  /* ======================================================================
   * Test bridge (window.SI)
   * ==================================================================== */
  window.SI = {
    getState: function () {
      return {
        phase: state.gameOver ? 'over' : (state.paused ? 'paused' : (state.running ? 'playing' : 'level')),
        level: state.level, score: state.score, lives: state.lives, wave: state.wave,
        best: state.best, paused: state.paused, running: state.running, gameOver: state.gameOver,
        aliensAlive: aliveAliens().length, shipX: state.ship.x, shipY: state.ship.y,
        bullets: state.bullets.length, enemyBullets: state.enemyBullets.length,
        invuln: state.invuln, fireChance: cfg().fireChance, maxBullets: cfg().maxBullets
      };
    },
    start: function (level) { startGame(level || state.level); return window.SI.getState(); },
    fire: function () { firePlayer(); return window.SI.getState(); },
    setKey: function (dir, on) { state.keys[dir] = !!on; return window.SI.getState(); },
    togglePause: function () { togglePause(); return window.SI.getState(); },
    setLives: function (n) { state.lives = n; updateHud(); return window.SI.getState(); },
    spawnEnemyBulletAtShip: function () {
      state.enemyBullets.push({ x: state.ship.x + state.ship.w / 2 - 2, y: state.ship.y - 30, w: 4, h: 10, vy: 5 });
      return window.SI.getState();
    },
    debugShootAlien: function () {
      const living = aliveAliens();
      if (living.length) {
        let t = living[0];
        living.forEach((a) => { if (a.y > t.y) t = a; });
        state.bullets.push({ x: t.x + t.w / 2 - 2, y: t.y + t.h + 4, w: 4, h: 10, vy: -8 });
      }
      return window.SI.getState();
    },
    killAllAliens: function () { state.aliens.forEach((a) => { a.alive = false; }); return window.SI.getState(); },
    reloadBest: function () { state.best = loadBest(); updateHud(); updateBestDisplays(); return window.SI.getState(); }
  };
})();
