'use strict';

  var T = LiteI18N.create({
    title:     { en: 'Fruit Catcher',          zh: '水果接接乐' },
    score:     { en: 'Score',                  zh: '得分' },
    lives:     { en: 'Lives',                  zh: '生命' },
    level:     { en: 'Level',                  zh: '等级' },
    new:       { en: 'New',                    zh: '新游戏' },
    playAgain: { en: 'Play again',             zh: '再玩一局' },
    close:     { en: 'Close',                  zh: '关闭' },
    caught:    { en: 'Caught',                 zh: '接到' },
    dropped:   { en: 'Missed',                 zh: '漏掉' },
    best:      { en: 'Best',                   zh: '最高分' },
    over:     { en: 'Game over',               zh: '游戏结束' },
    perfect:  { en: 'Perfect harvest!',        zh: '完美丰收！' },
    great:    { en: 'Great catching!',         zh: '眼疾手快！' },
    nice:     { en: 'Nice work!',              zh: '手感不错！' },
    keepon:   { en: 'Keep practicing!',        zh: '再练练手' },
    move:     { en: 'Move',                    zh: '移动' },
    pause:    { en: 'Pause',                   zh: '暂停' },
    resume:   { en: 'Resume',                  zh: '继续' },
    paused:   { en: 'Paused',                  zh: '已暂停' }
  });

  // ---------- canvas setup ----------
  var cvs = document.getElementById('game');
  var ctx = cvs.getContext('2d');
  var W = cvs.width, H = cvs.height;
  var DPR = window.devicePixelRatio || 1;
  if (DPR !== 1) {
    cvs.width = W * DPR; cvs.height = H * DPR;
    cvs.style.width = '100%'; cvs.style.height = 'auto';
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  }

  // ---------- game state ----------
  var score = 0, lives = 3, level = 1;
  var best = +(localStorage.getItem('fruitcatcher_best') || 0);
  var items = [];        // { x, y, vy, kind, rot, spin }
  var particles = [];    // catch/burst visuals
  var floaters = [];     // floating score text (+10)
  var basket = { x: W / 2, y: H - 40, height: 36, width: 90 };
  var spawnTimer = 0;
  var elapsed = 0;
  var running = false;
  var started = false;   // newGame() 后为真，区分开局前与暂停
  var lastTs = 0;
  var pointerActive = false;
  var stats = { caught: 0, dropped: 0, bombs: 0 };

  var FRUITS = [
    { key: 'apple',  s: 10, w: 1.0 },
    { key: 'banana', s: 12, w: 0.9 },
    { key: 'grape',  s: 14, w: 0.8 },
    { key: 'melon',  s: 16, w: 0.7 },
    { key: 'peach',  s: 18, w: 0.55 },
    { key: 'berry',  s: 20, w: 0.4 }
  ];
  var BOMB = { key: 'bomb', s: -1, w: 0.3 };

  // ---------- helpers ----------
  function rand(min, max) { return min + Math.random() * (max - min); }
  function pickKind() {
    // Fruits plus an increasingly large bomb pool as level grows.
    var pool = [];
    FRUITS.forEach(function (f) {
      for (var i = 0; i < Math.round(f.w * 10); i++) pool.push(f);
    });
    var bombWeight = Math.min(8, 2 + level);
    for (var j = 0; j < bombWeight; j++) pool.push(BOMB);
    return pool[(Math.random() * pool.length) | 0];
  }

  function spawn() {
    var kind = pickKind();
    var r = 22 + Math.random() * 8;
    items.push({
      x: rand(r + 4, W - r - 4),
      y: -r,
      vy: (90 + level * 12 + Math.random() * 18) * H / 380,
      r: r,
      kind: kind,
      rot: Math.random() * Math.PI * 2,
      spin: rand(-0.05, 0.05)
    });
  }

  // Catch sparkle particle
  function sparkle(x, y, color) {
    for (var i = 0; i < 8; i++) {
      var a = Math.random() * Math.PI * 2;
      var d = rand(20, 60);
      particles.push({
        x: x, y: y,
        vx: Math.cos(a) * d, vy: Math.sin(a) * d - 30,
        life: 1, decay: rand(1.8, 2.6),
        r: rand(2, 4),
        color: color
      });
    }
  }

  // Bomb explosion particles
  function boom(x, y) {
    var palette = ['#ffd54f', '#ff9100', '#ff3d00', '#b71c1c'];
    for (var i = 0; i < 18; i++) {
      var a = Math.random() * Math.PI * 2;
      var d = rand(40, 110);
      particles.push({
        x: x, y: y,
        vx: Math.cos(a) * d, vy: Math.sin(a) * d,
        life: 1, decay: rand(1.2, 2),
        r: rand(2, 5),
        color: palette[(Math.random() * palette.length) | 0],
        grav: 120
      });
    }
    // shock wave ring
    particles.push({
      ring: true, x: x, y: y, r: 8, grow: 220, life: 1, decay: 3.5
    });
    // shake the stage
    var stage = document.getElementById('stage');
    stage.classList.remove('shake');
    void stage.offsetWidth;
    stage.classList.add('shake');
  }

  // ---------- input ----------
  function setBasketX(clientX) {
    var rect = cvs.getBoundingClientRect();
    var x = (clientX - rect.left) * (W / rect.width);  // 画布 CSS 缩放后按比例换算
    basket.x = Math.max(basket.width / 2, Math.min(W - basket.width / 2, x));
  }

  cvs.addEventListener('mousemove', function (ev) {
    if (!running) return;
    setBasketX(ev.clientX);
  });
  cvs.addEventListener('touchmove', function (ev) {
    if (!running || !ev.touches[0]) return;
    setBasketX(ev.touches[0].clientX);
    ev.preventDefault();
  }, { passive: false });
  cvs.addEventListener('touchstart', function (ev) {
    pointerActive = true;
    if (ev.touches[0]) setBasketX(ev.touches[0].clientX);
    ev.preventDefault();
  }, { passive: false });
  cvs.addEventListener('mousedown', function (ev) { pointerActive = true; setBasketX(ev.clientX); });
  window.addEventListener('mouseup', function () { pointerActive = false; });

  var keys = {};
  var keyLeft = document.getElementById('keyLeft');
  var keyRight = document.getElementById('keyRight');

  function updateKeyHints() {
    var left = !!(keys.ArrowLeft || keys.a);
    var right = !!(keys.ArrowRight || keys.d);
    keyLeft.classList.toggle('active', left);
    keyRight.classList.toggle('active', right);
  }

  // Touch hold buttons: press-and-hold to move (same keys path as keyboard).
  function bindHoldButton(el, keyName) {
    function on(ev) { if (ev.preventDefault) ev.preventDefault(); keys[keyName] = true; updateKeyHints(); }
    function off(ev) { if (ev.preventDefault) ev.preventDefault(); keys[keyName] = false; updateKeyHints(); }
    el.addEventListener('touchstart', on, { passive: false });
    el.addEventListener('touchend', off);
    el.addEventListener('touchcancel', off);
    el.addEventListener('mousedown', on);
    el.addEventListener('mouseup', off);
    el.addEventListener('mouseleave', off);
  }
  bindHoldButton(keyLeft, 'ArrowLeft');
  bindHoldButton(keyRight, 'ArrowRight');

  window.addEventListener('keydown', function (ev) {
    var k = ev.key;
    keys[k] = true;
    if (k === ' ' || k === 'Enter') { ev.preventDefault(); togglePause(); }
    if (k === 'Escape') { closeDialog(); }
    updateKeyHints();
  });
  window.addEventListener('keyup', function (ev) { keys[ev.key] = false; updateKeyHints(); });
  window.addEventListener('blur', function () {
    Object.keys(keys).forEach(function (k) { keys[k] = false; });
    updateKeyHints();
  });

  function processKeys(dt) {
    if (keys.ArrowLeft || keys.a)  basket.x -= 360 * dt;
    if (keys.ArrowRight || keys.d) basket.x += 360 * dt;
    basket.x = Math.max(basket.width / 2, Math.min(W - basket.width / 2, basket.x));
  }

  // ---------- update ----------
  function update(dt) {
    elapsed += dt;
    level = 1 + Math.floor(elapsed / 12);
    if (level > 99) level = 99;

    // Spawn cadence grows with level but stays sane.
    var interval = Math.max(0.35, 1.1 - level * 0.06);
    spawnTimer += dt;
    if (spawnTimer >= interval) { spawnTimer = 0; spawn(); }

    // Items fall
    for (var i = items.length - 1; i >= 0; i--) {
      var it = items[i];
      it.y += it.vy * dt;
      it.rot += it.spin;
      // Catch check: vertical overlap + horizontal overlap with basket mouth.
      var top = it.y + it.r;
      var basketTop = basket.y;
      var basketLeft = basket.x - basket.width / 2;
      var basketRight = basket.x + basket.width / 2;
      if (top >= basketTop && it.y - it.r < basketTop + basket.height &&
          it.x >= basketLeft && it.x <= basketRight) {
        if (it.kind === BOMB) {
          loseLife(it.x, basketTop);
        } else {
          catchFruit(it);
        }
        items.splice(i, 1);
        continue;
      }
      // Missed (off-screen at the bottom)
      if (it.y - it.r > H + 20) {
        if (it.kind !== BOMB) {
          // missing a fruit costs a life too
          loseLife(W / 2, H, true);
          stats.dropped++;
        }
        items.splice(i, 1);
      }
    }

    // Floating score text
    for (var f = floaters.length - 1; f >= 0; f--) {
      var fl = floaters[f];
      fl.y -= 34 * dt;
      fl.life -= dt * 1.1;
      if (fl.life <= 0) floaters.splice(f, 1);
    }

    // Particles
    for (var p = particles.length - 1; p >= 0; p--) {
      var pa = particles[p];
      if (pa.ring) {
        pa.r += pa.grow * dt;
        pa.life -= pa.decay * dt;
      } else {
        pa.x += pa.vx * dt;
        pa.y += pa.vy * dt;
        if (pa.grav) pa.vy += pa.grav * dt;
        pa.vx *= 0.96; pa.vy *= 0.96;
        pa.life -= pa.decay * dt;
      }
      if (pa.life <= 0) particles.splice(p, 1);
    }
  }

  function catchFruit(it) {
    score += it.kind.s;
    stats.caught++;
    floaters.push({ x: it.x, y: it.y - 10, text: '+' + it.kind.s, life: 1 });
    if (typeof sfx !== 'undefined') { sfx.catch(); }
    var palette = ['#ffd54f', '#ff9100', '#66bb6a', '#ef5350'];
    sparkle(it.x, it.y, palette[(Math.random() * palette.length) | 0]);
    updateHud();
  }

  function loseLife(x, y, silent) {
    lives--;
    stats.bombs++;
    if (!silent) boom(x, y);
    if (typeof sfx !== 'undefined') { if (silent) { sfx.miss(); } else { sfx.bomb(); } }
    flashHud();
    updateHud();
    if (lives <= 0) endGame();
  }

  // ---------- render ----------
  function drawBasket() {
    var bx = basket.x - basket.width / 2;
    var by = basket.y;
    var bw = basket.width;
    var bh = basket.height;

    ctx.fillStyle = 'rgba(0,0,0,0.15)';
    ctx.beginPath();
    ctx.ellipse(basket.x, by + bh - 2, bw / 2 + 6, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    var grad = ctx.createLinearGradient(bx, by, bx, by + bh);
    grad.addColorStop(0, '#d4a373');
    grad.addColorStop(0.6, '#b1732d');
    grad.addColorStop(1, '#8a5a23');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(bx + 6, by);
    ctx.lineTo(bx + bw - 6, by);
    ctx.lineTo(bx + bw - 2, by + bh - 10);
    ctx.quadraticCurveTo(bx + bw / 2, by + bh + 6, bx + 2, by + bh - 10);
    ctx.closePath();
    ctx.fill();

    // weave pattern
    ctx.strokeStyle = 'rgba(255, 220, 170, .55)';
    ctx.lineWidth = 1.5;
    for (var yy = by + 6; yy < by + bh - 4; yy += 6) {
      ctx.beginPath();
      ctx.moveTo(bx + 4, yy);
      ctx.lineTo(bx + bw - 4, yy);
      ctx.stroke();
    }
    for (var xx = bx + 10; xx < bx + bw; xx += 12) {
      ctx.beginPath();
      ctx.moveTo(xx, by + 4);
      ctx.lineTo(xx, by + bh - 6);
      ctx.stroke();
    }
  }

  function drawItem(it) {
    ctx.save();
    ctx.translate(it.x, it.y);
    ctx.rotate(it.rot);
    var r = it.r;
    var key = it.kind.key;
    if (key === 'apple') {
      ctx.fillStyle = '#e53935';
      ctx.beginPath(); ctx.arc(0, 0, r * 0.88, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#6d4c41'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(0, -r * 0.8); ctx.lineTo(r * 0.12, -r * 1.15); ctx.stroke();
      ctx.fillStyle = '#66bb6a';
      ctx.beginPath(); ctx.ellipse(r * 0.3, -r * 0.95, r * 0.32, r * 0.16, 0.5, 0, Math.PI * 2); ctx.fill();
    } else if (key === 'banana') {
      ctx.strokeStyle = '#fdd835'; ctx.lineWidth = r * 0.5; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(0, 0, r * 0.55, 0.25 * Math.PI, 1.05 * Math.PI); ctx.stroke();
      ctx.fillStyle = '#f9a825';
      ctx.beginPath(); ctx.arc(-r * 0.42, r * 0.5, r * 0.12, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(r * 0.55, r * 0.32, r * 0.12, 0, Math.PI * 2); ctx.fill();
    } else if (key === 'grape') {
      ctx.fillStyle = '#8e24aa';
      var offs = [[0, -r * 0.55], [-r * 0.4, -r * 0.2], [r * 0.4, -r * 0.2],
                  [-r * 0.2, r * 0.25], [r * 0.2, r * 0.25], [0, r * 0.6]];
      for (var gi = 0; gi < offs.length; gi++) {
        ctx.beginPath(); ctx.arc(offs[gi][0], offs[gi][1], r * 0.36, 0, Math.PI * 2); ctx.fill();
      }
      ctx.strokeStyle = '#6d4c41'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(0, -r * 0.85); ctx.lineTo(r * 0.1, -r * 1.15); ctx.stroke();
    } else if (key === 'melon') {
      // Watermelon wedge: green rind, white ring, red flesh, seeds.
      ctx.fillStyle = '#43a047';
      ctx.beginPath(); ctx.arc(0, 0, r * 0.95, 0, Math.PI); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#e8f5e9';
      ctx.beginPath(); ctx.arc(0, 0, r * 0.8, 0, Math.PI); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#ef5350';
      ctx.beginPath(); ctx.arc(0, 0, r * 0.68, 0, Math.PI); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#263238';
      var seeds = [[-r * 0.3, r * 0.25], [0, r * 0.4], [r * 0.3, r * 0.25]];
      for (var si = 0; si < seeds.length; si++) {
        ctx.beginPath(); ctx.arc(seeds[si][0], seeds[si][1], r * 0.06, 0, Math.PI * 2); ctx.fill();
      }
    } else if (key === 'peach') {
      ctx.fillStyle = '#ffab91';
      ctx.beginPath(); ctx.arc(0, 0, r * 0.88, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#e57373'; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 0.55, 0.3 * Math.PI, 0.75 * Math.PI); ctx.stroke();
      ctx.fillStyle = '#66bb6a';
      ctx.beginPath(); ctx.ellipse(r * 0.25, -r * 0.9, r * 0.3, r * 0.15, 0.5, 0, Math.PI * 2); ctx.fill();
    } else if (key === 'berry') {
      ctx.fillStyle = '#e53935';
      ctx.beginPath();
      ctx.moveTo(0, r * 0.9);
      ctx.quadraticCurveTo(-r * 0.95, -r * 0.1, -r * 0.55, -r * 0.7);
      ctx.quadraticCurveTo(0, -r * 1.0, r * 0.55, -r * 0.7);
      ctx.quadraticCurveTo(r * 0.95, -r * 0.1, 0, r * 0.9);
      ctx.fill();
      ctx.fillStyle = '#fff8e1';
      var dots = [[-r * 0.3, -r * 0.2], [r * 0.3, -r * 0.2], [0, r * 0.15], [-r * 0.15, r * 0.45], [r * 0.15, r * 0.45]];
      for (var di = 0; di < dots.length; di++) {
        ctx.beginPath(); ctx.arc(dots[di][0], dots[di][1], r * 0.07, 0, Math.PI * 2); ctx.fill();
      }
      ctx.fillStyle = '#43a047';
      ctx.beginPath();
      ctx.moveTo(-r * 0.5, -r * 0.65); ctx.lineTo(0, -r * 1.05); ctx.lineTo(r * 0.5, -r * 0.65);
      ctx.lineTo(r * 0.2, -r * 0.55); ctx.lineTo(-r * 0.2, -r * 0.55);
      ctx.closePath(); ctx.fill();
    } else {
      // bomb: black ball + fuse + spark
      ctx.fillStyle = '#212121';
      ctx.beginPath(); ctx.arc(0, 0, r * 0.85, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.beginPath(); ctx.arc(-r * 0.3, -r * 0.3, r * 0.22, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#8d6e63'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(0, -r * 0.8);
      ctx.quadraticCurveTo(r * 0.3, -r * 1.15, r * 0.55, -r * 1.0); ctx.stroke();
      ctx.fillStyle = '#ffca28';
      var sx = r * 0.55, sy = -r * 1.0, sr = r * 0.22;
      ctx.beginPath();
      ctx.moveTo(sx, sy - sr); ctx.lineTo(sx + sr * 0.3, sy - sr * 0.3);
      ctx.lineTo(sx + sr, sy); ctx.lineTo(sx + sr * 0.3, sy + sr * 0.3);
      ctx.lineTo(sx, sy + sr); ctx.lineTo(sx - sr * 0.3, sy + sr * 0.3);
      ctx.lineTo(sx - sr, sy); ctx.lineTo(sx - sr * 0.3, sy - sr * 0.3);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }

  function drawParticles() {
    for (var i = 0; i < particles.length; i++) {
      var pa = particles[i];
      if (pa.ring) {
        ctx.strokeStyle = 'rgba(255, 180, 50, ' + Math.max(0, pa.life) + ')';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(pa.x, pa.y, pa.r, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        ctx.fillStyle = pa.color;
        ctx.globalAlpha = Math.max(0, pa.life);
        ctx.beginPath();
        ctx.arc(pa.x, pa.y, pa.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
    }
  }

  function drawCloud(t) {
    // Cheerful background clouds drifting slowly.
    ctx.save();
    ctx.globalAlpha = 0.55;
    ctx.fillStyle = '#fff';
    function cloud(cx, cy, s) {
      ctx.beginPath();
      ctx.arc(cx, cy, 18 * s, 0, Math.PI * 2);
      ctx.arc(cx + 18 * s, cy + 4, 22 * s, 0, Math.PI * 2);
      ctx.arc(cx + 38 * s, cy, 18 * s, 0, Math.PI * 2);
      ctx.fill();
    }
    var drift = (t * 8) % (W + 80);
    cloud(-80 + drift, 40, 1);
    cloud(W - 60 - drift * 0.7, 80, 0.7);
    cloud(W * 0.6 - drift * 0.5, 30, 0.9);
    ctx.restore();
  }

  function drawBackground() {
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#aee3ff');
    g.addColorStop(0.6, '#dff3ff');
    g.addColorStop(1, '#fff3c4');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#8bc34a';
    ctx.beginPath();
    ctx.moveTo(0, H - 18);
    ctx.quadraticCurveTo(W / 2, H - 44, W, H - 18);
    ctx.lineTo(W, H);
    ctx.lineTo(0, H);
    ctx.closePath();
    ctx.fill();
  }

  function drawFloaters() {
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (var i = 0; i < floaters.length; i++) {
      var fl = floaters[i];
      ctx.globalAlpha = Math.max(0, fl.life);
      ctx.font = 'bold 20px system-ui, "PingFang SC", "Microsoft YaHei", sans-serif';
      ctx.fillStyle = '#f57f17';
      ctx.fillText(fl.text, fl.x, fl.y);
    }
    ctx.globalAlpha = 1;
  }

  function render(t) {
    ctx.clearRect(0, 0, W, H);
    drawBackground();
    drawCloud(t);
    drawBasket();
    for (var i = 0; i < items.length; i++) drawItem(items[i]);
    drawParticles();
    drawFloaters();
    if (started && !running && lives > 0) {
      ctx.fillStyle = 'rgba(74, 47, 11, 0.45)';
      ctx.fillRect(0, 0, W, H);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 24px system-ui, "PingFang SC", "Microsoft YaHei", sans-serif';
      ctx.fillText(T.t('paused'), W / 2, H / 2);
    }
  }

  // ---------- HUD ----------
  var scoreEl = document.getElementById('scoreEl');
  var livesEl = document.getElementById('livesEl');
  var levelEl = document.getElementById('levelEl');
  var bestEl = document.getElementById('bestEl');
  function updateHud() {
    scoreEl.textContent = String(score);
    livesEl.textContent = lives > 0 ? '❤️'.repeat(lives) + '🖤'.repeat(0) : '🖤🖤🖤';
    if (lives <= 0) livesEl.classList.add('lost'); else livesEl.classList.remove('lost');
    levelEl.textContent = String(level);
    bestEl.textContent = String(best);
  }

  function flashHud() {
    livesEl.style.transition = '';
    livesEl.style.color = '#fff';
    livesEl.style.background = 'var(--danger)';
    setTimeout(function () {
      livesEl.style.transition = 'color .4s, background .4s';
      livesEl.style.color = '';
      livesEl.style.background = '';
    }, 60);
  }

  // ---------- loop ----------
  function loop(ts) {
    if (!lastTs) lastTs = ts;
    var dt = Math.min(0.05, (ts - lastTs) / 1000);
    lastTs = ts;

    if (running) {
      processKeys(dt);
      update(dt);
    }
    render(ts / 1000);
    requestAnimationFrame(loop);
  }

  // ---------- game lifecycle ----------
  function newGame() {
    closeDialog();
    startOverlay.classList.remove('show');
    started = true;
    score = 0; lives = 3; level = 1;
    items.length = 0; particles.length = 0;
    elapsed = 0; spawnTimer = 0;
    stats = { caught: 0, dropped: 0, bombs: 0 };
    basket.x = W / 2;
    running = true;
    updateHud();
    var bp = document.getElementById('btnPause');
    if (bp) bp.textContent = T.t('pause');
  }

  function endGame() {
    running = false;
    var isRecord = score > best && score > 0;
    if (score > best) {
      best = score;
      try { localStorage.setItem('fruitcatcher_best', String(best)); } catch (e) {}
    }
    if (typeof sfx !== 'undefined') { sfx.over(); if (isRecord) { sfx.best(); } }
    updateHud();  // 刷新 HUD 最高分条（上游 endGame 不调 updateHud，chip 会停在旧值）
    showDialog();
  }

  function togglePause() {
    if (lives <= 0) return;
    running = !running;
    var bp = document.getElementById('btnPause');
    if (bp) bp.textContent = running ? T.t('pause') : T.t('resume');
  }

  // ---------- dialog ----------
  var overlay = document.getElementById('overlay');
  var startOverlay = document.getElementById('startOverlay');
  var dlgScore = document.getElementById('dlgScore');
  var dlgCaught = document.getElementById('dlgCaught');
  var dlgDropped = document.getElementById('dlgDropped');
  var dlgBest = document.getElementById('dlgBest');
  var dlgGrade = document.getElementById('dlgGrade');
  var dlgTitle = document.getElementById('dlgTitle');

  function showDialog() {
    dlgTitle.textContent = T.t('over');
    dlgScore.textContent = String(score);
    dlgCaught.textContent = String(stats.caught);
    dlgDropped.textContent = String(stats.dropped);
    dlgBest.textContent = String(best);
    dlgGrade.textContent =
      score >= 300 ? T.t('perfect') :
      score >= 150 ? T.t('great') :
      score >= 50  ? T.t('nice') : T.t('keepon');
    overlay.classList.add('show');
  }

  function closeDialog() {
    overlay.classList.remove('show');
  }

  overlay.addEventListener('click', function (ev) {
    if (ev.target === overlay) closeDialog();
  });
  document.getElementById('btnAgain').addEventListener('click', newGame);
  document.getElementById('btnClose').addEventListener('click', closeDialog);
  document.getElementById('btnNew').addEventListener('click', newGame);
  document.getElementById('btnStart').addEventListener('click', newGame);
  document.getElementById('btnPause').addEventListener('click', togglePause);

  T.onChange(function () {
    if (overlay.classList.contains('show')) {
      dlgTitle.textContent = T.t('over');
      dlgGrade.textContent =
        score >= 300 ? T.t('perfect') :
        score >= 150 ? T.t('great') :
        score >= 50  ? T.t('nice') : T.t('keepon');
    }
  });

  // ---------- init ----------
  buildFieldPlaceholder();
  function buildFieldPlaceholder() {
    // Used by the harness to detect a stage element; no real setup needed.
    document.getElementById('stage').dataset.ready = '1';
  }

  updateHud();
  T.start();
  // The canvas loop starts even before newGame(), so the empty stage renders nicely.
  requestAnimationFrame(loop);

  /* ======================================================================
   * Test bridge (window.FC)
   * ==================================================================== */
  window.FC = {
    getState: function () {
      return {
        phase: !started ? 'ready' : (lives <= 0 ? 'over' : (running ? 'playing' : 'paused')),
        score: score, lives: lives, level: level, best: best,
        basketX: Math.round(basket.x),
        items: items.map(function (it) {
          return { x: Math.round(it.x), y: Math.round(it.y), kind: it.kind.key, vy: Math.round(it.vy) };
        }),
        stats: { caught: stats.caught, dropped: stats.dropped, bombs: stats.bombs },
        running: running, started: started
      };
    },
    tick: function (dt) { if (running) update(dt); return window.FC.getState(); },
    spawnItem: function (kindKey, x, y) {
      var kind = kindKey === 'bomb' ? BOMB : null;
      if (!kind) {
        for (var i = 0; i < FRUITS.length; i++) if (FRUITS[i].key === kindKey) kind = FRUITS[i];
      }
      if (!kind) return null;
      var it = { x: x, y: (y == null ? -24 : y), vy: 120, r: 24, kind: kind, rot: 0, spin: 0 };
      items.push(it);
      return it;
    },
    setBasketX: function (x) {
      basket.x = Math.max(basket.width / 2, Math.min(W - basket.width / 2, x));
    },
    start: function () { newGame(); return window.FC.getState(); },
    togglePause: function () { togglePause(); return window.FC.getState(); },
    reloadBest: function () {
      best = +(localStorage.getItem('fruitcatcher_best') || 0);
      updateHud();
      return window.FC.getState();
    }
  };
