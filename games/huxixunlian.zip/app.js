
        const protocols = {
            box: { name: '箱式呼吸', phases: [4, 4, 4, 4] },
            extended: { name: '延长呼气', phases: [4, 0, 8, 0] },
            sama: { name: '等长呼吸', phases: [6, 6, 6, 6] },
            'deep-box': { name: '深箱式呼吸', phases: [10, 10, 10, 10] },
            'master-box': { name: '大师箱式', phases: [15, 15, 15, 15] },
            'visama': { name: '不等长呼吸', phases: [6, 24, 12, 6] },
            'deep-sama': { name: '深等长呼吸', phases: [12, 12, 12, 12] }
        };

        let selectedProtocol = null;
        let selectedDuration = null;
        let sessionActive = false;
        let currentPhase = 0;
        let cycleCount = 0;
        let probesAnswered = 0;
        let probesMissed = 0;
        let sessionStartTime = 0;
        let sessionEndTime = 0;
        let phaseTimer = null;
        let sessionTimer = null;
        let probeTimer = null;
        let probeTimeout = null;

        // Level toggle
        document.querySelectorAll('.level-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.level-btn').forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
                
                const level = btn.dataset.level;
                document.querySelectorAll('.protocol-group').forEach(g => g.classList.remove('active'));
                document.getElementById(level + 'Protocols').classList.add('active');
                
                // Deselect any selected protocol when switching levels
                document.querySelectorAll('.protocol-btn').forEach(b => b.classList.remove('selected'));
                selectedProtocol = null;
                updateContinueButton();
            });
        });

        // Setup screen
        document.querySelectorAll('.protocol-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.protocol-btn').forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
                selectedProtocol = btn.dataset.protocol;
                updateContinueButton();
            });
        });

        document.querySelectorAll('.duration-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.duration-btn').forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
                selectedDuration = parseInt(btn.dataset.duration);
                updateContinueButton();
            });
        });

        function updateContinueButton() {
            document.getElementById('continueBtn').disabled = !(selectedProtocol && selectedDuration);
        }

        document.getElementById('continueBtn').addEventListener('click', () => {
            showScreen('safetyScreen');
        });

        // Safety screen
        document.querySelectorAll('.safety-item input').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                const allChecked = Array.from(document.querySelectorAll('.safety-item input'))
                    .every(cb => cb.checked);
                document.getElementById('startBtn').disabled = !allChecked;
            });
        });

        document.getElementById('startBtn').addEventListener('click', () => {
            if (!hxTipShown) { document.getElementById('tipOverlay').classList.add('active'); return; }
            startSession();
        });

        // Practice session
        function startSession() {
            showScreen('practiceScreen');
            document.getElementById('emergencyBtn').classList.add('active');
            document.getElementById('endBtn').classList.add('active');
            sessionActive = true;
            currentPhase = 0;
            cycleCount = 0;
            probesAnswered = 0;
            probesMissed = 0;
            sessionStartTime = Date.now();
            sessionEndTime = sessionStartTime + (selectedDuration * 60 * 1000);
            
            // Preparation phase
            const circle = document.getElementById('breathCircle');
            const label = document.getElementById('phaseLabel');
            
            label.textContent = '就绪';
            circle.className = 'breath-circle';
            
            setTimeout(() => {
                label.textContent = '开始';
                circle.className = 'breath-circle inhale';
                
                setTimeout(() => {
                    scheduleNextProbe();
                    runBreathCycle();
                    updateSessionTimer();
                }, 1000);
            }, 1500);
        }

        function runBreathCycle() {
            if (!sessionActive) return;

            const protocol = protocols[selectedProtocol];
            const phaseNames = ['吸气', '屏息', '呼气', '屏息'];
            const phaseClasses = ['inhale', 'hold', 'exhale', 'hold'];
            const phaseDuration = protocol.phases[currentPhase];

            if (phaseDuration === 0) {
                currentPhase = (currentPhase + 1) % 4;
                runBreathCycle();
                return;
            }

            const circle = document.getElementById('breathCircle');
            const label = document.getElementById('phaseLabel');

            circle.className = 'breath-circle ' + phaseClasses[currentPhase];
            label.textContent = phaseNames[currentPhase];

            phaseTimer = setTimeout(() => {
                currentPhase = (currentPhase + 1) % 4;
                if (currentPhase === 0) cycleCount++;
                runBreathCycle();
            }, phaseDuration * 1000);
        }

        function scheduleNextProbe() {
            if (!sessionActive) return;
            const delay = (45 + Math.random() * 45) * 1000;
            probeTimeout = setTimeout(showProbe, delay);
        }

        function showProbe() {
            if (!sessionActive) return;

            sessionActive = false;
            clearTimeout(phaseTimer);
            document.getElementById('probeOverlay').classList.add('active');

            let timeLeft = 5;
            document.getElementById('probeTimer').textContent = timeLeft;

            probeTimer = setInterval(() => {
                timeLeft--;
                document.getElementById('probeTimer').textContent = timeLeft;
                if (timeLeft <= 0) {
                    clearInterval(probeTimer);
                    probesMissed++;
                    hideProbe();
                    showPause();
                }
            }, 1000);
        }

        document.querySelectorAll('.probe-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                clearInterval(probeTimer);
                probesAnswered++;
                hideProbe();
                sessionActive = true;
                runBreathCycle();
                scheduleNextProbe();
            });
        });

        function hideProbe() {
            document.getElementById('probeOverlay').classList.remove('active');
        }

        function showPause() {
            document.getElementById('pauseOverlay').classList.add('active');
        }

        document.getElementById('resumeBtn').addEventListener('click', () => {
            document.getElementById('pauseOverlay').classList.remove('active');
            sessionActive = true;
            runBreathCycle();
            scheduleNextProbe();
        });

        function updateSessionTimer() {
            function updateDisplay() {
                const now = Date.now();
                const remaining = Math.max(0, Math.floor((sessionEndTime - now) / 1000));

                if (remaining <= 0) {
                    endSession();
                    return;
                }

                const minutes = Math.floor(remaining / 60);
                const seconds = remaining % 60;
                document.getElementById('timerDisplay').textContent = 
                    `${minutes}:${seconds.toString().padStart(2, '0')}`;
            }

            updateDisplay();
            sessionTimer = setInterval(updateDisplay, 1000);
        }

        function endSession(fromGround = false) {
            sessionActive = false;
            clearTimeout(phaseTimer);
            clearTimeout(probeTimeout);
            clearInterval(sessionTimer);
            clearInterval(probeTimer);
            document.getElementById('emergencyBtn').classList.remove('active');
            document.getElementById('endBtn').classList.remove('active');
            document.getElementById('endBtn').textContent = '提前结束';

            const totalProbes = probesAnswered + probesMissed;
            const awarenessPercent = totalProbes > 0 ? Math.round((probesAnswered / totalProbes) * 100) : 100;

            document.getElementById('cyclesCompleted').textContent = cycleCount;
            document.getElementById('awarenessScore').textContent = awarenessPercent + '%';
            document.getElementById('driftCount').textContent = probesMissed;

            let summaryMsg = '';
            if (fromGround) {
                summaryMsg = '平复完成。需要时照顾好自己，这也是觉察。';
            } else if (awarenessPercent >= 90) {
                summaryMsg = '专注极佳。整个练习中你的觉察保持稳定。';
            } else if (awarenessPercent >= 70) {
                summaryMsg = '不错的一次练习。略有走神，但整体保持了良好的专注。';
            } else {
                summaryMsg = '练习完成。可以试试更短的时长，慢慢培养持续觉察。';
            }
            document.getElementById('summaryText').textContent = summaryMsg;

            showScreen('summaryScreen');
        }

        // Emergency ground - NEW CLEANER VERSION
        document.getElementById('emergencyBtn').addEventListener('click', () => {
            sessionActive = false;
            clearTimeout(phaseTimer);
            clearTimeout(probeTimeout);
            clearInterval(sessionTimer);
            clearInterval(probeTimer);
            hideProbe();
            document.getElementById('pauseOverlay').classList.remove('active');
            
            // Show grounding overlay
            document.getElementById('groundingOverlay').classList.add('active');
            
            const circle = document.getElementById('groundCircle');
            const label = document.getElementById('groundPhase');
            const progress = document.getElementById('groundProgress');
            
            let groundPhase = 0;
            let groundCycles = 0;
            const groundPattern = ['吸气', '屏息', '呼气', '屏息'];
            const groundClasses = ['inhale', 'hold', 'exhale', 'hold'];
            
            function groundBreath() {
                circle.className = 'breath-circle ' + groundClasses[groundPhase];
                label.textContent = groundPattern[groundPhase];
                progress.textContent = `第 ${groundCycles + 1} 组 / 共 3 组`;
                
                setTimeout(() => {
                    groundPhase = (groundPhase + 1) % 4;
                    if (groundPhase === 0) {
                        groundCycles++;
                        if (groundCycles >= 3) {
                            document.getElementById('groundingOverlay').classList.remove('active');
                            endSession(true);
                            return;
                        }
                    }
                    groundBreath();
                }, 4000);
            }
            
            groundBreath();
        });

        // End session early
        var endArmed = false;
        document.getElementById('endBtn').addEventListener('click', () => {
            if (!endArmed) {
                endArmed = true;
                document.getElementById('endBtn').textContent = '再点一次确认结束';
                setTimeout(() => {
                    endArmed = false;
                    document.getElementById('endBtn').textContent = '提前结束';
                }, 3000);
                return;
            }
            endArmed = false;
            endSession();
        });

        // New session
        document.getElementById('newSessionBtn').addEventListener('click', () => {
            selectedProtocol = null;
            selectedDuration = null;
            document.querySelectorAll('.protocol-btn').forEach(b => b.classList.remove('selected'));
            document.querySelectorAll('.duration-btn').forEach(b => b.classList.remove('selected'));
            document.querySelectorAll('.safety-item input').forEach(cb => cb.checked = false);
            document.getElementById('emergencyBtn').classList.remove('active');
            document.getElementById('endBtn').classList.remove('active');
            document.getElementById('endBtn').textContent = '提前结束';
            showScreen('setupScreen');
        });

        function showScreen(screenId) {
            document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
            document.getElementById(screenId).classList.add('active');
        }
    
        // ---- 测试桥（供自动化实测读取状态，不影响功能）----
        window.HX = {
            getState: function () {
                var active = document.querySelector('.screen.active');
                var circle = document.getElementById('breathCircle');
                var r = circle ? circle.getBoundingClientRect() : { width: 0 };
                var card = document.querySelector('#practiceScreen .card');
                return {
                    screen: active ? active.id : '',
                    protocol: typeof selectedProtocol !== 'undefined' ? selectedProtocol : null,
                    duration: typeof selectedDuration !== 'undefined' ? selectedDuration : null,
                    sessionActive: typeof sessionActive !== 'undefined' ? sessionActive : false,
                    phase: (document.getElementById('phaseLabel') || {}).textContent || '',
                    timer: (document.getElementById('timerDisplay') || {}).textContent || '',
                    cycles: typeof cycleCount !== 'undefined' ? cycleCount : 0,
                    circleW: Math.round(r.width),
                    cardW: card ? Math.round(card.getBoundingClientRect().width) : 0,
                    continueDisabled: document.getElementById('continueBtn').disabled,
                    startDisabled: document.getElementById('startBtn').disabled,
                    tipVisible: document.getElementById('tipOverlay').classList.contains('active')
                };
            }
        };

        // ---- 音乐提示弹窗（首次开始练习时提示可自备音乐）----
        var hxTipShown = false;
        document.getElementById('tipBtn').addEventListener('click', function () {
            hxTipShown = true;
            document.getElementById('tipOverlay').classList.remove('active');
            startSession();
        });
