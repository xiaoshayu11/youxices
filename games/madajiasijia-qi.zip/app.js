/* 马达加斯加棋（Fanorona）：5x9 线盘，逼近/撤退整排吃子，每方 22 子，无连吃（与上游一致）。
   算法（连线/走法生成/吃子/AI）沿用上游 Pixel-Arcade fanorona.js，仅汉化与换主题；
   唯一修正：上游 conn() 用 |dr|+|dc|!==1 使斜线分支成死代码（斜步之和为 2），
   按其注释本意改为 Math.max(...)!==1，使斜线可走且与棋盘绘线一致。 */
var FN_ROWS = 5, FN_COLS = 9;

function fnConn(r1, c1, r2, c2) {
  var dr = r2 - r1, dc = c2 - c1;
  if (Math.max(Math.abs(dr), Math.abs(dc)) !== 1) return false;
  if (dr === 0 || dc === 0) return true;
  return ((r1 + c1) % 2) === 0;
}

var FN_DIRS = [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [-1, 1], [1, -1], [1, 1]];

function fnInB(r, c) {
  return r >= 0 && r < FN_ROWS && c >= 0 && c < FN_COLS;
}

function fnStartBoard() {
  var b = [];
  var r, c;
  for (r = 0; r < FN_ROWS; r++) {
    b.push([]);
    for (c = 0; c < FN_COLS; c++) b[r].push("");
  }
  for (c = 0; c < FN_COLS; c++) {
    b[0][c] = "B";
    b[1][c] = "B";
    b[3][c] = "W";
    b[4][c] = "W";
  }
  for (c = 0; c <= 3; c++) b[2][c] = "B";
  for (c = 5; c <= 8; c++) b[2][c] = "W";
  return b;
}

function fnRayCaptures(b, sr, sc, dr, dc, foe) {
  var out = [];
  var pr = sr, pc = sc, r = sr + dr, c = sc + dc;
  while (fnInB(r, c) && fnConn(pr, pc, r, c) && b[r][c] === foe) {
    out.push([r, c]);
    pr = r;
    pc = c;
    r += dr;
    c += dc;
  }
  return out;
}

function fnAllMoves(b, side) {
  var foe = side === "W" ? "B" : "W";
  var out = [];
  var r, c, di;
  for (r = 0; r < FN_ROWS; r++) for (c = 0; c < FN_COLS; c++) {
    if (b[r][c] !== side) continue;
    for (di = 0; di < FN_DIRS.length; di++) {
      var d = FN_DIRS[di];
      var tr = r + d[0], tc = c + d[1];
      if (!fnInB(tr, tc) || !fnConn(r, c, tr, tc) || b[tr][tc] !== "") continue;
      var app = fnRayCaptures(b, tr, tc, d[0], d[1], foe);
      var wd = fnRayCaptures(b, r, c, -d[0], -d[1], foe);
      out.push({ fr: r, fc: c, tr: tr, tc: tc, app: app.length ? app : null, wd: wd.length ? wd : null });
    }
  }
  return out;
}

function fnApplyMove(b, m, useApp) {
  b[m.tr][m.tc] = b[m.fr][m.fc];
  b[m.fr][m.fc] = "";
  var caps = useApp ? m.app : m.wd;
  if (caps) for (var i = 0; i < caps.length; i++) b[caps[i][0]][caps[i][1]] = "";
  return caps ? caps.length : 0;
}

function fnCountPieces(b, side) {
  var n = 0;
  for (var r = 0; r < FN_ROWS; r++) for (var c = 0; c < FN_COLS; c++) if (b[r][c] === side) n++;
  return n;
}

// AI：1 层贪心，吃最多优先（上游 aiPick）
function fnAiPick(b) {
  var moves = fnAllMoves(b, "B");
  if (!moves.length) return null;
  var best = null, bestS = -Infinity;
  for (var i = 0; i < moves.length; i++) {
    var m = moves[i];
    var cap = Math.max(m.app ? m.app.length : 0, m.wd ? m.wd.length : 0);
    var s = cap * 100;
    s += (4 - Math.abs(m.tr - 2)) * 1.5;
    s += (8 - Math.abs(m.tc - 4)) * 0.5;
    s += Math.random() * 3;
    if (s > bestS) {
      bestS = s;
      best = m;
    }
  }
  return best;
}

// ---- WebAudio 合成音效（无音频文件） ----
var fnSfxClicks = 0;
var fnSfxWins = 0;
var fnAudioCtx = null;
function fnAudio() {
  if (typeof AudioContext === "undefined" && typeof webkitAudioContext === "undefined") return null;
  if (!fnAudioCtx) {
    var AC = (typeof AudioContext !== "undefined") ? AudioContext : webkitAudioContext;
    try { fnAudioCtx = new AC(); } catch (e) { return null; }
  }
  if (fnAudioCtx.state === "suspended") { fnAudioCtx.resume(); }
  return fnAudioCtx;
}
function fnTone(freq, dur, delay, type, gain, slideTo) {
  var ctx = fnAudio();
  if (!ctx) return;
  var t = ctx.currentTime + (delay || 0);
  var osc = ctx.createOscillator();
  var g = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freq, t);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
  g.gain.setValueAtTime(gain || 0.12, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}
var sfx = {
  click: function () { fnSfxClicks++; fnTone(1800, 0.05, 0, "square", 0.05); },
  move: function () { fnSfxClicks++; fnTone(320, 0.09, 0, "sine", 0.12, 180); },
  capture: function () { fnSfxClicks++; fnTone(700, 0.16, 0, "triangle", 0.14, 160); },
  error: function () { fnTone(160, 0.18, 0, "sawtooth", 0.08); },
  win: function () { fnSfxWins++; fnTone(523, 0.14, 0, "sine", 0.12); fnTone(659, 0.14, 0.12, "sine", 0.12); fnTone(784, 0.26, 0.24, "sine", 0.12); },
  lose: function () { fnSfxWins++; fnTone(392, 0.2, 0, "sine", 0.12); fnTone(262, 0.32, 0.18, "sine", 0.12); }
};

// ---- 界面 ----
function fnEl(id) { return document.getElementById(id); }
var FN_M = 26, FN_S = 47;
var FN_W = 2 * FN_M + (FN_COLS - 1) * FN_S, FN_H = 2 * FN_M + (FN_ROWS - 1) * FN_S;
function fnPX(r, c) { return [FN_M + c * FN_S, FN_M + r * FN_S]; }

var fnBoard = null;
var fnTurn = "W";
var fnOver = false;
var fnWinner = null;
var fnSel = null;
var fnPending = null;
var fnMovesMade = 0;

function fnSvgLines() {
  var s = "";
  var r, c, i, j;
  for (r = 0; r < FN_ROWS; r++) for (c = 0; c < FN_COLS; c++) {
    var p = fnPX(r, c);
    if (c + 1 < FN_COLS) {
      var q = fnPX(r, c + 1);
      s += '<line x1="' + p[0] + '" y1="' + p[1] + '" x2="' + q[0] + '" y2="' + q[1] + '"/>';
    }
    if (r + 1 < FN_ROWS) {
      var q2 = fnPX(r + 1, c);
      s += '<line x1="' + p[0] + '" y1="' + p[1] + '" x2="' + q2[0] + '" y2="' + q2[1] + '"/>';
    }
  }
  for (i = 0; i < FN_ROWS - 1; i++) for (j = 0; j < FN_COLS - 1; j++) {
    var tl = fnPX(i, j);
    if ((i + j) % 2 === 0) {
      var br = fnPX(i + 1, j + 1);
      s += '<line x1="' + tl[0] + '" y1="' + tl[1] + '" x2="' + br[0] + '" y2="' + br[1] + '"/>';
    } else {
      var tr = fnPX(i, j + 1), bl = fnPX(i + 1, j);
      s += '<line x1="' + tr[0] + '" y1="' + tr[1] + '" x2="' + bl[0] + '" y2="' + bl[1] + '"/>';
    }
  }
  return s;
}

function fnSetStatus(text, cls) {
  var el = fnEl("fn-status");
  el.textContent = text;
  el.className = "status" + (cls ? " " + cls : "");
}

function fnRender() {
  var svg = fnEl("fn-svg");
  var NS = "http://www.w3.org/2000/svg";
  svg.innerHTML = fnSvgLines();
  var r, c;
  // 落点圆点
  for (r = 0; r < FN_ROWS; r++) for (c = 0; c < FN_COLS; c++) {
    var p = fnPX(r, c);
    var d = document.createElementNS(NS, "circle");
    d.setAttribute("cx", p[0]);
    d.setAttribute("cy", p[1]);
    d.setAttribute("r", 3.5);
    d.setAttribute("class", "fn-pt");
    svg.appendChild(d);
  }
  // 选中金圈 + 可走标记（绿点；可吃子为红色虚线圈，与上游一致）
  if (!fnOver && fnTurn === "W" && fnSel) {
    var sp = fnPX(fnSel[0], fnSel[1]);
    var ring = document.createElementNS(NS, "circle");
    ring.setAttribute("cx", sp[0]);
    ring.setAttribute("cy", sp[1]);
    ring.setAttribute("r", 17);
    ring.setAttribute("class", "fn-sel");
    svg.appendChild(ring);
    var moves = fnAllMoves(fnBoard, "W");
    for (var i = 0; i < moves.length; i++) {
      var m = moves[i];
      if (m.fr !== fnSel[0] || m.fc !== fnSel[1]) continue;
      var dp = fnPX(m.tr, m.tc);
      var h = document.createElementNS(NS, "circle");
      h.setAttribute("cx", dp[0]);
      h.setAttribute("cy", dp[1]);
      if (m.app || m.wd) {
        h.setAttribute("r", 13);
        h.setAttribute("class", "fn-dest cap");
      } else {
        h.setAttribute("r", 6);
        h.setAttribute("class", "fn-dest");
      }
      svg.appendChild(h);
    }
  }
  // 棋子
  for (r = 0; r < FN_ROWS; r++) for (c = 0; c < FN_COLS; c++) {
    var v = fnBoard[r][c];
    if (!v) continue;
    var pp = fnPX(r, c);
    var pc = document.createElementNS(NS, "circle");
    pc.setAttribute("cx", pp[0]);
    pc.setAttribute("cy", pp[1]);
    pc.setAttribute("r", 14);
    pc.setAttribute("class", "fn-piece " + v);
    svg.appendChild(pc);
  }
  // 透明热区（最后画，始终在最上层）
  for (r = 0; r < FN_ROWS; r++) for (c = 0; c < FN_COLS; c++) {
    (function (r, c) {
      var hp = fnPX(r, c);
      var hit = document.createElementNS(NS, "circle");
      hit.setAttribute("cx", hp[0]);
      hit.setAttribute("cy", hp[1]);
      hit.setAttribute("r", 23);
      hit.setAttribute("class", "fn-hit");
      hit.setAttribute("data-r", r);
      hit.setAttribute("data-c", c);
      hit.addEventListener("click", function () { fnOnPoint(r, c); });
      svg.appendChild(hit);
    })(r, c);
  }
  fnEl("fn-pw").textContent = fnCountPieces(fnBoard, "W");
  fnEl("fn-pb").textContent = fnCountPieces(fnBoard, "B");
  fnEl("fn-cap").textContent = 22 - fnCountPieces(fnBoard, "B");
}

function fnOnPoint(r, c) {
  if (fnOver || fnTurn !== "W") return;
  if (fnBoard[r][c] === "W") {
    fnSel = (fnSel && fnSel[0] === r && fnSel[1] === c) ? null : [r, c];
    if (typeof sfx !== "undefined") sfx.click();
    fnRender();
    return;
  }
  if (!fnSel || fnBoard[r][c] !== "") {
    fnSel = null;
    fnRender();
    return;
  }
  var moves = fnAllMoves(fnBoard, "W");
  var m = null;
  for (var i = 0; i < moves.length; i++) {
    if (moves[i].fr === fnSel[0] && moves[i].fc === fnSel[1] && moves[i].tr === r && moves[i].tc === c) {
      m = moves[i];
      break;
    }
  }
  if (!m) {
    if (typeof sfx !== "undefined") sfx.error();
    return;
  }
  fnSel = null;
  if (m.app && m.wd) {
    fnAskChoice(m);
    return;
  }
  fnExecMove(m, !!m.app);
}

function fnAskChoice(m) {
  fnPending = m;
  var choiceEl = fnEl("fn-choice");
  choiceEl.style.display = "flex";
  choiceEl.innerHTML = "";
  var lbl = document.createElement("span");
  lbl.setAttribute("class", "choice-label");
  lbl.textContent = "两种吃法都可以，选一种：";
  choiceEl.appendChild(lbl);
  var ba = document.createElement("button");
  ba.setAttribute("class", "btn small");
  ba.textContent = "逼近吃 " + m.app.length + " 子";
  ba.addEventListener("click", function () {
    if (typeof sfx !== "undefined") sfx.click();
    fnEl("fn-choice").style.display = "none";
    fnExecMove(fnPending, true);
  });
  var bw = document.createElement("button");
  bw.setAttribute("class", "btn small");
  bw.textContent = "撤退吃 " + m.wd.length + " 子";
  bw.addEventListener("click", function () {
    if (typeof sfx !== "undefined") sfx.click();
    fnEl("fn-choice").style.display = "none";
    fnExecMove(fnPending, false);
  });
  choiceEl.appendChild(ba);
  choiceEl.appendChild(bw);
  fnRender();
}

function fnExecMove(m, useApp) {
  var caps = fnApplyMove(fnBoard, m, useApp);
  fnMovesMade++;
  if (typeof sfx !== "undefined") { if (caps) sfx.capture(); else sfx.move(); }
  if (fnCountPieces(fnBoard, "B") === 0) {
    fnFinish(true, "黑子全部吃光了！");
    return;
  }
  if (fnCountPieces(fnBoard, "W") === 0) {
    fnFinish(false, "白子全部吃光了！");
    return;
  }
  if (!fnAllMoves(fnBoard, "B").length) {
    fnFinish(true, "黑子无路可走了！");
    return;
  }
  fnTurn = "B";
  fnSetStatus("AI 思考中…", "info");
  fnRender();
  setTimeout(fnAiTurn, 400);
}

function fnAiTurn() {
  if (fnOver || fnTurn !== "B") return;
  var m = fnAiPick(fnBoard);
  if (!m) {
    fnFinish(true, "黑子无路可走了！");
    return;
  }
  var useApp = m.app ? (m.wd ? m.app.length >= m.wd.length : true) : false;
  var caps = fnApplyMove(fnBoard, m, useApp);
  fnMovesMade++;
  if (typeof sfx !== "undefined") { if (caps) sfx.capture(); else sfx.move(); }
  if (fnCountPieces(fnBoard, "W") === 0) {
    fnFinish(false, "白子全部吃光了！");
    return;
  }
  if (fnCountPieces(fnBoard, "B") === 0) {
    fnFinish(true, "黑子全部吃光了！");
    return;
  }
  if (!fnAllMoves(fnBoard, "W").length) {
    fnFinish(false, "白子无路可走了！");
    return;
  }
  fnTurn = "W";
  fnSetStatus("轮到你（白子）", "info");
  fnRender();
}

function fnFinish(won, why) {
  fnOver = true;
  fnWinner = won ? "W" : "B";
  fnSetStatus(won ? "你赢了：" + why : "你输了：" + why, won ? "win" : "lose");
  if (typeof sfx !== "undefined") { if (won) sfx.win(); else sfx.lose(); }
  fnRender();
}

function fnNewGame() {
  fnBoard = fnStartBoard();
  fnTurn = "W";
  fnOver = false;
  fnWinner = null;
  fnSel = null;
  fnPending = null;
  fnMovesMade = 0;
  fnEl("fn-choice").style.display = "none";
  fnSetStatus("轮到你（白子，在下方）", "info");
  fnRender();
}

fnEl("fn-new").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  fnNewGame();
});
fnEl("fn-help").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  fnEl("fn-mask").style.display = "block";
});
fnEl("fn-help-close").addEventListener("click", function () {
  fnEl("fn-mask").style.display = "none";
});
fnEl("fn-mask").addEventListener("click", function (e) {
  if (e.target === fnEl("fn-mask")) fnEl("fn-mask").style.display = "none";
});

var FN = {
  getState: function () {
    return {
      turn: fnTurn,
      whiteCount: fnCountPieces(fnBoard, "W"),
      blackCount: fnCountPieces(fnBoard, "B"),
      movesMade: fnMovesMade,
      over: fnOver,
      winner: fnWinner,
      helpVisible: fnEl("fn-mask").style.display === "block",
      sfxClicks: fnSfxClicks,
      sfxWins: fnSfxWins
    };
  }
};

fnNewGame();
