/* 时光：事件绑定（原内联 onclick/oninput/onchange 全部改 addEventListener）
 * + 转换器时间步进器 + 测试桥 window.SG。跨脚本全局一律 typeof 守卫。 */
(function () {
  'use strict';
  // ---- 转换器时间步进器（替代 input[type=time]，值存全局 convTimeVal）----
  function pad2(n) { return ('0' + n).slice(-2); }
  function convSyncTime() {
    var p = (typeof convTimeVal !== 'undefined' ? convTimeVal : '12:00').split(':');
    var h = document.getElementById('convHourVal');
    var m = document.getElementById('convMinVal');
    if (h) h.textContent = pad2(parseInt(p[0], 10) || 0);
    if (m) m.textContent = pad2(parseInt(p[1], 10) || 0);
  }
  function convStep(which, d) {
    var p = (typeof convTimeVal !== 'undefined' ? convTimeVal : '12:00').split(':');
    var hh = parseInt(p[0], 10) || 0, mm = parseInt(p[1], 10) || 0;
    if (which === 'h') hh = (hh + d + 24) % 24; else mm = (mm + d + 60) % 60;
    convTimeVal = pad2(hh) + ':' + pad2(mm);
    convSyncTime();
    if (typeof convOpen !== 'undefined' && convOpen && typeof renderConvResults !== 'undefined') renderConvResults();
  }
  document.getElementById('convHourUp').addEventListener('click', function () { convStep('h', 1); });
  document.getElementById('convHourDown').addEventListener('click', function () { convStep('h', -1); });
  document.getElementById('convMinUp').addEventListener('click', function () { convStep('m', 1); });
  document.getElementById('convMinDown').addEventListener('click', function () { convStep('m', -1); });
  convSyncTime();

  // ---- 城市卡片分页按钮 ----
  var _sgPb = document.getElementById('sgPrevBtn'), _sgNb = document.getElementById('sgNextBtn');
  if (_sgPb) _sgPb.addEventListener('click', function () { if (typeof sgPageGo !== 'undefined') sgPageGo(-1); });
  if (_sgNb) _sgNb.addEventListener('click', function () { if (typeof sgPageGo !== 'undefined') sgPageGo(1); });

  // ---- 由原内联处理器生成的绑定 ----
  document.getElementById('langBtn').addEventListener('click', function(event){ toggleLang() });
  document.getElementById('timeFmtQuickBtn').addEventListener('click', function(event){ cycleTimeFmt() });
  document.getElementById('fsBtn').addEventListener('click', function(event){ openFullscreen() });
  document.getElementById('convBtn').addEventListener('click', function(event){ toggleConverter() });
  document.getElementById('mainDarkBtn').addEventListener('click', function(event){ toggleMainDark() });
  document.getElementById('sgb1').addEventListener('click', function(event){ openSettings() });
  document.getElementById('sgb2').addEventListener('click', function(event){ openAbout() });
  document.getElementById('mfbRefreshBtn').addEventListener('click', function(event){ manualSyncRefresh() });
  document.getElementById('sgb3').addEventListener('click', function(event){ toggleConverter() });
  document.getElementById('convBtnEl').addEventListener('click', function(event){ runConvert() });
  document.getElementById('sgb4').addEventListener('click', function(event){ closeFullscreen() });
  document.getElementById('fsTbClock').addEventListener('click', function(event){ setFsMode('clock') });
  document.getElementById('fsTbBlock').addEventListener('click', function(event){ setFsMode('blocks') });
  document.getElementById('fsTb12').addEventListener('click', function(event){ setFsTimeFmt('12h') });
  document.getElementById('fsTb24').addEventListener('click', function(event){ setFsTimeFmt('24h') });
  document.getElementById('fsTbDark').addEventListener('click', function(event){ toggleFsDark() });
  document.getElementById('fsTbClockDark').addEventListener('click', function(event){ toggleClockFace() });
  document.getElementById('fsTbDate').addEventListener('click', function(event){ toggleFsDate() });
  document.getElementById('fsScaleSlider').addEventListener('input', function(event){ setFsScale(this.value) });
  document.getElementById('settingsOverlay').addEventListener('click', function(event){ ovClick(event,'settingsOverlay') });
  document.getElementById('sgb5').addEventListener('click', function(event){ closeSettings() });
  document.getElementById('primSel').addEventListener('change', function(event){ setPrimary(this.value) });
  document.getElementById('sgb6').addEventListener('click', function(event){ setS('timeFmt','12h') });
  document.getElementById('sgb7').addEventListener('click', function(event){ setS('timeFmt','24h') });
  document.getElementById('sgb8').addEventListener('click', function(event){ setS('dateFmt','short') });
  document.getElementById('sgb9').addEventListener('click', function(event){ setS('dateFmt','us') });
  document.getElementById('sgb10').addEventListener('click', function(event){ setS('dateFmt','zh') });
  document.getElementById('sgb11').addEventListener('click', function(event){ setS('dateFmt','iso') });
  document.getElementById('sgb12').addEventListener('click', function(event){ setS('dateFmt','dmy') });
  document.getElementById('sgb13').addEventListener('click', function(event){ setS('dateFmt','mdy') });
  document.getElementById('sgb14').addEventListener('click', function(event){ setS('cardFmt','12h') });
  document.getElementById('sgb15').addEventListener('click', function(event){ setS('cardFmt','24h') });
  document.getElementById('sgb16').addEventListener('click', function(event){ setS('cardFmt','both') });
  document.getElementById('sgb17').addEventListener('click', function(event){ setS('rowStyle','vivid') });
  document.getElementById('sgb18').addEventListener('click', function(event){ setS('rowStyle','pin') });
  document.getElementById('sgb19').addEventListener('click', function(event){ setS('rowStyle','classic') });
  document.getElementById('fontScaleSlider').addEventListener('input', function(event){ setFontScale(this.value) });
  document.getElementById('fontSelect').addEventListener('change', function(event){ setFont(this.value) });
  document.getElementById('sgb20').addEventListener('click', function(event){ toggleDstPreview() });
  document.getElementById('aboutOverlay').addEventListener('click', function(event){ ovClick(event,'aboutOverlay') });
  document.getElementById('sgb21').addEventListener('click', function(event){ closeAbout() });
  document.getElementById('sgb22').addEventListener('click', function(event){ mpPrev() });
  document.getElementById('mpPlayBtn').addEventListener('click', function(event){ mpToggle() });
  document.getElementById('sgb23').addEventListener('click', function(event){ mpNext() });
  document.getElementById('mpLoopBtn').addEventListener('click', function(event){ mpToggleLoop() });
  document.getElementById('mpVol').addEventListener('input', function(event){ mpSetVol(this.value) });
  document.getElementById('mpBgCheck').addEventListener('change', function(event){ mpToggleBg(this.checked) });
  document.getElementById('musicToggleBtn').addEventListener('click', function(event){ mpTogglePanel() });

  // ---- 测试桥 ----
  window.SG = {
    getState: function () {
      var tr = (typeof MP_TRACKS !== 'undefined' && typeof mpIdx !== 'undefined') ? MP_TRACKS[mpIdx] : null;
      return {
        playing: typeof mpPlaying !== 'undefined' ? !!mpPlaying : false,
        trackIdx: typeof mpIdx !== 'undefined' ? mpIdx : -1,
        trackId: tr ? tr.id : null,
        trackName: tr ? tr.name : null,
        panelOpen: typeof mpPanelOpen !== 'undefined' ? !!mpPanelOpen : false,
        ctxState: (typeof mpCtx !== 'undefined' && mpCtx) ? mpCtx.state : null,
        nodeCount: typeof mpSynthNodes !== 'undefined' ? mpSynthNodes.length : 0,
        cities: typeof S !== 'undefined' ? S.clockTzs.length : 0,
        page: typeof sgPage !== 'undefined' ? sgPage : 0,
        pageInfo: (document.getElementById('sgPageInfo') || {}).textContent || '',
        visibleCards: document.querySelectorAll('#clocksGrid .clock-item').length,
        primaryTime: (document.getElementById('primaryTime') || {}).textContent || '',
        convTime: typeof convTimeVal !== 'undefined' ? convTimeVal : null
      };
    },
    togglePanel: function () { if (typeof mpTogglePanel !== 'undefined') mpTogglePanel(); },
    play: function () { if (typeof mpToggle !== 'undefined' && typeof mpPlaying !== 'undefined' && !mpPlaying) mpToggle(); },
    pause: function () { if (typeof mpToggle !== 'undefined' && typeof mpPlaying !== 'undefined' && mpPlaying) mpToggle(); },
    next: function () { if (typeof mpNext !== 'undefined') mpNext(); },
    prev: function () { if (typeof mpPrev !== 'undefined') mpPrev(); },
    selectTrack: function (i) {
      if (typeof MP_TRACKS !== 'undefined' && i >= 0 && i < MP_TRACKS.length) {
        mpIdx = i;
        if (typeof mpPlaying !== 'undefined' && mpPlaying && typeof mpStartCurrent !== 'undefined') mpStartCurrent();
        else if (typeof mpUpdateUI !== 'undefined') mpUpdateUI();
      }
    },
    saveSettings: function () { if (typeof save !== 'undefined') save(); }
  };
})();
