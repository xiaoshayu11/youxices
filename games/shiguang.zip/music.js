
// ══════════════════════════════════════════
//   MUSIC PLAYER  —  真实音频 + Web Audio API白噪音
//   全局唯一 AudioElement / AudioContext，彻底解决停不住的问题
// ══════════════════════════════════════════

// ── 音轨定义 ──
var MP_TRACKS = [
  {id:'rain',      emoji:'🌧️', name:'雨声',        sub:'White Noise · Rain',        type:'noise', bg:{type:'rain'}},
  {id:'heavy-rain',emoji:'⛈️', name:'暴雨声',       sub:'White Noise · Heavy Rain',  type:'noise', bg:{type:'heavyrain'}},
  {id:'ocean',     emoji:'🌊', name:'海浪声',       sub:'White Noise · Ocean',       type:'noise', bg:{type:'ocean'}},
  {id:'forest',    emoji:'🌲', name:'森林风声',     sub:'White Noise · Forest Wind', type:'noise', bg:{type:'forest'}},
  {id:'fireplace', emoji:'🔥', name:'壁炉噼啪',     sub:'White Noise · Fireplace',   type:'noise', bg:{type:'fire'}},
  {id:'cosmos',    emoji:'🌌', name:'宇宙氛围',     sub:'Ambient · Space',           type:'noise', bg:{type:'cosmos'}},
  {id:'crickets',  emoji:'🦗', name:'夜晚虫鸣',     sub:'Night · Crickets',          type:'noise', bg:{type:'night'}},
  {id:'dawn',      emoji:'🌅', name:'清晨鸟鸣',     sub:'Dawn · Birdsong',           type:'noise', bg:{type:'dawn'}},
  // 轻音乐用 Web Audio 合成，避免外链问题
  {id:'piano1',    emoji:'🎹', name:'钢琴轻音乐',   sub:'Piano · Gentle Melody',     type:'noise', bg:{type:'piano'}},
  {id:'lofi',      emoji:'☕', name:'LoFi 轻音乐',  sub:'LoFi · Chill Beats',        type:'noise', bg:{type:'lofi'}},
  {id:'strings',   emoji:'🎻', name:'弦乐氛围',     sub:'Strings · Soft Ambient',    type:'noise', bg:{type:'strings'}},
];

// ── 状态 ──
var mpIdx = 8;
var mpPlaying = false;
var mpPanelOpen = false;
var mpLoop = true;
var mpBgEnabled = true;
var mpVol = 0.35;

// ── Web Audio Context ──
var mpCtx = null;
var mpSynthNodes = [];
var mpSynthGain = null;

function mpEnsureCtx(){
  if(!mpCtx){
    mpCtx = new (window.AudioContext||window.webkitAudioContext)();
    mpSynthGain = mpCtx.createGain();
    mpSynthGain.gain.value = mpVol;
    mpSynthGain.connect(mpCtx.destination);
  }
  if(mpCtx.state==='suspended') mpCtx.resume();
}

// ── 停止所有声音（唯一入口）──
function mpStopAll(){
  // 先清 loopTimer，防止再次触发循环
  mpSynthNodes.forEach(function(n){
    try{ n.stop(); }catch(e){}
    try{ n.disconnect(); }catch(e){}
  });
  mpSynthNodes = [];
  // 关键：断开并重建 mpSynthGain
  // 这样所有仍在计划中的旧 oscillator 节点即使未来触发也无法发出声音
  if(mpSynthGain){
    try{
      mpSynthGain.gain.setValueAtTime(0, mpCtx.currentTime);
      mpSynthGain.disconnect();
    }catch(e){}
    mpSynthGain = mpCtx.createGain();
    mpSynthGain.gain.value = mpVol;
    mpSynthGain.connect(mpCtx.destination);
  }
  mpPlaying = false;
}

// ── 启动当前音轨 ──
function mpStartCurrent(){
  mpStopAll();
  mpStartNoise(MP_TRACKS[mpIdx].id);
  mpPlaying = true;
  mpUpdateUI();
  if(mpBgEnabled) mpStartBg(MP_TRACKS[mpIdx].bg);
}

// ── 白噪音基础工具 ──
function mpMakeNoise(dur, vol, ftype, freq, q){
  var buf = mpCtx.createBuffer(2, mpCtx.sampleRate*dur, mpCtx.sampleRate);
  for(var c=0;c<2;c++){var d=buf.getChannelData(c);for(var i=0;i<d.length;i++)d[i]=(Math.random()*2-1);}
  var src=mpCtx.createBufferSource(), f=mpCtx.createBiquadFilter(), g=mpCtx.createGain();
  f.type=ftype||'bandpass'; f.frequency.value=freq||1000; f.Q.value=q||0.5;
  g.gain.value=vol||0.5;
  src.buffer=buf; src.loop=true;
  src.connect(f); f.connect(g); g.connect(mpSynthGain);
  src.start();
  return {src:src, filt:f, gain:g};
}
function mpMakeTone(freq, vol, type){
  var o=mpCtx.createOscillator(), g=mpCtx.createGain();
  o.type=type||'sine'; o.frequency.value=freq;
  g.gain.value=vol||0.05;
  o.connect(g); g.connect(mpSynthGain); o.start();
  return {osc:o, gain:g};
}
function mpMakeLFO(target, rate, depth){
  var lfo=mpCtx.createOscillator(), lg=mpCtx.createGain();
  lfo.frequency.value=rate||0.1; lg.gain.value=depth||100;
  lfo.connect(lg); lg.connect(target); lfo.start();
  return {lfo:lfo, gain:lg};
}
function mpPushNodes(){
  var nodes=[];
  for(var i=0;i<arguments.length;i++){
    var obj=arguments[i];
    if(!obj)continue;
    if(obj.src)nodes.push(obj.src);
    if(obj.filt)nodes.push(obj.filt);
    if(obj.gain)nodes.push(obj.gain);
    if(obj.osc)nodes.push(obj.osc);
    if(obj.lfo)nodes.push(obj.lfo);
  }
  mpSynthNodes=mpSynthNodes.concat(nodes);
}

// ── 各音轨合成 ──
function mpStartNoise(id){
  mpEnsureCtx();
  if(id==='rain'){
    var r=mpMakeNoise(3,0.6,'bandpass',1300,0.4);
    var r2=mpMakeNoise(4,0.25,'bandpass',2800,0.35);
    var lf=mpMakeTone(55,0.03,'sine');
    mpPushNodes(r,r2,lf);
  }
  else if(id==='heavy-rain'){
    var r=mpMakeNoise(3,0.7,'bandpass',900,0.3);
    var r2=mpMakeNoise(3,0.35,'bandpass',2500,0.25);
    var r3=mpMakeNoise(5,0.15,'lowpass',200,0);
    var lf=mpMakeTone(48,0.055,'sine');
    var lf2=mpMakeTone(72,0.03,'sine');
    mpPushNodes(r,r2,r3,lf,lf2);
  }
  else if(id==='ocean'){
    var n=mpMakeNoise(6,0.55,'lowpass',500,0);
    var lfo=mpMakeLFO(n.filt.frequency, 0.1, 380);
    var lf=mpMakeTone(60,0.025,'sine');
    mpPushNodes(n,lfo,lf);
  }
  else if(id==='forest'){
    var w=mpMakeNoise(4,0.22,'bandpass',380,0.25);
    var hf=mpMakeNoise(3,0.06,'bandpass',3500,0.4);
    mpPushNodes(w,hf);
    mpSynthBirdsLoop('forest');
  }
  else if(id==='fireplace'){
    var lf=mpMakeNoise(5,0.45,'lowpass',200,0);
    var mid=mpMakeNoise(4,0.12,'bandpass',800,0.7);
    mpPushNodes(lf,mid);
    mpSynthCrackleLoop('fireplace');
  }
  else if(id==='cosmos'){
    [[110,0.05],[165,0.035],[220,0.025],[330,0.018],[440,0.013]].forEach(function(p,i){
      var t1=mpMakeTone(p[0],p[1],'sine');
      var lfo=mpMakeLFO(t1.osc.frequency,0.03+i*0.013,p[0]*0.01);
      mpPushNodes(t1,lfo);
    });
    var sh=mpMakeNoise(3,0.03,'highpass',6000,0);
    mpPushNodes(sh);
  }
  else if(id==='crickets'){
    // 蟋蟀：高频周期性调幅噪音
    var base=mpMakeNoise(3,0.18,'bandpass',4200,3.5);
    var lfo1=mpMakeLFO(base.gain.gain,14,0.16); // 14Hz 调幅 = 蟋蟀节奏
    var base2=mpMakeNoise(3,0.12,'bandpass',3800,3);
    var lfo2=mpMakeLFO(base2.gain.gain,14.3,0.10);
    // 低频底噪（夜晚寂静感）
    var bg=mpMakeNoise(5,0.06,'lowpass',120,0);
    var lf=mpMakeTone(80,0.015,'sine');
    mpPushNodes(base,lfo1,base2,lfo2,bg,lf);
    // 偶尔的远处青蛙声
    mpSynthFrogLoop();
  }
  else if(id==='dawn'){
    // 清晨：轻柔底噪 + 清脆多层鸟鸣 + 远处微风
    var w=mpMakeNoise(4,0.08,'lowpass',300,0);
    var hf=mpMakeNoise(3,0.04,'bandpass',2000,0.5);
    mpPushNodes(w,hf);
    mpSynthDawnBirdsLoop();
  }
  else if(id==='piano1'){
    mpSynthPianoLoop();
  }
  else if(id==='lofi'){
    mpSynthLoFiLoop();
  }
  else if(id==='strings'){
    mpSynthStringsLoop();
  }
}

// ── 虫鸣辅助：青蛙 ──
function mpSynthFrogLoop(){
  function frog(){
    if(!mpPlaying||MP_TRACKS[mpIdx].id!=='crickets')return;
    var t=mpCtx.currentTime;
    [0,0.18,0.36].forEach(function(dt){
      var o=mpCtx.createOscillator(),g=mpCtx.createGain();
      o.type='sine'; o.frequency.setValueAtTime(180,t+dt); o.frequency.linearRampToValueAtTime(130,t+dt+0.12);
      g.gain.setValueAtTime(0,t+dt); g.gain.linearRampToValueAtTime(0.06,t+dt+0.02);
      g.gain.exponentialRampToValueAtTime(0.001,t+dt+0.14);
      o.connect(g);g.connect(mpSynthGain);o.start(t+dt);o.stop(t+dt+0.18);
    });
    setTimeout(frog,4000+Math.random()*8000);
  }
  setTimeout(frog,2000+Math.random()*3000);
}

// ── 清晨鸟鸣（多层次，清脆悠远）──
function mpSynthDawnBirdsLoop(){
  // 鸟类A：清脆高频（知更鸟风格）
  function birdA(){
    if(!mpPlaying||MP_TRACKS[mpIdx].id!=='dawn')return;
    var t=mpCtx.currentTime;
    var phrase=[
      {f:2800,f2:3200,dur:0.08},{f:3100,f2:2700,dur:0.1},{f:3400,f2:3600,dur:0.06},
      {f:3000,f2:2500,dur:0.12}
    ];
    var delay=0;
    phrase.forEach(function(p){
      var o=mpCtx.createOscillator(),g=mpCtx.createGain();
      o.type='sine';
      o.frequency.setValueAtTime(p.f,t+delay);
      o.frequency.linearRampToValueAtTime(p.f2,t+delay+p.dur);
      g.gain.setValueAtTime(0,t+delay);
      g.gain.linearRampToValueAtTime(0.07,t+delay+0.015);
      g.gain.exponentialRampToValueAtTime(0.001,t+delay+p.dur);
      o.connect(g);g.connect(mpSynthGain);o.start(t+delay);o.stop(t+delay+p.dur+0.05);
      delay+=p.dur+0.05+Math.random()*0.04;
    });
    setTimeout(birdA,2500+Math.random()*4000);
  }
  // 鸟类B：悠远低一些（画眉鸟风格）
  function birdB(){
    if(!mpPlaying||MP_TRACKS[mpIdx].id!=='dawn')return;
    var t=mpCtx.currentTime;
    var notes=[1800,2100,1600,2200,1900];
    var delay=0;
    notes.forEach(function(f,i){
      var dur=0.15+Math.random()*0.1;
      var o=mpCtx.createOscillator(),g=mpCtx.createGain();
      o.type='sine';
      o.frequency.setValueAtTime(f,t+delay);
      o.frequency.linearRampToValueAtTime(f*(0.9+Math.random()*0.25),t+delay+dur*0.5);
      o.frequency.linearRampToValueAtTime(f*0.88,t+delay+dur);
      g.gain.setValueAtTime(0,t+delay);
      g.gain.linearRampToValueAtTime(0.055,t+delay+0.03);
      g.gain.exponentialRampToValueAtTime(0.001,t+delay+dur);
      o.connect(g);g.connect(mpSynthGain);o.start(t+delay);o.stop(t+delay+dur+0.05);
      delay+=dur+0.06+Math.random()*0.08;
    });
    setTimeout(birdB,5000+Math.random()*7000);
  }
  // 鸟类C：短促清脆（麻雀风格）
  function birdC(){
    if(!mpPlaying||MP_TRACKS[mpIdx].id!=='dawn')return;
    var t=mpCtx.currentTime;
    var count=3+Math.floor(Math.random()*4);
    for(var i=0;i<count;i++){
      (function(ii){
        var dt=ii*0.09+Math.random()*0.02;
        var freq=3500+Math.random()*800;
        var o=mpCtx.createOscillator(),g=mpCtx.createGain();
        o.type='sine'; o.frequency.value=freq;
        g.gain.setValueAtTime(0,t+dt);
        g.gain.linearRampToValueAtTime(0.05,t+dt+0.01);
        g.gain.exponentialRampToValueAtTime(0.001,t+dt+0.07);
        o.connect(g);g.connect(mpSynthGain);o.start(t+dt);o.stop(t+dt+0.09);
      })(i);
    }
    setTimeout(birdC,1800+Math.random()*3500);
  }
  setTimeout(birdA,300);
  setTimeout(birdB,1200+Math.random()*2000);
  setTimeout(birdC,600+Math.random()*1000);
}

// ── 森林鸟鸣 ──
function mpSynthBirdsLoop(id){
  function chirp(){
    if(!mpPlaying||MP_TRACKS[mpIdx].id!==id)return;
    var freq=1900+Math.random()*1200,dur=0.07+Math.random()*0.12;
    var o=mpCtx.createOscillator(),g=mpCtx.createGain();
    o.type='sine';
    o.frequency.setValueAtTime(freq,mpCtx.currentTime);
    o.frequency.linearRampToValueAtTime(freq*1.35,mpCtx.currentTime+dur/2);
    o.frequency.linearRampToValueAtTime(freq*0.88,mpCtx.currentTime+dur);
    g.gain.setValueAtTime(0,mpCtx.currentTime);
    g.gain.linearRampToValueAtTime(0.08,mpCtx.currentTime+0.02);
    g.gain.exponentialRampToValueAtTime(0.001,mpCtx.currentTime+dur);
    o.connect(g);g.connect(mpSynthGain);o.start();o.stop(mpCtx.currentTime+dur+0.05);
    var rep=Math.floor(Math.random()*3);
    for(var r=0;r<rep;r++){(function(ri){setTimeout(function(){
      if(!mpPlaying)return;
      var o2=mpCtx.createOscillator(),g2=mpCtx.createGain();
      o2.type='sine';o2.frequency.value=freq*(1+ri*0.06);
      g2.gain.setValueAtTime(0,mpCtx.currentTime);
      g2.gain.linearRampToValueAtTime(0.055,mpCtx.currentTime+0.02);
      g2.gain.exponentialRampToValueAtTime(0.001,mpCtx.currentTime+dur*0.75);
      o2.connect(g2);g2.connect(mpSynthGain);o2.start();o2.stop(mpCtx.currentTime+dur*0.8);
    },ri*130+70);})(r);}
    setTimeout(chirp,1300+Math.random()*3200);
  }
  setTimeout(chirp,500+Math.random()*800);
}

// ── 壁炉噼啪 ──
function mpSynthCrackleLoop(id){
  function crack(){
    if(!mpPlaying||MP_TRACKS[mpIdx].id!==id)return;
    var freq=300+Math.random()*500,dur=0.025+Math.random()*0.055;
    var o=mpCtx.createOscillator(),g=mpCtx.createGain();
    o.type='sawtooth';o.frequency.value=freq;
    g.gain.setValueAtTime(0.1,mpCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,mpCtx.currentTime+dur);
    o.connect(g);g.connect(mpSynthGain);o.start();o.stop(mpCtx.currentTime+dur+0.02);
    setTimeout(crack,180+Math.random()*550);
  }
  setTimeout(crack,200);
}

// ── 钢琴合成（更舒缓的旋律）──
function mpSynthPianoLoop(){
  var scale=[261.63,293.66,329.63,369.99,392,440,493.88,523.25];
  var melodies=[
    [0,2,4,7,6,4,2,0,1,3,5,7,5,3,1,0],
    [4,5,4,2,0,2,4,5,7,5,4,2,0,1,2,0]
  ];
  var mel=melodies[Math.floor(Math.random()*melodies.length)];
  var t=mpCtx.currentTime, step=1.1;
  mel.forEach(function(ni,i){
    var freq=scale[ni%scale.length];
    [1,2,3].forEach(function(h){
      var o=mpCtx.createOscillator(),g=mpCtx.createGain();
      o.type='sine';o.frequency.value=freq*h;
      var at=t+i*step,rel=at+step*0.78;
      g.gain.setValueAtTime(0,at);
      g.gain.linearRampToValueAtTime(0.13/(h*h),at+0.05);
      g.gain.exponentialRampToValueAtTime(0.001,rel);
      o.connect(g);g.connect(mpSynthGain);o.start(at);o.stop(rel+0.06);
    });
    if(i%4===0){
      var bo=mpCtx.createOscillator(),bg2=mpCtx.createGain();
      bo.type='sine';bo.frequency.value=freq/2;
      bg2.gain.setValueAtTime(0,t+i*step);
      bg2.gain.linearRampToValueAtTime(0.08,t+i*step+0.06);
      bg2.gain.exponentialRampToValueAtTime(0.001,t+i*step+step*0.6);
      bo.connect(bg2);bg2.connect(mpSynthGain);bo.start(t+i*step);bo.stop(t+i*step+step*0.65);
    }
  });
  var totalDur=mel.length*step*1000-100;
  var loopTimer=setTimeout(function(){ if(mpPlaying&&MP_TRACKS[mpIdx].id==='piano1') mpSynthPianoLoop(); },totalDur);
  mpSynthNodes.push({stop:function(){clearTimeout(loopTimer);},disconnect:function(){}});
}

// ── LoFi 合成（温暖慵懒感）──
function mpSynthLoFiLoop(){
  var chords=[
    [130.81,164.81,196],
    [146.83,184.99,220],
    [110,138.59,164.81],
    [123.47,155.56,185]
  ];
  var t=mpCtx.currentTime, dur=3.5;
  chords.forEach(function(ch,ci){
    var ct=t+ci*dur;
    ch.forEach(function(freq,fi){
      var o=mpCtx.createOscillator(),f=mpCtx.createBiquadFilter(),g=mpCtx.createGain();
      o.type='triangle';o.frequency.value=freq*(1+Math.random()*0.002);
      f.type='lowpass';f.frequency.value=700+fi*200;
      g.gain.setValueAtTime(0,ct);
      g.gain.linearRampToValueAtTime(0.065-fi*0.015,ct+0.15);
      g.gain.linearRampToValueAtTime(0.055-fi*0.012,ct+dur-0.3);
      g.gain.linearRampToValueAtTime(0,ct+dur);
      o.connect(f);f.connect(g);g.connect(mpSynthGain);o.start(ct);o.stop(ct+dur+0.1);
    });
    // 轻鼓击
    if(ci%2===0){
      var kick=mpCtx.createOscillator(),kgain=mpCtx.createGain();
      kick.type='sine';kick.frequency.setValueAtTime(120,ct+dur*0.5);
      kick.frequency.exponentialRampToValueAtTime(40,ct+dur*0.5+0.15);
      kgain.gain.setValueAtTime(0.12,ct+dur*0.5);
      kgain.gain.exponentialRampToValueAtTime(0.001,ct+dur*0.5+0.2);
      kick.connect(kgain);kgain.connect(mpSynthGain);kick.start(ct+dur*0.5);kick.stop(ct+dur*0.5+0.25);
    }
  });
  var totalDur=chords.length*dur*1000-100;
  var loopTimer=setTimeout(function(){ if(mpPlaying&&MP_TRACKS[mpIdx].id==='lofi') mpSynthLoFiLoop(); },totalDur);
  mpSynthNodes.push({stop:function(){clearTimeout(loopTimer);},disconnect:function(){}});
}

// ── 弦乐合成（更丰富和声）──
function mpSynthStringsLoop(){
  var prog=[
    [196,246.94,293.66,369.99],
    [220,277.18,329.63,415.30],
    [174.61,220,261.63,329.63],
    [185,233.08,277.18,349.23]
  ];
  var t=mpCtx.currentTime, dur=5.5;
  prog.forEach(function(chord,ci){
    var ct=t+ci*dur;
    chord.forEach(function(freq,fi){
      var o=mpCtx.createOscillator(),f=mpCtx.createBiquadFilter(),g=mpCtx.createGain();
      o.type='sawtooth';
      // 轻微音高偏移模拟弓弦
      o.frequency.value=freq*(1+(fi%2===0?0.002:-0.002));
      f.type='lowpass';f.frequency.value=1000-fi*80;
      g.gain.setValueAtTime(0,ct);
      g.gain.linearRampToValueAtTime(0.045-fi*0.007,ct+0.8);
      g.gain.linearRampToValueAtTime(0.04-fi*0.006,ct+dur-0.6);
      g.gain.linearRampToValueAtTime(0,ct+dur);
      o.connect(f);f.connect(g);g.connect(mpSynthGain);o.start(ct);o.stop(ct+dur+0.1);
    });
  });
  var totalDur=prog.length*dur*1000-100;
  var loopTimer=setTimeout(function(){ if(mpPlaying&&MP_TRACKS[mpIdx].id==='strings') mpSynthStringsLoop(); },totalDur);
  mpSynthNodes.push({stop:function(){clearTimeout(loopTimer);},disconnect:function(){}});
}

// ── 控制函数 ──
function mpToggle(){
  if(mpPlaying){
    mpStopAll();
    if(mpBgEnabled) mpStopBg();
    mpUpdateUI();
  } else {
    mpStartCurrent();
  }
}
function mpPrev(){
  mpIdx=(mpIdx-1+MP_TRACKS.length)%MP_TRACKS.length;
  mpStartCurrent();
}
function mpNext(){
  mpIdx=(mpIdx+1)%MP_TRACKS.length;
  mpStartCurrent();
}
function mpToggleLoop(){
  mpLoop=!mpLoop;
  document.getElementById('mpLoopBtn').style.opacity=mpLoop?'1':'0.35';
}
function mpSetVol(v){
  mpVol=v/100;
  if(mpSynthGain) mpSynthGain.gain.setTargetAtTime(mpVol,mpCtx?mpCtx.currentTime:0,0.05);
}
function mpTogglePanel(){
  mpPanelOpen=!mpPanelOpen;
  document.getElementById('musicPanel').classList.toggle('open',mpPanelOpen);
}
function mpToggleBg(on){
  mpBgEnabled=on;
  if(on&&mpPlaying) mpStartBg(MP_TRACKS[mpIdx].bg);
  else mpStopBg();
}

// ── UI更新 ──
function mpUpdateUI(){
  var tr=MP_TRACKS[mpIdx];
  document.getElementById('mpIcon').textContent=tr.emoji;
  document.getElementById('mpName').textContent=tr.name;
  document.getElementById('mpSub').textContent=tr.sub;
  document.getElementById('mpPlayBtn').textContent=mpPlaying?'⏸':'▶';
  var btn=document.getElementById('musicToggleBtn');
  btn.classList.toggle('playing',mpPlaying);
  btn.textContent=mpPlaying?'♫':'🎵';
  document.querySelectorAll('.mp-track-item').forEach(function(el,i){
    el.classList.toggle('active',i===mpIdx);
  });
  // EQ动画控制
  document.querySelectorAll('.mp-eq-bar').forEach(function(bar){
    bar.style.animationPlayState=mpPlaying?'running':'paused';
  });
}

function mpBuildList(){
  var list=document.getElementById('mpList');list.innerHTML='';
  MP_TRACKS.forEach(function(tr,i){
    var el=document.createElement('div');
    el.className='mp-track-item'+(i===mpIdx?' active':'');
    el.innerHTML='<span class="mp-track-emoji">'+tr.emoji+'</span>'
      +'<span class="mp-track-label">'+tr.name+'</span>'
      +'<div class="mp-eq">'
      +'<div class="mp-eq-bar" style="--s:.48s"></div>'
      +'<div class="mp-eq-bar" style="--s:.65s;animation-delay:.11s"></div>'
      +'<div class="mp-eq-bar" style="--s:.38s;animation-delay:.22s"></div>'
      +'</div>';
    el.onclick=function(){mpIdx=i;mpStartCurrent();};
    list.appendChild(el);
  });
}

// ══════════════════════════════════════════
//   DYNAMIC BACKGROUND CANVAS
// ══════════════════════════════════════════
var mpCanvas = document.getElementById('mpBgCanvas');
var mpCC = mpCanvas.getContext('2d');
var mpBgRaf = null;
var mpBgTime = 0;
var mpBgDrops = [];
var mpBgParts = [];

function mpResizeCanvas(){
  mpCanvas.width=window.innerWidth; mpCanvas.height=window.innerHeight;
  var fc=document.getElementById('mpFsCanvas');
  if(fc){fc.width=window.innerWidth;fc.height=window.innerHeight;fc._sized=true;}
}
window.addEventListener('resize', mpResizeCanvas);
mpResizeCanvas();

function mpStopBg(){
  if(mpBgRaf){cancelAnimationFrame(mpBgRaf);mpBgRaf=null;}
  mpCanvas.classList.remove('active');
  var fc=document.getElementById('mpFsCanvas');if(fc)fc.style.opacity='0';
  mpBgDrops=[]; mpBgParts=[];
}
function mpStartBg(cfg){
  mpStopBg();
  if(!cfg)return;
  mpBgTime=0; mpBgDrops=[]; mpBgParts=[];
  var W=mpCanvas.width,H=mpCanvas.height;
  if(cfg.type==='rain'||cfg.type==='heavyrain'){
    for(var i=0;i<(cfg.type==='heavyrain'?200:120);i++) mpBgDrops.push(mpNewDrop(cfg.type));
  }
  if(cfg.type==='cosmos'||cfg.type==='night'||cfg.type==='dawn'){
    for(var i=0;i<70;i++) mpBgParts.push({x:Math.random()*W,y:Math.random()*(cfg.type==='dawn'?H*0.5:H),r:Math.random()*1.4+0.3,spd:Math.random()*0.22+0.04,alpha:Math.random(),ph:Math.random()*Math.PI*2});
  }
  if(cfg.type==='fire'){ for(var i=0;i<60;i++) mpBgParts.push(mpNewFireP()); }
  if(cfg.type==='ocean'){ for(var i=0;i<6;i++) mpBgParts.push({y:H*0.52+i*36,ph:i*0.85,spd:0.007+i*0.003}); }
  if(cfg.type==='forest'){ for(var i=0;i<45;i++) mpBgParts.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-0.5)*0.4,vy:-(Math.random()*0.3+0.08),alpha:Math.random()*0.42+0.08,life:Math.random(),r:Math.random()*3+1}); }
  if(cfg.type==='piano'||cfg.type==='lofi'||cfg.type==='strings'){ for(var i=0;i<30;i++) mpBgParts.push({x:Math.random()*W,y:H+10,vx:(Math.random()-0.5)*0.6,vy:-(Math.random()*0.45+0.15),alpha:0,maxA:Math.random()*0.28+0.08,r:Math.random()*1.5+0.4,ph:Math.random()*Math.PI*2,grow:true}); }
  if(cfg.type==='night'){ mpBgParts._ff=[]; for(var i=0;i<16;i++) mpBgParts._ff.push({x:Math.random()*W,y:H*0.38+Math.random()*H*0.5,vx:(Math.random()-0.5)*0.44,vy:(Math.random()-0.5)*0.28,ph:Math.random()*Math.PI*2,r:Math.random()*1.6+0.7}); }
  if(cfg.type==='dawn'){ mpBgParts._birds=[]; for(var i=0;i<5;i++) mpBgParts._birds.push({x:Math.random()*W,y:H*0.18+Math.random()*H*0.22,spd:0.35+Math.random()*0.55,ph:Math.random()*Math.PI*2,sz:2+Math.random()*2}); }
  mpCanvas.classList.add('active');
  var mpFsEl=document.getElementById('mpFsCanvas');
  if(mpFsEl){mpFsEl.style.opacity='1';}
  function frame(){
    mpBgDraw(cfg,mpCanvas,mpCC);
    var fsel=document.getElementById('mpFsCanvas');
    if(fsel&&fsel.getContext&&fsOpen){
      var fcc=fsel._cc||(fsel._cc=fsel.getContext('2d'));
      if(!fsel._sized){fsel.width=window.innerWidth;fsel.height=window.innerHeight;fsel._sized=true;}
      mpBgDraw(cfg,fsel,fcc);
    }
    mpBgTime+=0.016; mpBgRaf=requestAnimationFrame(frame);
  }
  mpBgRaf=requestAnimationFrame(frame);
}
function mpNewDrop(type){ var h=type==='heavyrain'; return{x:Math.random()*mpCanvas.width,y:Math.random()*mpCanvas.height-mpCanvas.height,len:h?(Math.random()*20+10):(Math.random()*12+5),spd:h?(Math.random()*9+7):(Math.random()*5+3),alpha:Math.random()*0.30+0.07,w:h?(Math.random()*1.2+0.4):(Math.random()*0.7+0.2)}; }
function mpNewFireP(){ return{x:mpCanvas.width/2+(Math.random()-0.5)*mpCanvas.width*0.55,y:mpCanvas.height+20,r:Math.random()*8+3,vx:(Math.random()-0.5)*1.1,vy:-(Math.random()*3+1.4),alpha:Math.random()*0.55+0.2,hue:Math.random()*40}; }

function mpBgDraw(cfg,cv,cc){
  cv=cv||mpCanvas;cc=cc||mpCC;
  var W=cv.width,H=cv.height,t=mpBgTime,c=cc;
  c.clearRect(0,0,W,H);
  if(cfg.type==='rain'||cfg.type==='heavyrain'){
    var g=c.createLinearGradient(0,0,0,H);
    g.addColorStop(0,cfg.type==='heavyrain'?'rgba(4,8,22,0.84)':'rgba(7,16,38,0.76)');
    g.addColorStop(1,cfg.type==='heavyrain'?'rgba(2,4,16,0.90)':'rgba(3,10,28,0.84)');
    c.fillStyle=g;c.fillRect(0,0,W,H);
    c.strokeStyle='rgba(180,210,255,0.52)';
    for(var i=0;i<mpBgDrops.length;i++){
      var d=mpBgDrops[i];c.globalAlpha=d.alpha;c.lineWidth=d.w;
      c.beginPath();c.moveTo(d.x,d.y);c.lineTo(d.x+d.len*0.14,d.y+d.len);c.stroke();
      d.x+=d.len*0.07;d.y+=d.spd;
      if(d.y>H){var nd=mpNewDrop(cfg.type);d.x=nd.x;d.y=nd.y;d.len=nd.len;d.spd=nd.spd;d.alpha=nd.alpha;}
    }
    c.globalAlpha=1;
    if(Math.random()<0.035){c.strokeStyle='rgba(180,220,255,0.14)';c.lineWidth=0.7;c.beginPath();c.ellipse(Math.random()*W,H-Math.random()*50-8,Math.random()*15+4,Math.random()*4+2,0,0,Math.PI*2);c.stroke();}
  }
  else if(cfg.type==='ocean'){
    var g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,'rgba(4,14,38,0.82)');g.addColorStop(0.6,'rgba(7,38,76,0.79)');g.addColorStop(1,'rgba(2,18,52,0.90)');c.fillStyle=g;c.fillRect(0,0,W,H);
    for(var i=0;i<mpBgParts.length;i++){var wv=mpBgParts[i];wv.ph+=wv.spd;c.beginPath();c.moveTo(0,wv.y);for(var x=0;x<=W;x+=5)c.lineTo(x,wv.y+Math.sin(x*0.007+wv.ph)*26+Math.sin(x*0.014+wv.ph*0.65)*10);c.lineTo(W,H);c.lineTo(0,H);c.closePath();c.fillStyle='rgba(28,95,175,'+(0.042-i*0.005)+')';c.fill();c.strokeStyle='rgba(90,170,255,'+(0.11-i*0.013)+')';c.lineWidth=1.1;c.stroke();}
    for(var li=0;li<4;li++){var lx=W*0.18+li*W*0.2,ly=H*0.28+Math.sin(t*0.4+li)*H*0.1;var lg2=c.createRadialGradient(lx,ly,0,lx,ly,75+li*18);lg2.addColorStop(0,'rgba(70,150,255,0.055)');lg2.addColorStop(1,'rgba(70,150,255,0)');c.fillStyle=lg2;c.fillRect(0,0,W,H);}
  }
  else if(cfg.type==='fire'){
    var g=c.createLinearGradient(0,H,0,0);g.addColorStop(0,'rgba(55,8,0,0.94)');g.addColorStop(0.5,'rgba(18,2,0,0.90)');g.addColorStop(1,'rgba(4,0,0,0.87)');c.fillStyle=g;c.fillRect(0,0,W,H);
    for(var i=0;i<mpBgParts.length;i++){var fp=mpBgParts[i];fp.x+=fp.vx+Math.sin(t*1.8+i)*0.28;fp.y+=fp.vy;fp.alpha-=0.007;fp.r*=0.996;if(fp.alpha<=0||fp.y<H*0.18){var nfp=mpNewFireP();Object.assign(fp,nfp);}var fg=c.createRadialGradient(fp.x,fp.y,0,fp.x,fp.y,fp.r);fg.addColorStop(0,'rgba(255,235,90,'+fp.alpha+')');fg.addColorStop(0.4,'rgba('+(218+fp.hue|0)+','+(70+fp.hue*2.5|0)+',0,'+fp.alpha+')');fg.addColorStop(1,'rgba(200,45,0,0)');c.fillStyle=fg;c.beginPath();c.arc(fp.x,fp.y,fp.r,0,Math.PI*2);c.fill();}
  }
  else if(cfg.type==='cosmos'){
    var g=c.createRadialGradient(W/2,H/2,0,W/2,H/2,Math.max(W,H)*0.82);g.addColorStop(0,'rgba(14,5,48,0.90)');g.addColorStop(1,'rgba(1,0,9,0.96)');c.fillStyle=g;c.fillRect(0,0,W,H);
    for(var i=0;i<mpBgParts.length;i++){var sp=mpBgParts[i];sp.alpha=0.38+0.52*Math.sin(t*sp.spd+sp.ph);c.globalAlpha=sp.alpha;c.fillStyle='#fff';c.beginPath();c.arc(sp.x,sp.y,sp.r,0,Math.PI*2);c.fill();}c.globalAlpha=1;
    var nx=W/2+Math.sin(t*0.07)*W*0.14,ny=H/2+Math.cos(t*0.055)*H*0.1;var ng=c.createRadialGradient(nx,ny,0,nx,ny,Math.min(W,H)*0.42);ng.addColorStop(0,'rgba(95,55,200,0.07)');ng.addColorStop(0.5,'rgba(55,25,145,0.04)');ng.addColorStop(1,'rgba(18,8,75,0)');c.fillStyle=ng;c.fillRect(0,0,W,H);
  }
  else if(cfg.type==='forest'){
    var g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,'rgba(4,16,7,0.87)');g.addColorStop(1,'rgba(1,8,3,0.92)');c.fillStyle=g;c.fillRect(0,0,W,H);
    for(var ti=0;ti<8;ti++){var tx=W*ti/7,th=H*0.38+Math.sin(t*0.28+ti)*H*0.04;c.fillStyle='rgba(0,7,2,0.62)';c.beginPath();c.moveTo(tx,H);c.lineTo(tx-W*0.055,H-th*0.6);c.lineTo(tx,H-th);c.lineTo(tx+W*0.055,H-th*0.6);c.closePath();c.fill();}
    for(var i=0;i<mpBgParts.length;i++){var gp=mpBgParts[i];gp.x+=gp.vx;gp.y+=gp.vy;gp.life+=0.004;if(gp.life>1||gp.x<0||gp.x>W||gp.y<0){gp.x=Math.random()*W;gp.y=H*0.32+Math.random()*H*0.5;gp.life=Math.random();gp.alpha=Math.random()*0.38+0.08;}var ga=gp.alpha*Math.sin(gp.life*Math.PI);if(ga>0){var gg=c.createRadialGradient(gp.x,gp.y,0,gp.x,gp.y,gp.r*3);gg.addColorStop(0,'rgba(175,255,110,'+ga+')');gg.addColorStop(1,'rgba(175,255,110,0)');c.fillStyle=gg;c.beginPath();c.arc(gp.x,gp.y,gp.r*3,0,Math.PI*2);c.fill();}}
  }
  else if(cfg.type==='night'){
    var g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,'rgba(2,3,16,0.95)');g.addColorStop(1,'rgba(4,7,24,0.97)');c.fillStyle=g;c.fillRect(0,0,W,H);
    for(var i=0;i<mpBgParts.length;i++){var sp=mpBgParts[i];sp.alpha=0.28+0.62*Math.sin(t*sp.spd+sp.ph);c.globalAlpha=sp.alpha;c.fillStyle='#dde8ff';c.beginPath();c.arc(sp.x,sp.y,sp.r,0,Math.PI*2);c.fill();}c.globalAlpha=1;
    var mx=W*0.76,my=H*0.11;var mg=c.createRadialGradient(mx,my,0,mx,my,88);mg.addColorStop(0,'rgba(215,228,255,0.13)');mg.addColorStop(1,'rgba(215,228,255,0)');c.fillStyle=mg;c.fillRect(0,0,W,H);c.fillStyle='rgba(228,235,255,0.90)';c.beginPath();c.arc(mx,my,13,0,Math.PI*2);c.fill();
    if(mpBgParts._ff)mpBgParts._ff.forEach(function(ff){ff.x+=ff.vx+Math.sin(t*0.38+ff.ph)*0.28;ff.y+=ff.vy;if(ff.x<0)ff.x=W;if(ff.x>W)ff.x=0;if(ff.y<H*0.28||ff.y>H*0.95)ff.vy*=-1;var fa=0.45+0.55*Math.sin(t*2.2+ff.ph);if(fa>0.25){var fg=c.createRadialGradient(ff.x,ff.y,0,ff.x,ff.y,ff.r*4.5);fg.addColorStop(0,'rgba(175,255,110,'+fa*0.85+')');fg.addColorStop(1,'rgba(175,255,110,0)');c.fillStyle=fg;c.beginPath();c.arc(ff.x,ff.y,ff.r*4.5,0,Math.PI*2);c.fill();}});
  }
  else if(cfg.type==='dawn'){
    var g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,'rgba(28,18,55,0.87)');g.addColorStop(0.32,'rgba(75,35,18,0.82)');g.addColorStop(0.65,'rgba(170,80,24,0.72)');g.addColorStop(0.88,'rgba(230,148,50,0.64)');g.addColorStop(1,'rgba(252,195,90,0.56)');c.fillStyle=g;c.fillRect(0,0,W,H);
    var sx=W*0.54,sy=H*0.74;var sg=c.createRadialGradient(sx,sy,0,sx,sy,210);sg.addColorStop(0,'rgba(255,215,70,0.20)');sg.addColorStop(0.42,'rgba(255,140,25,0.08)');sg.addColorStop(1,'rgba(255,90,0,0)');c.fillStyle=sg;c.fillRect(0,0,W,H);
    c.fillStyle='rgba(12,8,32,0.68)';c.beginPath();c.moveTo(0,H);for(var mx2=0;mx2<=W;mx2+=W/10)c.lineTo(mx2,H*0.60+Math.sin(mx2*0.0028+0.4)*H*0.09+Math.sin(mx2*0.0072)*H*0.042);c.lineTo(W,H);c.closePath();c.fill();
    var fog=c.createLinearGradient(0,H*0.58,0,H*0.86);fog.addColorStop(0,'rgba(255,215,148,0)');fog.addColorStop(1,'rgba(255,215,148,0.09)');c.fillStyle=fog;c.fillRect(0,H*0.58,W,H*0.28);
    for(var i=0;i<Math.min(mpBgParts.length,22);i++){var sp2=mpBgParts[i];var sa=Math.max(0,0.38*Math.sin(t*sp2.spd+sp2.ph));if(sa>0.04){c.globalAlpha=sa*0.45;c.fillStyle='#fff';c.beginPath();c.arc(sp2.x,sp2.y*0.42,sp2.r*0.65,0,Math.PI*2);c.fill();}}c.globalAlpha=1;
    if(mpBgParts._birds)mpBgParts._birds.forEach(function(bird){bird.x+=bird.spd;if(bird.x>W+32)bird.x=-32;var by=bird.y+Math.sin(t*1.4+bird.ph)*7;var bw=bird.sz*4;c.strokeStyle='rgba(18,8,38,0.72)';c.lineWidth=bird.sz*0.55;c.beginPath();c.moveTo(bird.x-bw,by);c.quadraticCurveTo(bird.x,by-bird.sz*2,bird.x+bw,by);c.stroke();});
  }
  else if(cfg.type==='piano'||cfg.type==='lofi'||cfg.type==='strings'){
    var cols=cfg.type==='piano'?[[167,139,250],[99,102,241]]:cfg.type==='lofi'?[[251,146,60],[234,88,12]]:[[192,132,252],[168,85,247]];
    c.fillStyle='rgba(4,2,18,0.90)';c.fillRect(0,0,W,H);
    cols.forEach(function(col,ci){var ox=W*0.3+Math.sin(t*0.18+ci*2.0)*W*0.24,oy=H*0.42+Math.cos(t*0.13+ci*1.75)*H*0.18;var cg=c.createRadialGradient(ox,oy,0,ox,oy,Math.min(W,H)*(0.36+ci*0.09));cg.addColorStop(0,'rgba('+col[0]+','+col[1]+','+col[2]+',0.088)');cg.addColorStop(1,'rgba('+col[0]+','+col[1]+','+col[2]+',0)');c.fillStyle=cg;c.fillRect(0,0,W,H);});
    for(var i=0;i<mpBgParts.length;i++){var np=mpBgParts[i];np.x+=np.vx+Math.sin(t*0.48+np.ph)*0.28;np.y+=np.vy;if(np.grow){np.alpha+=0.0038;if(np.alpha>=np.maxA)np.grow=false;}else np.alpha-=0.0018;if(np.alpha<=0||np.y<-18){np.x=Math.random()*W;np.y=H+8;np.alpha=0;np.grow=true;}if(np.alpha>0){c.globalAlpha=np.alpha;c.fillStyle='rgba('+cols[0][0]+','+cols[0][1]+','+cols[0][2]+',1)';c.beginPath();c.arc(np.x,np.y,np.r,0,Math.PI*2);c.fill();}}c.globalAlpha=1;
  }
}

// ── 同步全屏canvas状态 ──
function mpSyncFsCanvas(){
  var fc=document.getElementById('mpFsCanvas');
  if(!fc)return;
  if(fsOpen&&mpPlaying){fc.style.opacity='1';}
  else{fc.style.opacity='0';}
}

// ── 时间转换面板升级 ──
function upgradeConverterUI() {
    if (document.getElementById('convBaseLine')) return; // 防止脚本重复插入导致内容重复
    var card = document.getElementById('converterCard');
    var fmtBarEl = document.getElementById('convFmtBar');
    var resultsEl = document.getElementById('convResults');
    if (!card || !fmtBarEl || !resultsEl) return;

    var headerTitleEl = document.getElementById('convTitleEl');
    if (headerTitleEl) {
      headerTitleEl.insertAdjacentHTML('beforebegin',
        '<span style="display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:8px;background:linear-gradient(135deg,var(--accent),var(--accent2));margin-right:8px;font-size:12px;flex-shrink:0;">🕐</span>');
    }

    // "从" 改成"基准时区"，并同步修改语言字典，避免以后切换语言又被改回去
    if (typeof I18N !== 'undefined' && I18N.zh) I18N.zh.convFrom = '基准时区';
    var fromLbl = document.getElementById('convFromLbl');
    if (fromLbl) fromLbl.textContent = '基准时区';

    var baseLine = document.createElement('div');
    baseLine.className = 'conv-base-line';
    baseLine.id = 'convBaseLine';
    fmtBarEl.insertAdjacentElement('afterend', baseLine);

    var legend = document.createElement('div');
    legend.className = 'conv-legend';
    legend.innerHTML =
      '<span class="conv-legend-item"><span class="conv-legend-dot" style="background:#34d399;"></span>快于基准时间</span>' +
      '<span class="conv-legend-item"><span class="conv-legend-dot" style="background:#38bdf8;"></span>与基准时间相同</span>' +
      '<span class="conv-legend-item"><span class="conv-legend-dot" style="background:#fb7185;"></span>慢于基准时间</span>';
    baseLine.insertAdjacentElement('afterend', legend);

    // 复制按钮：挪到"换算"按钮旁边，改小
    var convertBtnEl = document.getElementById('convBtnEl');
    var copyBtn = document.createElement('button');
    copyBtn.className = 'conv-action-btn';
    copyBtn.style.marginLeft = '6px';
    copyBtn.textContent = '📋 复制';
    copyBtn.onclick = function () {
      var text = window.__convCopyText || '';
      if (navigator.clipboard && text) {
        navigator.clipboard.writeText(text).then(function () {
          copyBtn.textContent = '✅ 已复制';
          setTimeout(function () { copyBtn.textContent = '📋 复制'; }, 1500);
        }).catch(function () {});
      }
    };
    if (convertBtnEl && convertBtnEl.parentElement) {
      convertBtnEl.insertAdjacentElement('afterend', copyBtn);
    }

    var closeBottomBtn = document.createElement('button');
    closeBottomBtn.className = 'conv-close-bottom';
    closeBottomBtn.innerHTML = '✕ 关闭窗口';
    closeBottomBtn.onclick = function () { if (typeof window.toggleConverter === 'function') window.toggleConverter(); };
    resultsEl.insertAdjacentElement('afterend', closeBottomBtn);

    var CIRCLE_COLOR_MAP = { ahead: '#1d8f63', same: '#1f7fa3', behind: '#c23c54' };

    window.renderConvResults = function () {
      var fromTz = document.getElementById('convFromTz').value;
      var tv = (typeof convTimeVal !== 'undefined' ? convTimeVal : '12:00').split(':');
      var hh = parseInt(tv[0]), mm = parseInt(tv[1]);
      var fromOff = getOffsetMin(fromTz);
      var baseMin = hh * 60 + mm - fromOff;
      var fromClk = tzObj(fromTz);

      if (fromClk) {
        var bd = new Date(); bd.setHours(hh, mm, 0, 0);
        var baseTimeStr = S.convFmt === '24h' ? fmt24(bd, false) : fmt12(bd, false);
        baseLine.innerHTML = '基准时间：' + fromClk.fl + ' ' + cName(fromClk) + '，' + ctName(fromClk) +
          '　' + baseTimeStr + '　' + fmtDate(localD(fromTz), S.dateFmt);
      }

      resultsEl.innerHTML = '';
      var clks = getClocks();
      var copyLines = [];

      clks.forEach(function (clk) {
        var toOff = getOffsetMin(clk.tz);
        var m = baseMin + toOff, dayOff = 0;
        while (m < 0) { m += 1440; dayOff--; }
        while (m >= 1440) { m -= 1440; dayOff++; }
        var rDate = new Date(); rDate.setHours(Math.floor(m / 60), m % 60, 0, 0);
        var ts;
        if (S.convFmt === '12h') ts = fmt12(rDate, false);
        else if (S.convFmt === '24h') ts = fmt24(rDate, false);
        else ts = fmt12(rDate, false) + ' / ' + fmt24(rDate, false);

        var diffMin = toOff - fromOff;
        var diffLabel, cls;
        if (diffMin === 0) { diffLabel = '时间相同'; cls = 'same'; }
        else {
          var ab = Math.abs(diffMin), dh = Math.floor(ab / 60), dm2 = ab % 60;
          diffLabel = (diffMin > 0 ? '快 ' : '慢 ') + (dh ? dh + '小时' : '') + (dm2 ? dm2 + '分钟' : '');
          cls = diffMin > 0 ? 'ahead' : 'behind';
        }
        var dayStr = dayOff === 0 ? '' : (dayOff > 0 ? '（明天）' : '（昨天）');
        var dateForRow = new Date();
        dateForRow.setDate(dateForRow.getDate() + dayOff);
        var dateLine = fmtDate(dateForRow, S.dateFmt);

        var abbr = '';
        try {
          var parts = new Intl.DateTimeFormat('en-US', { timeZone: clk.tz, timeZoneName: 'short' }).formatToParts(new Date());
          var pFound = parts.find(function (x) { return x.type === 'timeZoneName'; });
          abbr = pFound ? pFound.value : '';
        } catch (e) {}

        var circleColor = CIRCLE_COLOR_MAP[cls] || '#555';

        var row = document.createElement('div');
        row.className = 'conv-row-v2 ' + cls;
        row.innerHTML =
          '<div class="conv-flag-circle" style="background:' + circleColor + ';color:#fff;font-weight:700;font-size:11px;">' + clk.cc + '</div>' +
          '<div class="conv-row-main">' +
          '<div class="conv-row-title"><span class="conv-row-country">' + ctName(clk) + '</span><span class="conv-row-city">' + cName(clk) + '</span>' +
          (clk.tz === fromTz ? '<span class="conv-base-badge">基准时间</span>' : '') + '</div>' +
          '<div class="conv-row-meta">' + abbr + '</div></div>' +
          '<div class="conv-row-time-block"><div class="conv-row-time-main">' + ts + '</div>' +
          '<div class="conv-row-time-sub">' + dateLine + (dayStr ? ' ' + dayStr : '') + '</div></div>' +
          '<div class="conv-row-diff-col ' + cls + '">' + diffLabel + '</div>';
        resultsEl.appendChild(row);

        copyLines.push(ctName(clk) + ' ' + cName(clk) + '：' + ts + (dayStr ? ' ' + dayStr : ''));
      });

      window.__convCopyText = copyLines.join('\n');
    };

    if (typeof window.convOpen !== 'undefined' && window.convOpen) window.renderConvResults();
}
setTimeout(upgradeConverterUI, 400);
// ── 初始化 ──
mpBuildList();
mpUpdateUI();
// 默认自动播放：启动即播钢琴轻音乐；浏览器拦截时首次触摸/点击解锁（只解锁一次，不跟用户暂停打架）
var sgAutoDone=false;
function sgUnlock(){
  if(sgAutoDone) return;
  if(typeof mpCtx!=='undefined'&&mpCtx&&mpCtx.state==='suspended'){try{mpCtx.resume();}catch(e){}}
  if(!mpPlaying){try{mpStartCurrent();}catch(e){}}
  if(typeof mpCtx!=='undefined'&&mpCtx&&mpCtx.state==='running'){
    sgAutoDone=true;
    document.removeEventListener('pointerdown',sgUnlock);
    document.removeEventListener('touchstart',sgUnlock);
    document.removeEventListener('click',sgUnlock);
    document.removeEventListener('keydown',sgUnlock);
  }
}
try{mpStartCurrent();}catch(e){}
document.addEventListener('pointerdown',sgUnlock);
document.addEventListener('touchstart',sgUnlock,{passive:true});
document.addEventListener('click',sgUnlock);
document.addEventListener('keydown',sgUnlock);


