
var TZ_DB=[
  {tz:'Australia/Melbourne',city:'Melbourne',czh:'\u58a8\u5c14\u672c',co:'Australia',czho:'\u6fb3\u5927\u5229\u4e9a',fl:'\ud83c\udde6\ud83c\uddfa',dot:'dc-amber',dst:true,cc:'AU',kw:['australia','\u6fb3\u5927\u5229\u4e9a']},
  {tz:'Australia/Sydney',city:'Sydney',czh:'\u6089\u5c3c',co:'Australia',czho:'\u6fb3\u5927\u5229\u4e9a',fl:'\ud83c\udde6\ud83c\uddfa',dot:'dc-orange',dst:true,cc:'AU',kw:['australia']},
  {tz:'Australia/Brisbane',city:'Brisbane',czh:'\u5e03\u91cc\u65af\u73ed',co:'Australia',czho:'\u6fb3\u5927\u5229\u4e9a',fl:'\ud83c\udde6\ud83c\uddfa',dot:'dc-orange',dst:false,cc:'AU',kw:['australia']},
  {tz:'Australia/Perth',city:'Perth',czh:'\u73c0\u65af',co:'Australia',czho:'\u6fb3\u5927\u5229\u4e9a',fl:'\ud83c\udde6\ud83c\uddfa',dot:'dc-amber',dst:false,cc:'AU',kw:['australia']},
  {tz:'Australia/Adelaide',city:'Adelaide',czh:'\u963f\u5fb7\u83b1\u5fb7',co:'Australia',czho:'\u6fb3\u5927\u5229\u4e9a',fl:'\ud83c\udde6\ud83c\uddfa',dot:'dc-amber',dst:true,cc:'AU',kw:['australia']},
  {tz:'Australia/Darwin',city:'Darwin',czh:'\u8fbe\u5c14\u6587',co:'Australia',czho:'\u6fb3\u5927\u5229\u4e9a',fl:'\ud83c\udde6\ud83c\uddfa',dot:'dc-amber',dst:false,cc:'AU',kw:['australia']},
  {tz:'Pacific/Auckland',city:'Auckland',czh:'\u5965\u514b\u5170',co:'New Zealand',czho:'\u65b0\u897f\u5170',fl:'\ud83c\uddf3\ud83c\uddff',dot:'dc-green',dst:true,cc:'NZ',kw:['new zealand','\u65b0\u897f\u5170']},
  {tz:'Pacific/Fiji',city:'Suva',czh:'\u82cf\u74e6',co:'Fiji',czho:'\u65af\u6d4e',fl:'\ud83c\uddeb\ud83c\uddef',dot:'dc-teal',dst:false,cc:'FJ',kw:['fiji']},
  {tz:'Pacific/Honolulu',city:'Honolulu',czh:'\u6a80\u9999\u5c71',co:'USA Hawaii',czho:'\u7f8e\u56fd\u590f\u5a01\u5937',fl:'\ud83c\uddfa\ud83c\uddf8',dot:'dc-sky',dst:false,cc:'US',kw:['hawaii']},
  {tz:'Pacific/Guam',city:'Hagatna',czh:'\u5173\u5c9b',co:'Guam',czho:'\u5173\u5c9b',fl:'\ud83c\uddec\ud83c\uddfa',dot:'dc-teal',dst:false,cc:'GU',kw:['guam']},
  {tz:'Pacific/Apia',city:'Apia',czh:'\u963f\u76ae\u4e9a',co:'Samoa',czho:'\u8428\u6469\u4e9a',fl:'\ud83c\uddfc\ud83c\uddf8',dot:'dc-teal',dst:true,cc:'WS',kw:['samoa']},
  {tz:'Pacific/Tongatapu',city:'Nuku Alofa',czh:'\u52aa\u5e93\u963f\u6d1b\u6cd5',co:'Tonga',czho:'\u6c64\u52a0',fl:'\ud83c\uddf9\ud83c\uddf4',dot:'dc-sky',dst:false,cc:'TO',kw:['tonga']},
  {tz:'Pacific/Tahiti',city:'Papeete',czh:'\u5e15\u76ae\u63d0',co:'Fr. Polynesia',czho:'\u6cd5\u5c5e\u6ce2\u5229\u5c3c\u897f\u4e9a',fl:'\ud83c\uddf5\ud83c\uddeb',dot:'dc-sky',dst:false,cc:'PF',kw:['tahiti']},
  {tz:'Asia/Seoul',city:'Seoul',czh:'\u9996\u5c14',co:'South Korea',czho:'\u97e9\u56fd',fl:'\ud83c\uddf0\ud83c\uddf7',dot:'dc-rose',dst:false,cc:'KR',kw:['korea','\u97e9\u56fd']},
  {tz:'Asia/Tokyo',city:'Tokyo',czh:'\u4e1c\u4eac',co:'Japan',czho:'\u65e5\u672c',fl:'\ud83c\uddef\ud83c\uddf5',dot:'dc-rose',dst:false,cc:'JP',kw:['japan','\u65e5\u672c']},
  {tz:'Asia/Shanghai',city:'Shanghai',czh:'\u4e0a\u6d77',co:'China',czho:'\u4e2d\u56fd',fl:'\ud83c\udde8\ud83c\uddf3',dot:'dc-rose',dst:false,cc:'CN',kw:['china','\u4e2d\u56fd']},
  {tz:'Asia/Hong_Kong',city:'Hong Kong',czh:'\u9999\u6e2f',co:'China HK',czho:'\u9999\u6e2f',fl:'\ud83c\udded\ud83c\uddf0',dot:'dc-rose',dst:false,cc:'HK',kw:['hong kong','\u9999\u6e2f']},
  {tz:'Asia/Taipei',city:'Taipei',czh:'\u53f0\u5317',co:'Taiwan',czho:'\u53f0\u6e7e',fl:'\ud83c\uddf9\ud83c\uddfc',dot:'dc-sky',dst:false,cc:'TW',kw:['taiwan','\u53f0\u6e7e']},
  {tz:'Asia/Macau',city:'Macao',czh:'\u6fb3\u95e8',co:'Macao',czho:'\u6fb3\u95e8',fl:'\ud83c\uddf2\ud83c\uddf4',dot:'dc-rose',dst:false,cc:'MO',kw:['macao','\u6fb3\u95e8']},
  {tz:'Asia/Ulaanbaatar',city:'Ulaanbaatar',czh:'\u4e4c\u5170\u5df4\u6258',co:'Mongolia',czho:'\u8499\u53e4',fl:'\ud83c\uddf2\ud83c\uddf3',dot:'dc-purple',dst:false,cc:'MN',kw:['mongolia']},
  {tz:'Asia/Singapore',city:'Singapore',czh:'\u65b0\u52a0\u5761',co:'Singapore',czho:'\u65b0\u52a0\u5761',fl:'\ud83c\uddf8\ud83c\uddec',dot:'dc-teal',dst:false,cc:'SG',kw:['singapore','\u65b0\u52a0\u5761']},
  {tz:'Asia/Bangkok',city:'Bangkok',czh:'\u66fc\u8c37',co:'Thailand',czho:'\u6cf0\u56fd',fl:'\ud83c\uddf9\ud83c\udded',dot:'dc-teal',dst:false,cc:'TH',kw:['thailand','\u6cf0\u56fd']},
  {tz:'Asia/Kuala_Lumpur',city:'Kuala Lumpur',czh:'\u5409\u9686\u5761',co:'Malaysia',czho:'\u9a6c\u6765\u897f\u4e9a',fl:'\ud83c\uddf2\ud83c\uddfe',dot:'dc-teal',dst:false,cc:'MY',kw:['malaysia']},
  {tz:'Asia/Jakarta',city:'Jakarta',czh:'\u96c5\u52a0\u8fbe',co:'Indonesia',czho:'\u5370\u5ea6\u5c3c\u897f\u4e9a',fl:'\ud83c\uddee\ud83c\udde9',dot:'dc-teal',dst:false,cc:'ID',kw:['indonesia']},
  {tz:'Asia/Manila',city:'Manila',czh:'\u9a6c\u5c3c\u62c9',co:'Philippines',czho:'\u83f2\u5f8b\u5bbe',fl:'\ud83c\uddf5\ud83c\udded',dot:'dc-rose',dst:false,cc:'PH',kw:['philippines']},
  {tz:'Asia/Ho_Chi_Minh',city:'Ho Chi Minh',czh:'\u80e1\u5fd7\u660e\u5e02',co:'Vietnam',czho:'\u8d8a\u5357',fl:'\ud83c\uddfb\ud83c\uddf3',dot:'dc-teal',dst:false,cc:'VN',kw:['vietnam']},
  {tz:'Asia/Phnom_Penh',city:'Phnom Penh',czh:'\u91d1\u8fb9',co:'Cambodia',czho:'\u67ec\u57d4\u5be8',fl:'\ud83c\uddf0\ud83c\udded',dot:'dc-teal',dst:false,cc:'KH',kw:['cambodia','\u67ec\u57d4\u5be8']},
  {tz:'Asia/Yangon',city:'Yangon',czh:'\u4ef0\u5149',co:'Myanmar',czho:'\u7f05\u7538',fl:'\ud83c\uddf2\ud83c\uddf2',dot:'dc-teal',dst:false,cc:'MM',kw:['myanmar']},
  {tz:'Asia/Kolkata',city:'Mumbai/Delhi',czh:'\u5b5f\u4e70/\u5fb7\u91cc',co:'India',czho:'\u5370\u5ea6',fl:'\ud83c\uddee\ud83c\uddf3',dot:'dc-amber',dst:false,cc:'IN',kw:['india','\u5370\u5ea6']},
  {tz:'Asia/Dhaka',city:'Dhaka',czh:'\u8fbe\u5361',co:'Bangladesh',czho:'\u5b5f\u52a0\u62c9\u56fd',fl:'\ud83c\udde7\ud83c\udde9',dot:'dc-teal',dst:false,cc:'BD',kw:['bangladesh']},
  {tz:'Asia/Karachi',city:'Karachi',czh:'\u5361\u62c9\u5947',co:'Pakistan',czho:'\u5df4\u57fa\u65af\u5766',fl:'\ud83c\uddf5\ud83c\uddf0',dot:'dc-amber',dst:false,cc:'PK',kw:['pakistan']},
  {tz:'Asia/Kathmandu',city:'Kathmandu',czh:'\u52a0\u5fb7\u6ee1\u90fd',co:'Nepal',czho:'\u5c3c\u6cca\u5c14',fl:'\ud83c\uddf3\ud83c\uddf5',dot:'dc-amber',dst:false,cc:'NP',kw:['nepal']},
  {tz:'Asia/Colombo',city:'Colombo',czh:'\u79d1\u4f26\u5761',co:'Sri Lanka',czho:'\u65af\u91cc\u5170\u5361',fl:'\ud83c\uddf1\ud83c\uddf0',dot:'dc-teal',dst:false,cc:'LK',kw:['sri lanka']},
  {tz:'Indian/Maldives',city:'Male',czh:'\u9a6c\u7d2f',co:'Maldives',czho:'\u9a6c\u5c14\u4ee3\u592b',fl:'\ud83c\uddf2\ud83c\uddfb',dot:'dc-sky',dst:false,cc:'MV',kw:['maldives']},
  {tz:'Asia/Almaty',city:'Almaty',czh:'\u963f\u62c9\u6728\u56fe',co:'Kazakhstan',czho:'\u54c8\u8428\u514b\u65af\u5766',fl:'\ud83c\uddf0\ud83c\uddff',dot:'dc-sky',dst:false,cc:'KZ',kw:['kazakhstan']},
  {tz:'Asia/Dubai',city:'Dubai',czh:'\u8fea\u62dc',co:'UAE',czho:'\u963f\u8054\u914b',fl:'\ud83c\udde6\ud83c\uddea',dot:'dc-amber',dst:false,cc:'AE',kw:['uae']},
  {tz:'Asia/Riyadh',city:'Riyadh',czh:'\u5229\u96c5\u5f97',co:'Saudi Arabia',czho:'\u6c99\u7279\u963f\u62c9\u4f2f',fl:'\ud83c\uddf8\ud83c\udde6',dot:'dc-amber',dst:false,cc:'SA',kw:['saudi']},
  {tz:'Asia/Jerusalem',city:'Jerusalem',czh:'\u8036\u8def\u6492\u51b7',co:'Israel',czho:'\u4ee5\u8272\u5217',fl:'\ud83c\uddee\ud83c\uddf1',dot:'dc-sky',dst:true,cc:'IL',kw:['israel']},
  {tz:'Asia/Tehran',city:'Tehran',czh:'\u5fb7\u9ed1\u5170',co:'Iran',czho:'\u4f0a\u6717',fl:'\ud83c\uddee\ud83c\uddf7',dot:'dc-amber',dst:true,cc:'IR',kw:['iran']},
  {tz:'Asia/Baghdad',city:'Baghdad',czh:'\u5df4\u683c\u8fbe',co:'Iraq',czho:'\u4f0a\u62c9\u514b',fl:'\ud83c\uddee\ud83c\uddf6',dot:'dc-amber',dst:false,cc:'IQ',kw:['iraq']},
  {tz:'Asia/Kuwait',city:'Kuwait City',czh:'\u79d1\u5a01\u7279\u57ce',co:'Kuwait',czho:'\u79d1\u5a01\u7279',fl:'\ud83c\uddf0\ud83c\uddfc',dot:'dc-amber',dst:false,cc:'KW',kw:['kuwait']},
  {tz:'Asia/Qatar',city:'Doha',czh:'\u591a\u54c8',co:'Qatar',czho:'\u5361\u5854\u5c14',fl:'\ud83c\uddf6\ud83c\udde6',dot:'dc-amber',dst:false,cc:'QA',kw:['qatar']},
  {tz:'Asia/Muscat',city:'Muscat',czh:'\u9a6c\u65af\u5580\u7279',co:'Oman',czho:'\u963f\u66fc',fl:'\ud83c\uddf4\ud83c\uddf2',dot:'dc-amber',dst:false,cc:'OM',kw:['oman']},
  {tz:'Asia/Beirut',city:'Beirut',czh:'\u8d1d\u9c81\u7279',co:'Lebanon',czho:'\u9ece\u5df4\u5ae9',fl:'\ud83c\uddf1\ud83c\udde7',dot:'dc-rose',dst:true,cc:'LB',kw:['lebanon']},
  {tz:'Asia/Baku',city:'Baku',czh:'\u5df4\u5e93',co:'Azerbaijan',czho:'\u963f\u585e\u62dc\u7586',fl:'\ud83c\udde6\ud83c\uddff',dot:'dc-teal',dst:false,cc:'AZ',kw:['azerbaijan']},
  {tz:'Asia/Yerevan',city:'Yerevan',czh:'\u57c3\u91cc\u6e29',co:'Armenia',czho:'\u4e9a\u7f8e\u5c3c\u4e9a',fl:'\ud83c\udde6\ud83c\uddf2',dot:'dc-rose',dst:false,cc:'AM',kw:['armenia']},
  {tz:'Asia/Tbilisi',city:'Tbilisi',czh:'\u7b2c\u6bd4\u5229\u65af',co:'Georgia',czho:'\u683c\u9c81\u5409\u4e9a',fl:'\ud83c\uddec\ud83c\uddea',dot:'dc-amber',dst:false,cc:'GE',kw:['georgia']},
  {tz:'Asia/Vladivostok',city:'Vladivostok',czh:'\u6d77\u53c2\u5d34',co:'Russia FE',czho:'\u4fe3\u7f57\u65af\u8fdc\u4e1c',fl:'\ud83c\uddf7\ud83c\uddfa',dot:'dc-purple',dst:false,cc:'RU',kw:['vladivostok']},
  {tz:'Asia/Novosibirsk',city:'Novosibirsk',czh:'\u65b0\u897f\u4f2f\u5229\u4e9a',co:'Russia Sib',czho:'\u4fe3\u7f57\u65af\u897f\u4f2f\u5229\u4e9a',fl:'\ud83c\uddf7\ud83c\uddfa',dot:'dc-purple',dst:false,cc:'RU',kw:['novosibirsk']},
  {tz:'Europe/London',city:'London',czh:'\u4f26\u6566',co:'UK',czho:'\u82f1\u56fd',fl:'\ud83c\uddec\ud83c\udde7',dot:'dc-sky',dst:true,cc:'GB',kw:['uk','\u82f1\u56fd']},
  {tz:'Europe/Dublin',city:'Dublin',czh:'\u90fd\u67cf\u6797',co:'Ireland',czho:'\u7231\u5c14\u5170',fl:'\ud83c\uddee\ud83c\uddea',dot:'dc-green',dst:true,cc:'IE',kw:['ireland']},
  {tz:'Europe/Paris',city:'Paris',czh:'\u5df4\u9ece',co:'France',czho:'\u6cd5\u56fd',fl:'\ud83c\uddeb\ud83c\uddf7',dot:'dc-purple',dst:true,cc:'FR',kw:['france','\u6cd5\u56fd']},
  {tz:'Europe/Berlin',city:'Berlin',czh:'\u67cf\u6797',co:'Germany',czho:'\u5fb7\u56fd',fl:'\ud83c\udde9\ud83c\uddea',dot:'dc-amber',dst:true,cc:'DE',kw:['germany','\u5fb7\u56fd']},
  {tz:'Europe/Madrid',city:'Madrid',czh:'\u9a6c\u5fb7\u91cc',co:'Spain',czho:'\u897f\u73ed\u7259',fl:'\ud83c\uddea\ud83c\uddf8',dot:'dc-rose',dst:true,cc:'ES',kw:['spain']},
  {tz:'Europe/Lisbon',city:'Lisbon',czh:'\u91cc\u65af\u672c',co:'Portugal',czho:'\u8461\u8404\u7259',fl:'\ud83c\uddf5\ud83c\uddf9',dot:'dc-lime',dst:true,cc:'PT',kw:['portugal']},
  {tz:'Europe/Amsterdam',city:'Amsterdam',czh:'\u963f\u59c6\u65af\u7279\u4e39',co:'Netherlands',czho:'\u8377\u5170',fl:'\ud83c\uddf3\ud83c\uddf1',dot:'dc-orange',dst:true,cc:'NL',kw:['netherlands']},
  {tz:'Europe/Brussels',city:'Brussels',czh:'\u5e03\u9c81\u585e\u5c14',co:'Belgium',czho:'\u6bd4\u5229\u65f6',fl:'\ud83c\udde7\ud83c\uddea',dot:'dc-amber',dst:true,cc:'BE',kw:['belgium']},
  {tz:'Europe/Vienna',city:'Vienna',czh:'\u7ef4\u4e5f\u7eb3',co:'Austria',czho:'\u5965\u5730\u5229',fl:'\ud83c\udde6\ud83c\uddf9',dot:'dc-rose',dst:true,cc:'AT',kw:['austria']},
  {tz:'Europe/Rome',city:'Rome',czh:'\u7f57\u9a6c',co:'Italy',czho:'\u610f\u5927\u5229',fl:'\ud83c\uddee\ud83c\uddf9',dot:'dc-rose',dst:true,cc:'IT',kw:['italy']},
  {tz:'Europe/Athens',city:'Athens',czh:'\u96c5\u5178',co:'Greece',czho:'\u5e0c\u814a',fl:'\ud83c\uddec\ud83c\uddf7',dot:'dc-sky',dst:true,cc:'GR',kw:['greece']},
  {tz:'Europe/Stockholm',city:'Stockholm',czh:'\u65af\u5fb7\u54e5\u5c14\u6469',co:'Sweden',czho:'\u745e\u5178',fl:'\ud83c\uddf8\ud83c\uddea',dot:'dc-sky',dst:true,cc:'SE',kw:['sweden']},
  {tz:'Europe/Oslo',city:'Oslo',czh:'\u5965\u65af\u9646',co:'Norway',czho:'\u632a\u5a01',fl:'\ud83c\uddf3\ud83c\uddf4',dot:'dc-sky',dst:true,cc:'NO',kw:['norway']},
  {tz:'Europe/Copenhagen',city:'Copenhagen',czh:'\u54e5\u672c\u54c8\u6839',co:'Denmark',czho:'\u4e39\u9ea6',fl:'\ud83c\udde9\ud83c\uddf0',dot:'dc-rose',dst:true,cc:'DK',kw:['denmark']},
  {tz:'Europe/Helsinki',city:'Helsinki',czh:'\u8d6b\u5c14\u8f9b\u57fa',co:'Finland',czho:'\u82ac\u5170',fl:'\ud83c\uddeb\ud83c\uddee',dot:'dc-sky',dst:true,cc:'FI',kw:['finland']},
  {tz:'Europe/Zurich',city:'Zurich',czh:'\u82cf\u9ece\u4e16',co:'Switzerland',czho:'\u745e\u58eb',fl:'\ud83c\udde8\ud83c\udded',dot:'dc-green',dst:true,cc:'CH',kw:['switzerland']},
  {tz:'Europe/Warsaw',city:'Warsaw',czh:'\u534e\u6c99',co:'Poland',czho:'\u6ce2\u5170',fl:'\ud83c\uddf5\ud83c\uddf1',dot:'dc-rose',dst:true,cc:'PL',kw:['poland']},
  {tz:'Europe/Prague',city:'Prague',czh:'\u5e03\u62c9\u683c',co:'Czech Rep.',czho:'\u6377\u514b',fl:'\ud83c\udde8\ud83c\uddff',dot:'dc-sky',dst:true,cc:'CZ',kw:['czech']},
  {tz:'Europe/Budapest',city:'Budapest',czh:'\u5e03\u8fbe\u4f69\u65af\u5f53',co:'Hungary',czho:'\u5308\u7259\u5229',fl:'\ud83c\udded\ud83c\uddfa',dot:'dc-rose',dst:true,cc:'HU',kw:['hungary']},
  {tz:'Europe/Bucharest',city:'Bucharest',czh:'\u5e03\u52a0\u52d2\u65af\u7279',co:'Romania',czho:'\u7f57\u9a6c\u5c3c\u4e9a',fl:'\ud83c\uddf7\ud83c\uddf4',dot:'dc-amber',dst:true,cc:'RO',kw:['romania']},
  {tz:'Europe/Moscow',city:'Moscow',czh:'\u83ab\u65af\u79d1',co:'Russia',czho:'\u4fe3\u7f57\u65af',fl:'\ud83c\uddf7\ud83c\uddfa',dot:'dc-purple',dst:false,cc:'RU',kw:['russia']},
  {tz:'Europe/Kyiv',city:'Kyiv',czh:'\u57fa\u8f85',co:'Ukraine',czho:'\u4e4c\u514b\u5170',fl:'\ud83c\uddfa\ud83c\udde6',dot:'dc-sky',dst:true,cc:'UA',kw:['ukraine']},
  {tz:'Europe/Istanbul',city:'Istanbul',czh:'\u4f0a\u65af\u5766\u5e03\u5c14',co:'Turkey',czho:'\u571f\u8033\u5176',fl:'\ud83c\uddf9\ud83c\uddf7',dot:'dc-amber',dst:false,cc:'TR',kw:['turkey']},
  {tz:'Atlantic/Reykjavik',city:'Reykjavik',czh:'\u96f7\u514b\u96c5\u672a\u514b',co:'Iceland',czho:'\u51b0\u5c9b',fl:'\ud83c\uddee\ud83c\uddf8',dot:'dc-sky',dst:false,cc:'IS',kw:['iceland']},
  {tz:'Europe/Belgrade',city:'Belgrade',czh:'\u8d1d\u5c14\u683c\u83b1\u5fb7',co:'Serbia',czho:'\u585e\u5c14\u7ef4\u4e9a',fl:'\ud83c\uddf7\ud83c\uddf8',dot:'dc-rose',dst:true,cc:'RS',kw:['serbia']},
  {tz:'Europe/Sofia',city:'Sofia',czh:'\u7d22\u83f2\u4e9a',co:'Bulgaria',czho:'\u4fdd\u52a0\u5229\u4e9a',fl:'\ud83c\udde7\ud83c\uddec',dot:'dc-sky',dst:true,cc:'BG',kw:['bulgaria']},
  {tz:'Europe/Tallinn',city:'Tallinn',czh:'\u5854\u6797',co:'Estonia',czho:'\u7231\u6c99\u5c3c\u4e9a',fl:'\ud83c\uddea\ud83c\uddea',dot:'dc-sky',dst:true,cc:'EE',kw:['estonia']},
  {tz:'Europe/Riga',city:'Riga',czh:'\u91cc\u52a0',co:'Latvia',czho:'\u62c9\u6258\u7ef4\u4e9a',fl:'\ud83c\uddf1\ud83c\uddfb',dot:'dc-rose',dst:true,cc:'LV',kw:['latvia']},
  {tz:'Europe/Vilnius',city:'Vilnius',czh:'\u7ef4\u5c14\u7ebd\u65af',co:'Lithuania',czho:'\u7acb\u9676\u5b9b',fl:'\ud83c\uddf1\ud83c\uddf9',dot:'dc-green',dst:true,cc:'LT',kw:['lithuania']},
  {tz:'Europe/Minsk',city:'Minsk',czh:'\u660e\u65af\u514b',co:'Belarus',czho:'\u767d\u4fe3\u7f57\u65af',fl:'\ud83c\udde7\ud83c\uddfe',dot:'dc-green',dst:false,cc:'BY',kw:['belarus']},
  {tz:'Africa/Cairo',city:'Cairo',czh:'\u5f00\u7f57',co:'Egypt',czho:'\u57c3\u53ca',fl:'\ud83c\uddea\ud83c\uddec',dot:'dc-amber',dst:false,cc:'EG',kw:['egypt']},
  {tz:'Africa/Johannesburg',city:'Johannesburg',czh:'\u7ea6\u7ff0\u5185\u65af\u5821',co:'South Africa',czho:'\u5357\u975e',fl:'\ud83c\uddff\ud83c\udde6',dot:'dc-teal',dst:false,cc:'ZA',kw:['south africa']},
  {tz:'Africa/Lagos',city:'Lagos',czh:'\u62c9\u5404\u65af',co:'Nigeria',czho:'\u5c3c\u65e5\u5229\u4e9a',fl:'\ud83c\uddf3\ud83c\uddec',dot:'dc-amber',dst:false,cc:'NG',kw:['nigeria']},
  {tz:'Africa/Nairobi',city:'Nairobi',czh:'\u5185\u7f57\u6bd5',co:'Kenya',czho:'\u8089\u5c3c\u4e9a',fl:'\ud83c\uddf0\ud83c\uddea',dot:'dc-teal',dst:false,cc:'KE',kw:['kenya']},
  {tz:'Africa/Casablanca',city:'Casablanca',czh:'\u5361\u8428\u5e03\u5170\u5361',co:'Morocco',czho:'\u6469\u6d1b\u54e5',fl:'\ud83c\uddf2\ud83c\udde6',dot:'dc-amber',dst:true,cc:'MA',kw:['morocco']},
  {tz:'Africa/Accra',city:'Accra',czh:'\u963f\u514b\u62c9',co:'Ghana',czho:'\u52a0\u7eb3',fl:'\ud83c\uddec\ud83c\udded',dot:'dc-lime',dst:false,cc:'GH',kw:['ghana']},
  {tz:'Africa/Addis_Ababa',city:'Addis Ababa',czh:'\u4e9a\u7684\u65af\u4e9a\u8d1d\u5df4',co:'Ethiopia',czho:'\u57c3\u585e\u4fc4\u6bd4\u4e9a',fl:'\ud83c\uddea\ud83c\uddf9',dot:'dc-amber',dst:false,cc:'ET',kw:['ethiopia']},
  {tz:'Africa/Dar_es_Salaam',city:'Dar es Salaam',czh:'\u8fbe\u7d2f\u65af\u8428\u62c9\u59c6',co:'Tanzania',czho:'\u5766\u6851\u5c3c\u4e9a',fl:'\ud83c\uddf9\ud83c\uddff',dot:'dc-teal',dst:false,cc:'TZ',kw:['tanzania']},
  {tz:'Africa/Algiers',city:'Algiers',czh:'\u963f\u5c14\u53ca\u5c14',co:'Algeria',czho:'\u963f\u5c14\u53ca\u5229\u4e9a',fl:'\ud83c\udde9\ud83c\uddff',dot:'dc-amber',dst:false,cc:'DZ',kw:['algeria']},
  {tz:'Indian/Mauritius',city:'Port Louis',czh:'\u8def\u6613\u6e2f',co:'Mauritius',czho:'\u6bdb\u91cc\u6c42\u65af',fl:'\ud83c\uddf2\ud83c\uddfa',dot:'dc-teal',dst:false,cc:'MU',kw:['mauritius']},
  {tz:'America/New_York',city:'New York',czh:'\u7ebd\u7ea6',co:'USA East',czho:'\u7f8e\u56fd\u4e1c\u90e8',fl:'\ud83c\uddfa\ud83c\uddf8',dot:'dc-sky',dst:true,cc:'US',kw:['usa','\u7f8e\u56fd','eastern']},
  {tz:'America/Chicago',city:'Chicago',czh:'\u829d\u52a0\u54e5',co:'USA Central',czho:'\u7f8e\u56fd\u4e2d\u90e8',fl:'\ud83c\uddfa\ud83c\uddf8',dot:'dc-sky',dst:true,cc:'US',kw:['usa','\u7f8e\u56fd','central']},
  {tz:'America/Denver',city:'Denver',czh:'\u4e39\u4f5b',co:'USA Mountain',czho:'\u7f8e\u56fd\u5c71\u5730',fl:'\ud83c\uddfa\ud83c\uddf8',dot:'dc-sky',dst:true,cc:'US',kw:['usa','\u7f8e\u56fd','mountain']},
  {tz:'America/Los_Angeles',city:'Los Angeles',czh:'\u6d1b\u6749\u77f6',co:'USA West',czho:'\u7f8e\u56fd\u897f\u90e8',fl:'\ud83c\uddfa\ud83c\uddf8',dot:'dc-sky',dst:true,cc:'US',kw:['usa','\u7f8e\u56fd','pacific','la']},
  {tz:'America/Anchorage',city:'Anchorage',czh:'\u5b89\u514b\u96f7\u5947',co:'USA Alaska',czho:'\u7f8e\u56fd\u963f\u62c9\u65af\u52a0',fl:'\ud83c\uddfa\ud83c\uddf8',dot:'dc-sky',dst:true,cc:'US',kw:['alaska']},
  {tz:'America/Phoenix',city:'Phoenix',czh:'\u83f2\u5c3c\u514b\u65af',co:'USA Arizona',czho:'\u7f8e\u56fd\u4e9a\u5229\u6851\u90a3',fl:'\ud83c\uddfa\ud83c\uddf8',dot:'dc-sky',dst:false,cc:'US',kw:['arizona']},
  {tz:'America/Toronto',city:'Toronto',czh:'\u591a\u4f26\u591a',co:'Canada',czho:'\u52a0\u62ff\u5927',fl:'\ud83c\udde8\ud83c\udde6',dot:'dc-green',dst:true,cc:'CA',kw:['canada']},
  {tz:'America/Vancouver',city:'Vancouver',czh:'\u6e29\u54e5\u534e',co:'Canada W',czho:'\u52a0\u62ff\u5927\u897f\u90e8',fl:'\ud83c\udde8\ud83c\udde6',dot:'dc-green',dst:true,cc:'CA',kw:['canada']},
  {tz:'America/Sao_Paulo',city:'Sao Paulo',czh:'\u5723\u4fdd\u7f57',co:'Brazil',czho:'\u5df4\u897f',fl:'\ud83c\udde7\ud83c\uddf7',dot:'dc-green',dst:false,cc:'BR',kw:['brazil']},
  {tz:'America/Argentina/Buenos_Aires',city:'Buenos Aires',czh:'\u5e03\u5b9c\u8bfa\u65af\u827e\u5229\u65af',co:'Argentina',czho:'\u963f\u6839\u5ef7',fl:'\ud83c\udde6\ud83c\uddf7',dot:'dc-sky',dst:false,cc:'AR',kw:['argentina']},
  {tz:'America/Santiago',city:'Santiago',czh:'\u5723\u5730\u4e9a\u54e5',co:'Chile',czho:'\u667a\u5229',fl:'\ud83c\udde8\ud83c\uddf1',dot:'dc-sky',dst:true,cc:'CL',kw:['chile']},
  {tz:'America/Bogota',city:'Bogota',czh:'\u6ce2\u54e5\u5927',co:'Colombia',czho:'\u54e5\u4f26\u6bd4\u4e9a',fl:'\ud83c\udde8\ud83c\uddf4',dot:'dc-amber',dst:false,cc:'CO',kw:['colombia']},
  {tz:'America/Lima',city:'Lima',czh:'\u5229\u9a6c',co:'Peru',czho:'\u79d8\u9c81',fl:'\ud83c\uddf5\ud83c\uddea',dot:'dc-amber',dst:false,cc:'PE',kw:['peru']},
  {tz:'America/Caracas',city:'Caracas',czh:'\u52a0\u62c9\u52a0\u65af',co:'Venezuela',czho:'\u59d4\u5185\u745e\u62c9',fl:'\ud83c\uddfb\ud83c\uddea',dot:'dc-amber',dst:false,cc:'VE',kw:['venezuela']},
  {tz:'America/Mexico_City',city:'Mexico City',czh:'\u58a8\u897f\u54e5\u57ce',co:'Mexico',czho:'\u58a8\u897f\u54e5',fl:'\ud83c\uddf2\ud83c\uddfd',dot:'dc-teal',dst:true,cc:'MX',kw:['mexico']},
  {tz:'America/Panama',city:'Panama City',czh:'\u5df4\u62ff\u9a6c\u57ce',co:'Panama',czho:'\u5df4\u62ff\u9a6c',fl:'\ud83c\uddf5\ud83c\udde6',dot:'dc-teal',dst:false,cc:'PA',kw:['panama']},
  {tz:'America/Montevideo',city:'Montevideo',czh:'\u8499\u5f97\u7ef4\u7684\u4e9a',co:'Uruguay',czho:'\u4e4c\u62c9\u572d',fl:'\ud83c\uddfa\ud83c\uddfe',dot:'dc-sky',dst:false,cc:'UY',kw:['uruguay']},
{tz:'Africa/Abidjan',city:'Abidjan',czh:'阿比让',co:'C\u00f4te d\u2019Ivoire',czho:'科特迪瓦',fl:'🇨🇮',dot:'dc-purple',dst:false,cc:'CI',kw:['cote divoire']},
  {tz:'Africa/Maputo',city:'Maputo',czh:'马普托',co:'Mozambique',czho:'莫桑比克',fl:'🇲🇿',dot:'dc-sky',dst:false,cc:'MZ',kw:['mozambique']},
  {tz:'Africa/Douala',city:'Douala',czh:'杜阿拉',co:'Cameroon',czho:'喀麦隆',fl:'🇨🇲',dot:'dc-rose',dst:false,cc:'CM',kw:['cameroon']},
  {tz:'Africa/Dakar',city:'Dakar',czh:'达喀尔',co:'Senegal',czho:'塞内加尔',fl:'🇸🇳',dot:'dc-amber',dst:false,cc:'SN',kw:['senegal']},
  {tz:'Africa/Tunis',city:'Tunis',czh:'突尼斯城',co:'Tunisia',czho:'突尼斯',fl:'🇹🇳',dot:'dc-teal',dst:false,cc:'TN',kw:['tunisia']},
  {tz:'Africa/Kampala',city:'Kampala',czh:'坎帕拉',co:'Uganda',czho:'乌干达',fl:'🇺🇬',dot:'dc-green',dst:false,cc:'UG',kw:['uganda']},
  {tz:'Africa/Lusaka',city:'Lusaka',czh:'卢萨卡',co:'Zambia',czho:'赞比亚',fl:'🇿🇲',dot:'dc-orange',dst:false,cc:'ZM',kw:['zambia']},
  {tz:'Africa/Harare',city:'Harare',czh:'哈拉雷',co:'Zimbabwe',czho:'津巴布韦',fl:'🇿🇼',dot:'dc-lime',dst:false,cc:'ZW',kw:['zimbabwe']},
  {tz:'Africa/Luanda',city:'Luanda',czh:'罗安达',co:'Angola',czho:'安哥拉',fl:'🇦🇴',dot:'dc-pink',dst:false,cc:'AO',kw:['angola']},
  {tz:'Africa/Kinshasa',city:'Kinshasa',czh:'金沙萨',co:'DR Congo',czho:'刚果（金）',fl:'🇨🇩',dot:'dc-indigo',dst:false,cc:'CD',kw:['dr congo']},
  {tz:'Africa/Brazzaville',city:'Brazzaville',czh:'布拉柴维尔',co:'Congo',czho:'刚果（布）',fl:'🇨🇬',dot:'dc-purple',dst:false,cc:'CG',kw:['congo']},
  {tz:'Africa/Khartoum',city:'Khartoum',czh:'喀土穆',co:'Sudan',czho:'苏丹',fl:'🇸🇩',dot:'dc-sky',dst:false,cc:'SD',kw:['sudan']},
  {tz:'Africa/Tripoli',city:'Tripoli',czh:'的黎波里',co:'Libya',czho:'利比亚',fl:'🇱🇾',dot:'dc-rose',dst:false,cc:'LY',kw:['libya']},
  {tz:'Africa/Kigali',city:'Kigali',czh:'基加利',co:'Rwanda',czho:'卢旺达',fl:'🇷🇼',dot:'dc-amber',dst:false,cc:'RW',kw:['rwanda']},
  {tz:'Africa/Bamako',city:'Bamako',czh:'巴马科',co:'Mali',czho:'马里',fl:'🇲🇱',dot:'dc-teal',dst:false,cc:'ML',kw:['mali']},
  {tz:'Africa/Windhoek',city:'Windhoek',czh:'温得和克',co:'Namibia',czho:'纳米比亚',fl:'🇳🇦',dot:'dc-green',dst:false,cc:'NA',kw:['namibia']},
  {tz:'Africa/Gaborone',city:'Gaborone',czh:'哈博罗内',co:'Botswana',czho:'博茨瓦纳',fl:'🇧🇼',dot:'dc-orange',dst:false,cc:'BW',kw:['botswana']},
  {tz:'Africa/Mogadishu',city:'Mogadishu',czh:'摩加迪沙',co:'Somalia',czho:'索马里',fl:'🇸🇴',dot:'dc-lime',dst:false,cc:'SO',kw:['somalia']},
  {tz:'Indian/Antananarivo',city:'Antananarivo',czh:'塔那那利佛',co:'Madagascar',czho:'马达加斯加',fl:'🇲🇬',dot:'dc-sky',dst:false,cc:'MG',kw:['madagascar']},
  {tz:'Africa/Freetown',city:'Freetown',czh:'弗里敦',co:'Sierra Leone',czho:'塞拉利昂',fl:'🇸🇱',dot:'dc-rose',dst:false,cc:'SL',kw:['sierra leone']},
  {tz:'Africa/Monrovia',city:'Monrovia',czh:'蒙罗维亚',co:'Liberia',czho:'利比里亚',fl:'🇱🇷',dot:'dc-amber',dst:false,cc:'LR',kw:['liberia']},
  {tz:'Africa/Ouagadougou',city:'Ouagadougou',czh:'瓦加杜古',co:'Burkina Faso',czho:'布基纳法索',fl:'🇧🇫',dot:'dc-teal',dst:false,cc:'BF',kw:['burkina faso']},
  {tz:'Africa/Niamey',city:'Niamey',czh:'尼亚美',co:'Niger',czho:'尼日尔',fl:'🇳🇪',dot:'dc-green',dst:false,cc:'NE',kw:['niger']},
  {tz:'Africa/Ndjamena',city:'N\u2019Djamena',czh:'恩贾梅纳',co:'Chad',czho:'乍得',fl:'🇹🇩',dot:'dc-orange',dst:false,cc:'TD',kw:['chad']},
  {tz:'Africa/Bujumbura',city:'Bujumbura',czh:'布琼布拉',co:'Burundi',czho:'布隆迪',fl:'🇧🇮',dot:'dc-lime',dst:false,cc:'BI',kw:['burundi']},
  {tz:'Africa/Lome',city:'Lome',czh:'洛美',co:'Togo',czho:'多哥',fl:'🇹🇬',dot:'dc-pink',dst:false,cc:'TG',kw:['togo']},
  {tz:'Africa/Porto-Novo',city:'Porto-Novo',czh:'波多诺伏',co:'Benin',czho:'贝宁',fl:'🇧🇯',dot:'dc-indigo',dst:false,cc:'BJ',kw:['benin']},
  {tz:'Africa/Malabo',city:'Malabo',czh:'马拉博',co:'Equatorial Guinea',czho:'赤道几内亚',fl:'🇬🇶',dot:'dc-purple',dst:false,cc:'GQ',kw:['equatorial guinea']},
  {tz:'Africa/Libreville',city:'Libreville',czh:'利伯维尔',co:'Gabon',czho:'加蓬',fl:'🇬🇦',dot:'dc-sky',dst:false,cc:'GA',kw:['gabon']},
  {tz:'Africa/Asmara',city:'Asmara',czh:'阿斯马拉',co:'Eritrea',czho:'厄立特里亚',fl:'🇪🇷',dot:'dc-rose',dst:false,cc:'ER',kw:['eritrea']},
  {tz:'Africa/Djibouti',city:'Djibouti',czh:'吉布提市',co:'Djibouti',czho:'吉布提',fl:'🇩🇯',dot:'dc-amber',dst:false,cc:'DJ',kw:['djibouti']},
  {tz:'Africa/Bissau',city:'Bissau',czh:'比绍',co:'Guinea-Bissau',czho:'几内亚比绍',fl:'🇬🇼',dot:'dc-teal',dst:false,cc:'GW',kw:['guinea-bissau']},
  {tz:'Africa/Conakry',city:'Conakry',czh:'科纳克里',co:'Guinea',czho:'几内亚',fl:'🇬🇳',dot:'dc-green',dst:false,cc:'GN',kw:['guinea']},
  {tz:'Africa/Nouakchott',city:'Nouakchott',czh:'努瓦克肖特',co:'Mauritania',czho:'毛里塔尼亚',fl:'🇲🇷',dot:'dc-orange',dst:false,cc:'MR',kw:['mauritania']},
  {tz:'Africa/Maseru',city:'Maseru',czh:'马塞卢',co:'Lesotho',czho:'莱索托',fl:'🇱🇸',dot:'dc-lime',dst:false,cc:'LS',kw:['lesotho']},
  {tz:'Africa/Mbabane',city:'Mbabane',czh:'姆巴巴内',co:'Eswatini',czho:'斯威士兰',fl:'🇸🇿',dot:'dc-pink',dst:false,cc:'SZ',kw:['eswatini']},
  {tz:'America/Costa_Rica',city:'San Jose',czh:'圣何塞',co:'Costa Rica',czho:'哥斯达黎加',fl:'🇨🇷',dot:'dc-indigo',dst:false,cc:'CR',kw:['costa rica']},
  {tz:'America/Havana',city:'Havana',czh:'哈瓦那',co:'Cuba',czho:'古巴',fl:'🇨🇺',dot:'dc-purple',dst:true,cc:'CU',kw:['cuba']},
  {tz:'America/Santo_Domingo',city:'Santo Domingo',czh:'圣多明各',co:'Dominican Rep.',czho:'多米尼加',fl:'🇩🇴',dot:'dc-sky',dst:false,cc:'DO',kw:['dominican rep.']},
  {tz:'America/Guatemala',city:'Guatemala City',czh:'危地马拉城',co:'Guatemala',czho:'危地马拉',fl:'🇬🇹',dot:'dc-rose',dst:false,cc:'GT',kw:['guatemala']},
  {tz:'America/Tegucigalpa',city:'Tegucigalpa',czh:'特古西加尔巴',co:'Honduras',czho:'洪都拉斯',fl:'🇭🇳',dot:'dc-amber',dst:false,cc:'HN',kw:['honduras']},
  {tz:'America/Jamaica',city:'Kingston',czh:'金斯敦',co:'Jamaica',czho:'牙买加',fl:'🇯🇲',dot:'dc-teal',dst:false,cc:'JM',kw:['jamaica']},
  {tz:'America/Managua',city:'Managua',czh:'马那瓜',co:'Nicaragua',czho:'尼加拉瓜',fl:'🇳🇮',dot:'dc-green',dst:false,cc:'NI',kw:['nicaragua']},
  {tz:'America/El_Salvador',city:'San Salvador',czh:'圣萨尔瓦多',co:'El Salvador',czho:'萨尔瓦多',fl:'🇸🇻',dot:'dc-orange',dst:false,cc:'SV',kw:['el salvador']},
  {tz:'America/Nassau',city:'Nassau',czh:'拿骚',co:'Bahamas',czho:'巴哈马',fl:'🇧🇸',dot:'dc-lime',dst:true,cc:'BS',kw:['bahamas']},
  {tz:'America/Port_of_Spain',city:'Port of Spain',czh:'西班牙港',co:'Trinidad & Tobago',czho:'特立尼达和多巴哥',fl:'🇹🇹',dot:'dc-pink',dst:false,cc:'TT',kw:['trinidad&tobago']},
  {tz:'America/Belize',city:'Belize City',czh:'伯利兹城',co:'Belize',czho:'伯利兹',fl:'🇧🇿',dot:'dc-indigo',dst:false,cc:'BZ',kw:['belize']},
  {tz:'America/Port-au-Prince',city:'Port-au-Prince',czh:'太子港',co:'Haiti',czho:'海地',fl:'🇭🇹',dot:'dc-purple',dst:true,cc:'HT',kw:['haiti']},
  {tz:'America/La_Paz',city:'La Paz',czh:'拉巴斯',co:'Bolivia',czho:'玻利维亚',fl:'🇧🇴',dot:'dc-sky',dst:false,cc:'BO',kw:['bolivia']},
  {tz:'America/Guayaquil',city:'Guayaquil',czh:'瓜亚基尔',co:'Ecuador',czho:'厄瓜多尔',fl:'🇪🇨',dot:'dc-rose',dst:false,cc:'EC',kw:['ecuador']},
  {tz:'America/Asuncion',city:'Asuncion',czh:'亚松森',co:'Paraguay',czho:'巴拉圭',fl:'🇵🇾',dot:'dc-amber',dst:true,cc:'PY',kw:['paraguay']},
  {tz:'America/Guyana',city:'Georgetown',czh:'乔治敦',co:'Guyana',czho:'圭亚那',fl:'🇬🇾',dot:'dc-teal',dst:false,cc:'GY',kw:['guyana']},
  {tz:'America/Paramaribo',city:'Paramaribo',czh:'帕拉马里博',co:'Suriname',czho:'苏里南',fl:'🇸🇷',dot:'dc-green',dst:false,cc:'SR',kw:['suriname']},
  {tz:'Asia/Amman',city:'Amman',czh:'安曼',co:'Jordan',czho:'约旦',fl:'🇯🇴',dot:'dc-orange',dst:false,cc:'JO',kw:['jordan']},
  {tz:'Asia/Damascus',city:'Damascus',czh:'大马士革',co:'Syria',czho:'叙利亚',fl:'🇸🇾',dot:'dc-lime',dst:false,cc:'SY',kw:['syria']},
  {tz:'Asia/Aden',city:'Aden',czh:'亚丁',co:'Yemen',czho:'也门',fl:'🇾🇪',dot:'dc-pink',dst:false,cc:'YE',kw:['yemen']},
  {tz:'Asia/Bahrain',city:'Manama',czh:'麦纳麦',co:'Bahrain',czho:'巴林',fl:'🇧🇭',dot:'dc-indigo',dst:false,cc:'BH',kw:['bahrain']},
  {tz:'Asia/Nicosia',city:'Nicosia',czh:'尼科西亚',co:'Cyprus',czho:'塞浦路斯',fl:'🇨🇾',dot:'dc-purple',dst:true,cc:'CY',kw:['cyprus']},
  {tz:'Asia/Kabul',city:'Kabul',czh:'喀布尔',co:'Afghanistan',czho:'阿富汗',fl:'🇦🇫',dot:'dc-sky',dst:false,cc:'AF',kw:['afghanistan']},
  {tz:'Asia/Tashkent',city:'Tashkent',czh:'塔什干',co:'Uzbekistan',czho:'乌兹别克斯坦',fl:'🇺🇿',dot:'dc-rose',dst:false,cc:'UZ',kw:['uzbekistan']},
  {tz:'Asia/Ashgabat',city:'Ashgabat',czh:'阿什哈巴德',co:'Turkmenistan',czho:'土库曼斯坦',fl:'🇹🇲',dot:'dc-amber',dst:false,cc:'TM',kw:['turkmenistan']},
  {tz:'Asia/Bishkek',city:'Bishkek',czh:'比什凯克',co:'Kyrgyzstan',czho:'吉尔吉斯斯坦',fl:'🇰🇬',dot:'dc-teal',dst:false,cc:'KG',kw:['kyrgyzstan']},
  {tz:'Asia/Dushanbe',city:'Dushanbe',czh:'杜尚别',co:'Tajikistan',czho:'塔吉克斯坦',fl:'🇹🇯',dot:'dc-green',dst:false,cc:'TJ',kw:['tajikistan']},
  {tz:'Asia/Thimphu',city:'Thimphu',czh:'廷布',co:'Bhutan',czho:'不丹',fl:'🇧🇹',dot:'dc-orange',dst:false,cc:'BT',kw:['bhutan']},
  {tz:'Asia/Vientiane',city:'Vientiane',czh:'万象',co:'Laos',czho:'老挝',fl:'🇱🇦',dot:'dc-lime',dst:false,cc:'LA',kw:['laos']},
  {tz:'Asia/Brunei',city:'Bandar Seri Begawan',czh:'斯里巴加湾市',co:'Brunei',czho:'文莱',fl:'🇧🇳',dot:'dc-pink',dst:false,cc:'BN',kw:['brunei']},
  {tz:'Asia/Dili',city:'Dili',czh:'帝力',co:'Timor-Leste',czho:'东帝汶',fl:'🇹🇱',dot:'dc-indigo',dst:false,cc:'TL',kw:['timor-leste']},
  {tz:'Europe/Zagreb',city:'Zagreb',czh:'萨格勒布',co:'Croatia',czho:'克罗地亚',fl:'🇭🇷',dot:'dc-purple',dst:true,cc:'HR',kw:['croatia']},
  {tz:'Europe/Ljubljana',city:'Ljubljana',czh:'卢布尔雅那',co:'Slovenia',czho:'斯洛文尼亚',fl:'🇸🇮',dot:'dc-sky',dst:true,cc:'SI',kw:['slovenia']},
  {tz:'Europe/Bratislava',city:'Bratislava',czh:'布拉迪斯拉发',co:'Slovakia',czho:'斯洛伐克',fl:'🇸🇰',dot:'dc-rose',dst:true,cc:'SK',kw:['slovakia']},
  {tz:'Europe/Luxembourg',city:'Luxembourg',czh:'卢森堡市',co:'Luxembourg',czho:'卢森堡',fl:'🇱🇺',dot:'dc-amber',dst:true,cc:'LU',kw:['luxembourg']},
  {tz:'Europe/Malta',city:'Valletta',czh:'瓦莱塔',co:'Malta',czho:'马耳他',fl:'🇲🇹',dot:'dc-teal',dst:true,cc:'MT',kw:['malta']},
  {tz:'Europe/Sarajevo',city:'Sarajevo',czh:'萨拉热窝',co:'Bosnia',czho:'波黑',fl:'🇧🇦',dot:'dc-green',dst:true,cc:'BA',kw:['bosnia']},
  {tz:'Europe/Tirane',city:'Tirane',czh:'地拉那',co:'Albania',czho:'阿尔巴尼亚',fl:'🇦🇱',dot:'dc-orange',dst:true,cc:'AL',kw:['albania']},
  {tz:'Europe/Skopje',city:'Skopje',czh:'斯科普里',co:'N. Macedonia',czho:'北马其顿',fl:'🇲🇰',dot:'dc-lime',dst:true,cc:'MK',kw:['n. macedonia']},
  {tz:'Europe/Chisinau',city:'Chisinau',czh:'基希讷乌',co:'Moldova',czho:'摩尔多瓦',fl:'🇲🇩',dot:'dc-pink',dst:true,cc:'MD',kw:['moldova']},
  {tz:'Europe/Podgorica',city:'Podgorica',czh:'波德戈里察',co:'Montenegro',czho:'黑山',fl:'🇲🇪',dot:'dc-indigo',dst:true,cc:'ME',kw:['montenegro']},
  {tz:'Europe/Andorra',city:'Andorra la Vella',czh:'安道尔城',co:'Andorra',czho:'安道尔',fl:'🇦🇩',dot:'dc-purple',dst:true,cc:'AD',kw:['andorra']},
  {tz:'Europe/Monaco',city:'Monaco',czh:'摩纳哥',co:'Monaco',czho:'摩纳哥',fl:'🇲🇨',dot:'dc-sky',dst:true,cc:'MC',kw:['monaco']},
  {tz:'Pacific/Port_Moresby',city:'Port Moresby',czh:'莫尔兹比港',co:'Papua New Guinea',czho:'巴布亚新几内亚',fl:'🇵🇬',dot:'dc-rose',dst:false,cc:'PG',kw:['papua new guinea']},
  {tz:'Pacific/Guadalcanal',city:'Honiara',czh:'霍尼亚拉',co:'Solomon Islands',czho:'所罗门群岛',fl:'🇸🇧',dot:'dc-amber',dst:false,cc:'SB',kw:['solomon islands']},
  {tz:'Pacific/Efate',city:'Port Vila',czh:'维拉港',co:'Vanuatu',czho:'瓦努阿图',fl:'🇻🇺',dot:'dc-teal',dst:false,cc:'VU',kw:['vanuatu']},
  {tz:'Pacific/Noumea',city:'Noumea',czh:'努美阿',co:'New Caledonia',czho:'新喀里多尼亚',fl:'🇳🇨',dot:'dc-green',dst:false,cc:'NC',kw:['new caledonia']},
  {tz:'America/Nuuk',city:'Nuuk',czh:'努克',co:'Greenland',czho:'格陵兰',fl:'🇬🇱',dot:'dc-orange',dst:true,cc:'GL',kw:['greenland']},
  {tz:'UTC',city:'UTC',czh:'UTC',co:'UTC/GMT',czho:'\u534f\u8c03\u4e16\u754c\u65f6',fl:'\ud83c\udf10',dot:'dc-sky',dst:false,cc:'--',kw:['utc','gmt']},
];

var FONTS=[
  {id:'sys',name:'系统默认',zh:'跟随系统',stack:"-apple-system,BlinkMacSystemFont,'PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif"},
  {id:'serif',name:'衬线',zh:'阅读衬线',stack:"Georgia,'Songti SC','STSong','SimSun',serif"},
  {id:'mono',name:'等宽',zh:'数字等宽',stack:"'SF Mono',SFMono-Regular,Consolas,'Courier New',monospace"},
  {id:'round',name:'圆体',zh:'圆润亲和',stack:"'Yuanti SC','PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif"}
];
function fontStack(id){for(var i=0;i<FONTS.length;i++)if(FONTS[i].id===id)return FONTS[i].stack;return FONTS[0].stack;}
var SKINS=[
  {id:'default',name:'\u6781\u5149\u7d2b',en:'Aurora Purple',grad:'linear-gradient(135deg,#a78bfa,#38bdf8)',bg:'rgba(15,12,41,.9)'},
  {id:'aurora',name:'\u7fe0\u7eff\u6781\u5149',en:'Green Aurora',grad:'linear-gradient(135deg,#34d399,#fbbf24)',bg:'rgba(0,30,16,.9)'},
  {id:'rose',name:'\u73ab\u7470\u7c89',en:'Rose Pink',grad:'linear-gradient(135deg,#f472b6,#e879f9)',bg:'rgba(26,5,32,.9)'},
  {id:'ocean',name:'\u6df1\u6d77\u84dd',en:'Deep Ocean',grad:'linear-gradient(135deg,#0ea5e9,#818cf8)',bg:'rgba(0,27,46,.9)'},
  {id:'ember',name:'\u70c8\u7130\u6a59',en:'Ember Fire',grad:'linear-gradient(135deg,#f97316,#ef4444)',bg:'rgba(28,10,0,.9)'},
  {id:'starfield',name:'\u661f\u7a7a\u7070',en:'Starfield',grad:'linear-gradient(135deg,#a5b4fc,#7dd3fc)',bg:'rgba(5,10,24,.9)'},
  {id:'dst',name:'DST\u5e86\u5178',en:'DST Special',grad:'linear-gradient(135deg,#c084fc,#f0abfc)',bg:'rgba(10,0,26,.9)'},
];
var DOT_COLORS={'dc-purple':'#a78bfa','dc-sky':'#38bdf8','dc-rose':'#fb7185','dc-amber':'#fbbf24','dc-teal':'#2dd4bf','dc-green':'#86efac','dc-orange':'#fb923c','dc-lime':'#a3e635','dc-pink':'#f472b6','dc-indigo':'#818cf8','dc-blue':'#60a5fa','dc-violet':'#c084fc','dc-red':'#f87171','dc-yellow':'#facc15'};

var DS={lang:'zh',timeFmt:'12h',dateFmt:'short',cardFmt:'both',convFmt:'12h',showAlt:true,showSec:true,showUtcOffset:false,fontScale:100,skin:'default',font:'sys',fsMode:'clock',fsTimeFmt:'12h',fsDark:false,fsClockDark:false,fsShowDate:true,fsScale:100,primaryTz:'Australia/Melbourne',mainDark:false,rowStyle:'vivid',clockTzs:['Australia/Melbourne','Europe/Madrid','Europe/Belgrade','Asia/Seoul','America/Sao_Paulo','Europe/Athens','Europe/Rome','Europe/Vienna','Asia/Phnom_Penh','Europe/Amsterdam','America/New_York','Europe/Paris','Asia/Tokyo','Europe/Stockholm']};
var S={};for(var k in DS)S[k]=DS[k];S.clockTzs=DS.clockTzs.slice();
try{var sv=localStorage.getItem('sg36');if(sv){var p2=JSON.parse(sv);for(var k in p2)S[k]=p2[k];if(!S.clockTzs)S.clockTzs=DS.clockTzs.slice();}}catch(e){}
function save(){try{localStorage.setItem('sg36',JSON.stringify(S));}catch(e){}}
function tzObj(tz){for(var i=0;i<TZ_DB.length;i++)if(TZ_DB[i].tz===tz)return TZ_DB[i];return null;}
function getClocks(){var r=[];for(var i=0;i<S.clockTzs.length;i++){var o=tzObj(S.clockTzs[i]);if(o)r.push(o);}return r;}
function cName(c){return S.lang==='zh'?c.czh:c.city;}
function ctName(c){return S.lang==='zh'?c.czho:c.co;}
function pad(n){return n<10?'0'+n:''+n;}
function localD(tz){return new Date(new Date().toLocaleString('en-US',{timeZone:tz}));}

var I18N={
  en:{settings:'Settings',about:'Guide',convTitle:'TIME CONVERTER',convFrom:'FROM',convTime:'TIME',convBtn:'Convert',sPrimary:'Primary Clock',sTimefmt:'Time Format',sAltline:'Secondary Line',sAltlineLbl:'Show alternate format',sSec:'Seconds',sSecLbl:'Show seconds',sDatefmt:'Date Format',sCardfmt:'Card Format',sFontsize:'Font Size',sActive:'Active Cities',sAdd:'Add City',today:'Today',tomorrow:'Tomorrow',yesterday:'Yesterday',searchPh:'Search city or country...',noResult:'No results',diffSame:'same time',diffAhead:'ahead',diffBehind:'behind',hours:'h',mins:'m',dstSpring:'Primary clock springs forward!',dstFall:'Primary clock falls back!',dstToday:'DST Change Today',fsClk:'Clock',fsBlk:'Blocks'},
  zh:{settings:'\u8bbe\u7f6e',about:'\u8bf4\u660e',convTitle:'\u65f6\u95f4\u6362\u7b97',convFrom:'\u4ece',convTime:'\u65f6\u95f4',convBtn:'\u6362\u7b97',sPrimary:'\u4e3b\u65f6\u949f',sTimefmt:'\u65f6\u95f4\u683c\u5f0f',sAltline:'\u526f\u663e\u793a\u884c',sAltlineLbl:'\u663e\u793a\u53e6\u4e00\u79cd\u683c\u5f0f',sSec:'\u79d2\u6570',sSecLbl:'\u663e\u793a\u79d2',sDatefmt:'\u65e5\u671f\u683c\u5f0f',sCardfmt:'\u5361\u7247\u683c\u5f0f',sFontsize:'\u5b57\u4f53\u5927\u5c0f',sActive:'\u5df2\u6dfb\u52a0\u57ce\u5e02',sAdd:'\u6dfb\u52a0\u57ce\u5e02',today:'\u4eca\u5929',tomorrow:'\u660e\u5929',yesterday:'\u6628\u5929',searchPh:'\u641c\u7d22\u57ce\u5e02\u6216\u56fd\u5bb6\u2026',noResult:'\u65e0\u7ed3\u679c',diffSame:'\u76f8\u540c\u65f6\u95f4',diffAhead:'\u8d85\u524d',diffBehind:'\u843d\u540e',hours:'\u5c0f\u65f6',mins:'\u5206\u949f',dstSpring:'\u4eca\u5929\u4e3b\u65f6\u949f\u8fdb\u5165\u590f\u4ee4\u65f6\uff01',dstFall:'\u4eca\u5929\u4e3b\u65f6\u949f\u8fdb\u5165\u51ac\u4ee4\u65f6\uff01',dstToday:'\u4ee4\u65f6\u5207\u6362\u65e5',fsClk:'\u65f6\u949f\u6a21\u5f0f',fsBlk:'\u65f6\u95f4\u5757'}
};
function t(k){var lng=S.lang==='zh'?'zh':'en';return(I18N[lng]&&I18N[lng][k])?I18N[lng][k]:k;}

function fmt12(d,sec){var h=d.getHours(),m=d.getMinutes(),s=d.getSeconds(),ap=h>=12?'PM':'AM',h12=h%12||12;return sec?h12+':'+pad(m)+':'+pad(s)+' '+ap:h12+':'+pad(m)+' '+ap;}
function fmtUtcOffset(tz){var mins=getOffsetMin(tz);var sign=mins>=0?'+':'-';var abs=Math.abs(mins);var h=Math.floor(abs/60),m=abs%60;return 'UTC '+sign+h+(m?':'+pad(m):'');}
function fmt24(d,sec){var h=d.getHours(),m=d.getMinutes(),s=d.getSeconds();return sec?pad(h)+':'+pad(m)+':'+pad(s):pad(h)+':'+pad(m);}
function fmtPrimary(d){return S.timeFmt==='24h'?fmt24(d,S.showSec):fmt12(d,S.showSec);}
function fmtCard(d,cf){if(cf==='12h')return fmt12(d,false);if(cf==='24h')return fmt24(d,false);return fmt12(d,false)+' / '+fmt24(d,false);}
var DENS=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
var DZHS=['\u5468\u65e5','\u5468\u4e00','\u5468\u4e8c','\u5468\u4e09','\u5468\u56db','\u5468\u4e94','\u5468\u516d'];
var MS=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
var MF=['January','February','March','April','May','June','July','August','September','October','November','December'];
function getPeriod(d){
  var h=d.getHours()+d.getMinutes()/60;
  if(S.lang==='zh'){if(h<5)return'\u51cc\u6668';if(h<8)return'\u65e9\u4e0a';if(h<11.5)return'\u4e0a\u5348';if(h<13.5)return'\u4e2d\u5348';if(h<18)return'\u4e0b\u5348';if(h<22)return'\u665a\u4e0a';return'\u591c\u665a';}
  if(h<5)return'Night';if(h<11.5)return'Morning';if(h<13.5)return'Noon';if(h<18)return'Afternoon';if(h<22)return'Evening';return'Night';
}
function fmtDate(d,f){
  var dy=d.getDate(),mo=d.getMonth(),yr=d.getFullYear(),wd=d.getDay();
  if(f==='zh')return yr+'\u5e74'+(mo+1)+'\u6708'+dy+'\u65e5 '+DZHS[wd];
  if(f==='short')return(S.lang==='zh'?DZHS[wd]:DENS[wd])+', '+dy+' '+MS[mo]+' '+yr;
  if(f==='us')return MF[mo]+' '+dy+', '+yr;
  if(f==='iso')return yr+'-'+pad(mo+1)+'-'+pad(dy);
  if(f==='dmy')return pad(dy)+'/'+pad(mo+1)+'/'+yr;
  if(f==='mdy')return pad(mo+1)+'/'+pad(dy)+'/'+yr;
  return dy+' '+MS[mo]+' '+yr;
}
function relDay(dTz,baseTz){
  var a=localD(dTz),b=localD(baseTz);
  var diff=(a.getDate()-b.getDate())||(a.getMonth()-b.getMonth())||(a.getFullYear()-b.getFullYear());
  if(diff===0)return'';
  return diff>0?' \u00b7 '+t('tomorrow'):' \u00b7 '+t('yesterday');
}
function getOffsetMin(tz){
  var now=new Date();var loc=new Date(now.toLocaleString('en-US',{timeZone:tz}));
  return Math.round((Date.UTC(loc.getFullYear(),loc.getMonth(),loc.getDate(),loc.getHours(),loc.getMinutes())-Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate(),now.getUTCHours(),now.getUTCMinutes()))/60000);
}
function cycleTimeFmt(){S.timeFmt=S.timeFmt==='12h'?'24h':'12h';save();updateTimeFmtBtn();pillOn('timeFmtPills',S.timeFmt);tick();}
function updateTimeFmtBtn(){document.getElementById('timeFmtQuickBtn').textContent=S.timeFmt==='24h'?'24H':'12H';}

var _dstDay=-1;
function isTodayDST(tz){
  try{var today=localD(tz);var yr=today.getFullYear(),mo=today.getMonth(),dy=today.getDate();var dtA=new Date(yr,mo,dy,1,55,0),dtB=new Date(yr,mo,dy,3,5,0);var locA=new Date(dtA.toLocaleString('en-US',{timeZone:tz}));var locB=new Date(dtB.toLocaleString('en-US',{timeZone:tz}));return Math.round((locA-dtA)/60000)!==Math.round((locB-dtB)/60000);}catch(e){return false;}
}
function getDSTChangeToday(tz){
  try{var today=localD(tz);var yr=today.getFullYear(),mo=today.getMonth(),dy=today.getDate();var dtA=new Date(yr,mo,dy,1,55,0),dtB=new Date(yr,mo,dy,3,5,0);var locA=new Date(dtA.toLocaleString('en-US',{timeZone:tz}));var locB=new Date(dtB.toLocaleString('en-US',{timeZone:tz}));var offA=Math.round((locA-dtA)/60000),offB=Math.round((locB-dtB)/60000);if(offA===offB)return null;return{fromOff:offA,toOff:offB};}catch(e){return null;}
}
function checkDST(){
  var today=new Date().getDate();if(today===_dstDay)return;_dstDay=today;
  var _dstPrimary=isTodayDST(S.primaryTz);var _dstOthers=[];var clks=getClocks();
  for(var i=0;i<clks.length;i++)if(clks[i].tz!==S.primaryTz&&isTodayDST(clks[i].tz))_dstOthers.push(clks[i].tz);
  var banner=document.getElementById('dstBanner');
  if(_dstPrimary||_dstOthers.length>0){
    banner.classList.add('show');
    var ch=getDSTChangeToday(S.primaryTz);var sp=ch?ch.toOff>ch.fromOff:true;
    document.getElementById('dstBannerTitle').textContent=_dstPrimary?(sp?t('dstSpring'):t('dstFall'))+' \u2600\ufe0f':t('dstToday');
    var oth='';for(var i=0;i<_dstOthers.length;i++){var o=tzObj(_dstOthers[i]);if(o)oth+=o.fl+cName(o)+' ';}
    document.getElementById('dstBannerSub').textContent=oth;
  }else banner.classList.remove('show');
}

function buildStars(el){el.innerHTML='';for(var i=0;i<100;i++){var s=document.createElement('div');s.className='star';var sz=(Math.random()*2+0.5).toFixed(1);s.style.cssText='width:'+sz+'px;height:'+sz+'px;left:'+(Math.random()*100).toFixed(1)+'%;top:'+(Math.random()*100).toFixed(1)+'%;--dur:'+(Math.random()*3+2).toFixed(1)+'s;--lo:'+(Math.random()*.15+.05).toFixed(2)+';--hi:'+(Math.random()*.6+.4).toFixed(2)+';animation-delay:'+(Math.random()*4).toFixed(1)+'s;';el.appendChild(s);}}

function buildDarkStars(el,cssClass){
  cssClass=cssClass||'ds-star';el.innerHTML='';
  var configs=[{count:120,minSz:.5,maxSz:1.2,minLo:.03,maxLo:.1,minHi:.3,maxHi:.6,minDur:2,maxDur:4},{count:50,minSz:1.2,maxSz:2,minLo:.05,maxLo:.15,minHi:.5,maxHi:.85,minDur:1.5,maxDur:3.5},{count:15,minSz:2,maxSz:3,minLo:.1,maxLo:.2,minHi:.8,maxHi:1,minDur:1,maxDur:2.5}];
  var colors=['#fff','#fff','#fff','#fff','#a5b4fc','#7dd3fc','#e9d5ff','#fbbf24'];
  configs.forEach(function(cfg){
    for(var i=0;i<cfg.count;i++){
      var s=document.createElement('div');s.className=cssClass;
      var sz=(Math.random()*(cfg.maxSz-cfg.minSz)+cfg.minSz).toFixed(2);
      var lo=(Math.random()*(cfg.maxLo-cfg.minLo)+cfg.minLo).toFixed(3);
      var hi=(Math.random()*(cfg.maxHi-cfg.minHi)+cfg.minHi).toFixed(3);
      var dur=(Math.random()*(cfg.maxDur-cfg.minDur)+cfg.minDur).toFixed(2);
      var dl=(Math.random()*6).toFixed(2);
      var col=colors[Math.floor(Math.random()*colors.length)];
      s.style.cssText='width:'+sz+'px;height:'+sz+'px;left:'+(Math.random()*100).toFixed(2)+'%;top:'+(Math.random()*100).toFixed(2)+'%;background:'+col+';--dur:'+dur+'s;--lo:'+lo+';--hi:'+hi+';animation-delay:'+dl+'s;box-shadow:0 0 '+(parseFloat(sz)*2)+'px '+col+';';
      el.appendChild(s);
    }
  });
}

/* ── MAIN DARK COSMOS ── */
function toggleMainDark(){
  S.mainDark=!S.mainDark;save();applyMainDark();
}
function applyMainDark(){
  var btn=document.getElementById('mainDarkBtn');
  var layer=document.getElementById('mainDarkStars');
  if(S.mainDark){
    document.body.classList.add('dark-cosmos');
    if(btn){btn.classList.add('on');btn.classList.add('cosmos-on');}
    if(layer&&layer.children.length===0)buildDarkStars(layer,'ds-star-main');
  }else{
    document.body.classList.remove('dark-cosmos');
    if(btn){btn.classList.remove('on');btn.classList.remove('cosmos-on');}
  }
}

function updatePrimary(){
  var clk=tzObj(S.primaryTz)||TZ_DB[0];var d=localD(clk.tz);
  document.getElementById('primaryLoc').textContent=clk.fl+'  '+cName(clk)+', '+ctName(clk);
  var main=fmtPrimary(d);document.getElementById('primaryTime').textContent=main;
  var altEl=document.getElementById('primaryAlt');
  if(S.showAlt){var alt=S.timeFmt==='24h'?fmt12(d,S.showSec):fmt24(d,S.showSec);altEl.textContent=main+' / '+alt;}else altEl.textContent='';
  document.getElementById('primaryDate').textContent=fmtDate(d,S.dateFmt)+' '+getPeriod(d);
}

var dragSrcTz=null;
function hexA(hex,a){hex=String(hex).replace('#','');if(hex.length===3)hex=hex.split('').map(function(c){return c+c;}).join('');var n=parseInt(hex,16);if(isNaN(n))return'rgba(167,139,250,'+a+')';var r=(n>>16)&255,g=(n>>8)&255,b=n&255;return'rgba('+r+','+g+','+b+','+a+')';}
var sgPage=0,SG_PER=5;
function sgPageGo(d){sgPage+=d;if(sgPage<0)sgPage=0;renderGrid();}
function renderGrid(){
  var grid=document.getElementById('clocksGrid');grid.innerHTML='';
  var all=getClocks().filter(function(c){return c.tz!==S.primaryTz;});
  var pages=Math.max(1,Math.ceil(all.length/SG_PER));if(sgPage>pages-1)sgPage=pages-1;if(sgPage<0)sgPage=0;
  var clks=all.slice(sgPage*SG_PER,sgPage*SG_PER+SG_PER);
  var _pi=document.getElementById('sgPageInfo');if(_pi)_pi.textContent=(sgPage+1)+' / '+pages;
  var _pb=document.getElementById('sgPrevBtn'),_nb=document.getElementById('sgNextBtn');
  if(_pb)_pb.disabled=sgPage<=0;if(_nb)_nb.disabled=sgPage>=pages-1;
  var _pg=document.getElementById('sgPager');if(_pg)_pg.style.display=pages>1?'flex':'none';
  for(var i=0;i<clks.length;i++){
    var clk=clks[i];
    var d=localD(clk.tz);var isDST=isTodayDST(clk.tz);var dstCh=isDST?getDSTChangeToday(clk.tz):null;
    var dstBadge=isDST?'<span class="dst-badge">'+(dstCh&&dstCh.toOff>dstCh.fromOff?'\u2600+1h':'\ud83c\udf42-1h')+'</span>':'';
    var el=document.createElement('div');el.className='clock-item'+(isDST?' dst-today':'');el.draggable=true;el.dataset.tz=clk.tz;
    var rowColor=DOT_COLORS[clk.dot]||'#a78bfa';
    var vivid=S.rowStyle==='vivid';
    var pin=S.rowStyle==='pin';
    var tinted=vivid||pin;
    if(tinted&&!isDST){el.style.background='linear-gradient(90deg, '+hexA(rowColor,.16)+', '+hexA(rowColor,.045)+' 38%, rgba(255,255,255,.03) 75%)';el.style.borderColor=hexA(rowColor,.22);}
    var markerHtml=pin
      ?'<div class="ccode-pin" style="background:'+hexA(rowColor,.18)+';border-color:'+hexA(rowColor,.55)+';color:'+rowColor+';">'+clk.cc+'</div>'
      :'<div class="cdot'+(vivid?'':' dot-classic')+'" style="color:'+rowColor+';background:'+rowColor+';"></div>';
    var utcHtml=S.showUtcOffset?'<div class="ctutc"'+(pin?' style="color:'+rowColor+';"':'')+'>'+fmtUtcOffset(clk.tz)+'</div>':'';
    el.innerHTML='<div class="drag-handle"><span></span><span></span><span></span></div>'+markerHtml
      +'<div class="cinfo"><div class="cname-row"><span class="ccountry-main">'+clk.fl+' '+ctName(clk)+'</span><span class="ccity-badge">'+cName(clk)+'</span>'+dstBadge+'</div></div>'
      +'<div class="ctblock"><div class="ctmain">'+fmtCard(d,S.cardFmt)+'</div><div class="ctdate">'+fmtDate(d,S.dateFmt)+' '+getPeriod(d)+relDay(clk.tz,S.primaryTz)+'</div></div>'+utcHtml;
    (function(tz,elem,rc,dst,tt){
      elem.addEventListener('dragstart',function(e){dragSrcTz=tz;elem.classList.add('dragging');e.dataTransfer.effectAllowed='move';});
      elem.addEventListener('dragend',function(){elem.classList.remove('dragging');var its=grid.querySelectorAll('.clock-item');for(var j=0;j<its.length;j++)its[j].classList.remove('drag-over');});
      elem.addEventListener('dragover',function(e){e.preventDefault();var its=grid.querySelectorAll('.clock-item');for(var j=0;j<its.length;j++)its[j].classList.remove('drag-over');if(tz!==dragSrcTz)elem.classList.add('drag-over');});
      elem.addEventListener('dragleave',function(){elem.classList.remove('drag-over');});
      elem.addEventListener('drop',function(e){e.preventDefault();elem.classList.remove('drag-over');if(!dragSrcTz||dragSrcTz===tz)return;var fi=S.clockTzs.indexOf(dragSrcTz),ti=S.clockTzs.indexOf(tz);if(fi<0||ti<0)return;S.clockTzs.splice(fi,1);S.clockTzs.splice(ti,0,dragSrcTz);dragSrcTz=null;save();renderGrid();});
      if(tt&&!dst){
        elem.addEventListener('mouseenter',function(){elem.style.background='linear-gradient(90deg, '+hexA(rc,.26)+', '+hexA(rc,.08)+' 38%, rgba(255,255,255,.05) 75%)';});
        elem.addEventListener('mouseleave',function(){elem.style.background='linear-gradient(90deg, '+hexA(rc,.16)+', '+hexA(rc,.045)+' 38%, rgba(255,255,255,.03) 75%)';});
      }
    })(clk.tz,el,rowColor,isDST,tinted);
    grid.appendChild(el);
  }
  updateFooterBar();
}

function makeAnalog(d,size,darkFace){
  size=size||90;
  var h=d.getHours()%12,m=d.getMinutes(),sec=d.getSeconds();
  var hA=(h*60+m)/720*360-90;var mA=m/60*360-90;var sA=sec/60*360-90;
  function pt(a,r){var rad=a*Math.PI/180;return[50+r*Math.cos(rad),50+r*Math.sin(rad)];}
  var faceColor=darkFace?'rgba(10,5,25,.92)':'rgba(255,255,255,.09)';
  var borderColor=darkFace?'rgba(255,255,255,.25)':'rgba(255,255,255,.22)';
  var hHandColor='rgba(255,255,255,.95)';var mHandColor='rgba(255,255,255,.88)';
  var sHandColor=darkFace?'#ef4444':'var(--accent)';
  var numColor='rgba(255,255,255,.88)';
  var ticks='';
  for(var i=0;i<60;i++){
    var a=i/60*360-90;var isH=i%5===0;var isQ=i%15===0;
    var r1=isQ?37:(isH?40:44),r2=47;var sw=isQ?2:(isH?1.5:.7);
    var sc=isH?'rgba(255,255,255,.5)':'rgba(255,255,255,.2)';
    var p1=pt(a,r1),p2=pt(a,r2);
    ticks+='<line x1="'+p1[0]+'" y1="'+p1[1]+'" x2="'+p2[0]+'" y2="'+p2[1]+'" stroke="'+sc+'" stroke-width="'+sw+'"/>';
  }
  var numLabels=[12,1,2,3,4,5,6,7,8,9,10,11];var nums='';
  for(var i=0;i<12;i++){
    var a=(i/12)*360-90;var isQ=i%3===0;var nr=isQ?30:34;var np=pt(a,nr);
    var fs=isQ?10.5:7.5;var fw=isQ?'700':'500';var op=isQ?'1':'.65';
    nums+='<text x="'+np[0]+'" y="'+np[1]+'" text-anchor="middle" dominant-baseline="central" font-size="'+fs+'" font-weight="'+fw+'" fill="'+numColor+'" opacity="'+op+'" font-family="sans-serif">'+numLabels[i]+'</text>';
  }
  var hp=pt(hA,20),mp=pt(mA,28),sp=pt(sA,34);
  return '<svg viewBox="0 0 100 100" width="'+size+'" height="'+size+'" xmlns="http://www.w3.org/2000/svg">'
    +'<defs><filter id="gfs'+size+'"><feGaussianBlur stdDeviation="1.5" result="cb"/><feMerge><feMergeNode in="cb"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>'
    +'<circle cx="50" cy="50" r="48" fill="'+faceColor+'" stroke="'+borderColor+'" stroke-width="1.5"/>'
    +ticks+nums
    +'<line x1="50" y1="50" x2="'+hp[0]+'" y2="'+hp[1]+'" stroke="'+hHandColor+'" stroke-width="3.5" stroke-linecap="round"/>'
    +'<line x1="50" y1="50" x2="'+mp[0]+'" y2="'+mp[1]+'" stroke="'+mHandColor+'" stroke-width="2.5" stroke-linecap="round"/>'
    +'<line x1="50" y1="50" x2="'+sp[0]+'" y2="'+sp[1]+'" stroke="'+sHandColor+'" stroke-width="1.5" stroke-linecap="round" filter="url(#gfs'+size+')"/>'
    +'<circle cx="50" cy="50" r="3" fill="'+sHandColor+'" filter="url(#gfs'+size+')"/>'
    +'</svg>';
}

var fsOpen=false;
function openFullscreen(){
  fsOpen=true;document.getElementById('fsOverlay').classList.add('open');mpSyncFsCanvas();
  if(S.skin==='starfield')buildStars(document.getElementById('fsStarsLayer'));
  updateFsToolbar();applyFsDark();
  var sl=document.getElementById('fsScaleSlider');if(sl)sl.value=S.fsScale||100;
  updateFS();
}
function closeFullscreen(){fsOpen=false;document.getElementById('fsOverlay').classList.remove('open');mpSyncFsCanvas();}
function setFsMode(m){
  S.fsMode=m;save();updateFsToolbar();
  document.getElementById('fsClockGrid').style.display=m==='clock'?'flex':'none';
  document.getElementById('fsBlocksGrid').style.display=m==='blocks'?'flex':'none'; /* FIXED: flex not grid */
  updateFS();
}
function setFsTimeFmt(f){S.fsTimeFmt=f;save();updateFsToolbar();updateFS();}
function toggleFsDark(){S.fsDark=!S.fsDark;save();updateFsToolbar();applyFsDark();}
function toggleClockFace(){S.fsClockDark=!S.fsClockDark;save();updateFsToolbar();updateFS();}
function toggleFsDate(){S.fsShowDate=!S.fsShowDate;save();updateFsToolbar();updateFS();}
function setFsScale(v){S.fsScale=parseInt(v);save();updateFS();}
function applyFsDark(){
  var ov=document.getElementById('fsOverlay');var ds=document.getElementById('fsDarkStars');
  if(S.fsDark){ov.style.background='linear-gradient(135deg,#02010a,#050312,#030210)';document.querySelectorAll('.fs-bg-orb').forEach(function(o){o.style.opacity='.07';});if(ds&&ds.children.length===0)buildDarkStars(ds,'ds-star');if(ds)ds.classList.add('active');}
  else{ov.style.background='';document.querySelectorAll('.fs-bg-orb').forEach(function(o){o.style.opacity='';});if(ds)ds.classList.remove('active');}
}
function updateFsToolbar(){
  document.getElementById('fsTbClock').classList.toggle('on',S.fsMode==='clock');
  document.getElementById('fsTbBlock').classList.toggle('on',S.fsMode==='blocks');
  document.getElementById('fsTb12').classList.toggle('on',S.fsTimeFmt==='12h');
  document.getElementById('fsTb24').classList.toggle('on',S.fsTimeFmt==='24h');
  document.getElementById('fsTbDark').classList.toggle('on',S.fsDark);
  document.getElementById('fsTbClockDark').classList.toggle('on',S.fsClockDark);
  document.getElementById('fsTbDate').classList.toggle('on',S.fsShowDate);
  document.getElementById('fsTbClock').innerHTML='&#9711; '+t('fsClk');
  document.getElementById('fsTbBlock').innerHTML='&#9632; '+t('fsBlk');
}
function getFsTime(d){return S.fsTimeFmt==='24h'?fmt24(d,false):fmt12(d,false);}

function updateFS(){
  if(!fsOpen)return;
  var pClk=tzObj(S.primaryTz)||TZ_DB[0];var pd=localD(pClk.tz);
  var ph=pd.getHours(),pm2=pd.getMinutes(),ps=pd.getSeconds();
  var ph12=ph%12||12;var pap=ph>=12?'PM':'AM';
  var primHtml;
  if(S.fsTimeFmt==='24h'){primHtml=pad(ph)+'<span class="fs-colon-blink">:</span>'+pad(pm2)+'<span class="fs-colon-blink">:</span>'+pad(ps);}
  else{primHtml=ph12+'<span class="fs-colon-blink">:</span>'+pad(pm2)+'<span class="fs-colon-blink">:</span>'+pad(ps)+' '+pap;}
  document.getElementById('fsPrimaryFlag').textContent=pClk.fl;
  document.getElementById('fsPrimaryLoc').textContent=cName(pClk)+', '+ctName(pClk);
  document.getElementById('fsPrimaryTime').innerHTML=primHtml;
  var sub=S.fsTimeFmt==='24h'?fmt12(pd,false):fmt24(pd,false);
  if(S.fsShowDate)sub+=' \u00b7 '+fmtDate(pd,S.dateFmt)+' '+getPeriod(pd);
  document.getElementById('fsPrimarySub').textContent=sub;

  var cGrid=document.getElementById('fsClockGrid'),bGrid=document.getElementById('fsBlocksGrid');
  cGrid.innerHTML='';bGrid.innerHTML='';
  var clks=getClocks();
  var sc=(S.fsScale||100)/100;
  var analogSize=Math.round(88*sc);
  var timeFontSize=Math.round(14*sc);
  var blkHFont=Math.round(38*sc);
  var blkSepFont=Math.round(32*sc);

  for(var i=0;i<clks.length;i++){
    var clk=clks[i];if(clk.tz===S.primaryTz)continue;
    var d=localD(clk.tz);var isDST=isTodayDST(clk.tz);var dstCh=isDST?getDSTChangeToday(clk.tz):null;
    var rel=relDay(clk.tz,S.primaryTz);
    var dotColor=DOT_COLORS[clk.dot]||'#a78bfa';
    var dstTag=isDST?'<div class="fs-cc-dst">'+(dstCh&&dstCh.toOff>dstCh.fromOff?'\u2600\ufe0f +1h':'\ud83c\udf42 -1h')+'</div>':'';
    var period=getPeriod(d);
    var dateLine=fmtDate(d,S.dateFmt)+' \u00b7 '+period+(rel?' '+rel:'');

    var cc=document.createElement('div');cc.className='fs-clock-card'+(isDST?' dst-today':'');
    cc.style.width=Math.round(170*sc)+'px';
    cc.innerHTML='<div class="fs-cc-header"><span class="fs-cc-dot" style="background:'+dotColor+';color:'+dotColor+'"></span><span class="fs-cc-badge">'+clk.cc+'</span></div>'
      +'<div class="fs-cc-name">'+ctName(clk)+'</div><div class="fs-cc-city">'+cName(clk)+'</div>'
      +'<div class="analog-wrap">'+makeAnalog(d,analogSize,S.fsClockDark)+'</div>'
      +'<div class="fs-cc-time" style="font-size:'+timeFontSize+'px;">'+getFsTime(d)+'</div>'
      +(S.fsShowDate?'<div class="fs-cc-date">'+dateLine+'</div>':'')
      +dstTag;
    cGrid.appendChild(cc);

    var bc=document.createElement('div');bc.className='fs-block-card'+(isDST?' dst-today':'');
    bc.style.width=Math.round(200*sc)+'px';
    var bh=S.fsTimeFmt==='24h'?pad(d.getHours()):String(d.getHours()%12||12);
    var bm=pad(d.getMinutes());var bap2=d.getHours()>=12?'PM':'AM';
    var ampmHtml=S.fsTimeFmt==='12h'?'<span class="fs-blk-ampm" style="font-size:'+Math.round(12*sc)+'px;">'+bap2+'</span>':'';
    var alt24=S.fsTimeFmt==='12h'?'<div class="fs-blk-24">'+pad(d.getHours())+':'+bm+'</div>':'';
    var dstTag2=isDST?'<div class="fs-blk-dst">'+(dstCh&&dstCh.toOff>dstCh.fromOff?'\u2600\ufe0f +1h':'\ud83c\udf42 -1h')+'</div>':'';
    bc.innerHTML='<div class="fs-blk-header"><span class="fs-blk-dot" style="background:'+dotColor+';color:'+dotColor+'"></span><span class="fs-blk-badge">'+clk.cc+'</span><span class="fs-blk-country">'+ctName(clk)+'</span></div>'
      +'<div class="fs-blk-city">'+cName(clk)+'</div>'
      +'<div class="fs-blk-time-row"><span class="fs-blk-h" style="font-size:'+blkHFont+'px;">'+bh+'</span><span class="fs-blk-sep" style="font-size:'+blkSepFont+'px;">:</span><span class="fs-blk-m" style="font-size:'+blkHFont+'px;">'+bm+'</span>'+ampmHtml+'</div>'
      +alt24
      +(S.fsShowDate?'<div class="fs-blk-date">'+dateLine+'</div>':'')
      +dstTag2;
    bGrid.appendChild(bc);
  }
}

var convOpen=false;
function toggleConverter(){convOpen=!convOpen;document.getElementById('converterCard').style.display=convOpen?'block':'none';document.getElementById('convBtn').classList.toggle('on',convOpen);if(convOpen){buildConvFrom();buildConvFmtBar();renderConvResults();}}
function buildConvFrom(){var sel=document.getElementById('convFromTz');sel.innerHTML='';var clks=getClocks();for(var i=0;i<clks.length;i++){var o=document.createElement('option');o.value=clks[i].tz;o.textContent=clks[i].fl+' '+cName(clks[i]);if(clks[i].tz===S.primaryTz)o.selected=true;sel.appendChild(o);}}
function buildConvFmtBar(){var bar=document.getElementById('convFmtBar');bar.innerHTML='';var fmts=[{v:'12h',l:'12h AM/PM'},{v:'24h',l:'24h'},{v:'both',l:'12h/24h'}];for(var i=0;i<fmts.length;i++){(function(f){var el=document.createElement('div');el.className='conv-fmt-pill'+(S.convFmt===f.v?' on':'');el.textContent=f.l;el.onclick=function(){S.convFmt=f.v;save();buildConvFmtBar();renderConvResults();};bar.appendChild(el);})(fmts[i]);}}
function runConvert(){renderConvResults();}
function renderConvResults(){
  var fromTz=document.getElementById('convFromTz').value;
  var tv=(typeof convTimeVal!=='undefined'?convTimeVal:'12:00').split(':');var hh=parseInt(tv[0]),mm=parseInt(tv[1]);
  var fromOff=getOffsetMin(fromTz);var baseMin=hh*60+mm-fromOff;
  var res=document.getElementById('convResults');res.innerHTML='';
  var clks=getClocks();
  for(var i=0;i<clks.length;i++){
    var clk=clks[i];var toOff=getOffsetMin(clk.tz);var m=baseMin+toOff,dayOff=0;
    while(m<0){m+=1440;dayOff--;}while(m>=1440){m-=1440;dayOff++;}
    var rDate=new Date();rDate.setHours(Math.floor(m/60),m%60,0,0);
    var ts;if(S.convFmt==='12h')ts=fmt12(rDate,false);else if(S.convFmt==='24h')ts=fmt24(rDate,false);else ts=fmt12(rDate,false)+' / '+fmt24(rDate,false);
    var diffMin=toOff-fromOff,diffStr;
    if(diffMin===0)diffStr=t('diffSame');else{var ab=Math.abs(diffMin),dh=Math.floor(ab/60),dm2=ab%60;diffStr=(diffMin>0?'+':'-')+(dh?dh+t('hours'):'')+(dm2?dm2+t('mins'):'')+' '+(diffMin>0?t('diffAhead'):t('diffBehind'));}
    var dayStr=dayOff===0?'':(dayOff>0?' +'+dayOff+'d':' '+dayOff+'d');
    var row=document.createElement('div');row.className='conv-row'+(clk.tz===fromTz?' hl':'');
    row.innerHTML='<div class="conv-row-dot '+clk.dot+'"></div><div class="conv-row-info"><div class="conv-row-place">'+clk.fl+' '+ctName(clk)+'</div><div class="conv-row-diff">'+diffStr+'</div></div><div><div class="conv-row-time">'+ts+'</div><div class="conv-row-day">'+dayStr+'</div></div>';
    res.appendChild(row);
  }
}

function toggleLang(){S.lang=S.lang==='en'?'zh':'en';save();applyLang();tick();}
function applyLang(){
  document.getElementById('langLabel').textContent=S.lang==='en'?'EN':'\u4e2d';
  var m={settingsTitleEl:'settings',aboutTitleEl:'about',convTitleEl:'convTitle',convFromLbl:'convFrom',convTimeLbl:'convTime',convBtnEl:'convBtn',sPrimary:'sPrimary',sTimefmt:'sTimefmt',sAltline:'sAltline',sAltlineLbl:'sAltlineLbl',sSec:'sSec',sSecLbl:'sSecLbl',sDatefmt:'sDatefmt',sCardfmt:'sCardfmt',sFontsize:'sFontsize',sActive:'sActive',sAdd:'sAdd'};
  for(var id in m){var el=document.getElementById(id);if(el)el.textContent=t(m[id]);}
  
  updateFsToolbar();
}
function buildFontSelect(){var sel=document.getElementById('fontSelect');if(!sel)return;sel.innerHTML='';for(var i=0;i<FONTS.length;i++){var o=document.createElement('option');o.value=FONTS[i].id;o.textContent=FONTS[i].name+' \u00b7 '+FONTS[i].zh;if(S.font===FONTS[i].id)o.selected=true;sel.appendChild(o);}}
function setFont(id){S.font=id;document.documentElement.style.setProperty('--font',fontStack(id));save();buildFontSelect();}
function applyFont(){document.documentElement.style.setProperty('--font',fontStack(S.font||'sys'));}
function setFontScale(v){S.fontScale=parseInt(v);document.documentElement.style.setProperty('--fs',S.fontScale/100);document.getElementById('scaleVal').textContent=S.fontScale+'%';save();}
function applyFontScale(){document.documentElement.style.setProperty('--fs',S.fontScale/100);var sl=document.getElementById('fontScaleSlider');if(sl){sl.value=S.fontScale;document.getElementById('scaleVal').textContent=S.fontScale+'%';}}
function applySkin(){document.body.className='';if(S.skin!=='default')document.body.classList.add('skin-'+S.skin);if(S.mainDark)document.body.classList.add('dark-cosmos');if(S.skin==='starfield')buildStars(document.getElementById('starsLayer'));else document.getElementById('starsLayer').innerHTML='';}
function buildSkinGrid(){var g=document.getElementById('skinGrid');g.innerHTML='';for(var i=0;i<SKINS.length;i++){(function(sk){var el=document.createElement('div');el.className='skin-card'+(S.skin===sk.id?' on':'');el.style.background=sk.bg;el.innerHTML='<div class="skin-swatch" style="background:'+sk.grad+'"></div><div><div class="skin-name">'+sk.name+'</div><div class="skin-sub">'+sk.en+'</div></div>';el.onclick=function(){setSkin(sk.id);};g.appendChild(el);})(SKINS[i]);}}
function setSkin(id){S.skin=id;save();applySkin();buildSkinGrid();}
var dstPrvOpen=false;
function toggleDstPreview(){dstPrvOpen=!dstPrvOpen;document.getElementById('dstPreviewPanel').classList.toggle('open',dstPrvOpen);if(dstPrvOpen)buildDstPreview();}
function buildDstPreview(){
  var pClk=tzObj(S.primaryTz)||TZ_DB[0];var content=document.getElementById('dstPreviewContent');
  var yr=new Date().getFullYear();var changes=[],prev=null;
  for(var m=0;m<12;m++){for(var d=1;d<=28;d++){var dt=new Date(yr,m,d,3,0,0);var loc=new Date(dt.toLocaleString('en-US',{timeZone:pClk.tz}));var off=Math.round((loc-dt)/60000);if(prev!==null&&off!==prev)changes.push({date:new Date(yr,m,d),from:prev,to:off});prev=off;}}
  if(!changes.length){content.innerHTML='<div style="font-size:11px;color:var(--text3);padding:4px 0;">'+pClk.fl+' No DST observed</div>';return;}
  function fmtOff(o){return 'UTC'+(o>=0?'+':'')+Math.floor(o/60)+(o%60?':'+pad(Math.abs(o%60)):'');}
  var html='<div style="font-size:10px;color:rgba(233,213,255,.5);margin-bottom:8px;">'+pClk.fl+' '+ctName(pClk)+' \u00b7 '+yr+'</div><div class="dst-preview-grid">';
  for(var i=0;i<changes.length;i++){var ch=changes[i],sp=ch.to>ch.from;html+='<div class="dst-prev-card"><div class="dst-prev-label">'+(sp?'\u2600\ufe0f Spring':'\ud83c\udf42 Fall')+'</div><div class="dst-prev-time">'+pad(ch.date.getDate())+' '+MS[ch.date.getMonth()]+'</div><div class="dst-prev-date">'+fmtOff(ch.from)+' \u2192 '+fmtOff(ch.to)+'</div></div>';}
  html+='</div><div class="dst-offset-info">';
  for(var i=0;i<changes.length;i++){var ch=changes[i],sp=ch.to>ch.from,adj=Math.abs(ch.to-ch.from);html+=(sp?'\u2600\ufe0f':'\ud83c\udf42')+' '+pad(ch.date.getDate())+' '+MS[ch.date.getMonth()]+': 2:00\u2192'+(sp?'3:00':'1:00')+' ('+(sp?'+':'-')+adj+'m)<br>';}
  content.innerHTML=html+'</div>';
}
function openSettings(){syncUI();document.getElementById('settingsOverlay').classList.add('open');filterAdd('');}
function closeSettings(){document.getElementById('settingsOverlay').classList.remove('open');}
function openAbout(){applyLang();document.getElementById('aboutOverlay').classList.add('open');}
function closeAbout(){document.getElementById('aboutOverlay').classList.remove('open');}
function ovClick(e,id){if(e.target.id===id)document.getElementById(id).classList.remove('open');}
function syncUI(){pillOn('timeFmtPills',S.timeFmt);pillOn('dateFmtPills',S.dateFmt);pillOn('cardFmtPills',S.cardFmt);pillOn('rowStylePills',S.rowStyle);document.getElementById('togAlt').checked=S.showAlt;document.getElementById('togSec').checked=S.showSec;document.getElementById('togUtcOff').checked=S.showUtcOffset;rebuildPrimSel();renderAcList();updateFmtPrev();applyFontScale();buildSkinGrid();buildFontSelect();applyLang();updateTimeFmtBtn();}
function pillOn(gid,val){var pills=document.querySelectorAll('#'+gid+' .pill');for(var i=0;i<pills.length;i++)pills[i].classList.toggle('on',pills[i].dataset.val===val);}
function setS(key,val){S[key]=val;var gmap={timeFmt:'timeFmtPills',dateFmt:'dateFmtPills',cardFmt:'cardFmtPills',rowStyle:'rowStylePills'};if(gmap[key])pillOn(gmap[key],val);if(key==='dateFmt')updateFmtPrev();if(key==='timeFmt')updateTimeFmtBtn();save();tick();}
function updateFmtPrev(){document.getElementById('fmtPrev').textContent=fmtDate(localD('Australia/Melbourne'),S.dateFmt)+' '+getPeriod(localD('Australia/Melbourne'));}
function setPrimary(tz){S.primaryTz=tz;save();renderAcList();tick();_dstDay=-1;}
document.getElementById('togAlt').addEventListener('change',function(){S.showAlt=this.checked;save();tick();});
document.getElementById('togSec').addEventListener('change',function(){S.showSec=this.checked;save();tick();});
document.getElementById('togUtcOff').addEventListener('change',function(){S.showUtcOffset=this.checked;save();tick();});
function rebuildPrimSel(){var sel=document.getElementById('primSel');sel.innerHTML='';var clks=getClocks();for(var i=0;i<clks.length;i++){var o=document.createElement('option');o.value=clks[i].tz;o.textContent=clks[i].fl+' '+cName(clks[i])+', '+ctName(clks[i]);if(clks[i].tz===S.primaryTz)o.selected=true;sel.appendChild(o);}}
function renderAcList(){var list=document.getElementById('acList');list.innerHTML='';var clks=getClocks();for(var i=0;i<clks.length;i++){(function(c,idx){var row=document.createElement('div');row.className='ac-row';row.innerHTML='<span class="ac-flag">'+c.fl+'</span><span class="ac-name">'+cName(c)+', '+ctName(c)+(c.tz===S.primaryTz?' <span class="ac-star">\u2605</span>':'')+'</span><button class="ac-rm" onclick="rmCity('+idx+')">&#215;</button>';list.appendChild(row);})(clks[i],i);}rebuildPrimSel();}
function rmCity(i){if(S.clockTzs.length<=1)return;if(S.clockTzs[i]===S.primaryTz)S.primaryTz=S.clockTzs[i===0?1:0];S.clockTzs.splice(i,1);save();renderAcList();tick();}
function filterAdd(q){
  var list=document.getElementById('addTzList');list.innerHTML='';
  var preset=!q.trim();
  var added={};for(var i=0;i<S.clockTzs.length;i++)added[S.clockTzs[i]]=1;
  var lq=q.toLowerCase(),res=[];
  for(var i=0;i<TZ_DB.length&&res.length<14;i++){
    var tz=TZ_DB[i];if(added[tz.tz])continue;
    var match=preset||tz.city.toLowerCase().indexOf(lq)>=0||tz.czh.indexOf(q)>=0||tz.co.toLowerCase().indexOf(lq)>=0||tz.czho.indexOf(q)>=0||tz.tz.toLowerCase().indexOf(lq)>=0;
    if(!match&&tz.kw)for(var j=0;j<tz.kw.length;j++)if(tz.kw[j].indexOf(lq)>=0){match=true;break;}
    if(match)res.push(tz);
  }
  if(!res.length){var nd=document.createElement('div');nd.style.cssText='color:var(--text3);font-size:12px;padding:8px 10px;';nd.textContent=t('noResult');list.appendChild(nd);return;}
  for(var i=0;i<res.length;i++){
    (function(tz){var el=document.createElement('div');el.className='tz-opt';el.innerHTML='<span style="font-size:15px;">'+tz.fl+'</span><div><div class="tz-opt-lbl">'+cName(tz)+'</div><div class="tz-opt-sub">'+ctName(tz)+(tz.dst?' \u00b7 DST':'')+'</div></div>';el.onclick=function(){S.clockTzs.push(tz.tz);filterAdd('');save();renderAcList();tick();};list.appendChild(el);})(res[i]);
  }
}
document.addEventListener('keydown',function(e){if(e.key==='Escape'){closeSettings();closeAbout();closeFullscreen();}});

var lastSyncTime=new Date();
var convTimeVal='12:00';
function updateFooterBar(){
  var cnt=document.getElementById('mfbCount');
  if(cnt)cnt.textContent=(S.lang==='zh'?('共 '+S.clockTzs.length+' 个地点'):(S.clockTzs.length+' locations'));
  var st=document.getElementById('mfbSyncTime');
  if(st)st.textContent=(S.lang==='zh'?'更新时间 ':'Updated ')+fmt12(lastSyncTime,true);
}
function manualSyncRefresh(){
  lastSyncTime=new Date();
  updateFooterBar();
  var btn=document.getElementById('mfbRefreshBtn');
  if(btn){btn.classList.remove('spinning');void btn.offsetWidth;btn.classList.add('spinning');}
}
function tick(){updatePrimary();renderGrid();updateFS();checkDST();}
applySkin();applyFont();applyFontScale();applyLang();updateTimeFmtBtn();applyMainDark();
buildStars(document.getElementById('starsLayer'));
checkDST();tick();setInterval(tick,1000);
