
// ══════════════════════════════════════════
//   网页版增强功能（动态叠加特效）
// ══════════════════════════════════════════

// ── 圆润滚动条 + 样式增强 ──
(function(){
  var style = document.createElement('style');
  style.textContent =
    '::-webkit-scrollbar{width:7px;height:7px;}' +
    '::-webkit-scrollbar-track{background:transparent;}' +
    '::-webkit-scrollbar-thumb{background:transparent;border-radius:10px;transition:background .3s ease;}' +
    ':hover::-webkit-scrollbar-thumb,.scrolling::-webkit-scrollbar-thumb{background:rgba(167,139,250,0.55);background:color-mix(in srgb,var(--accent) 55%,transparent);}' +
    '.icon-btn.on{background:rgba(167,139,250,0.45)!important;background:color-mix(in srgb,var(--accent) 45%,transparent)!important;border-color:rgba(167,139,250,0.85)!important;border-color:color-mix(in srgb,var(--accent) 85%,transparent)!important;color:#fff!important;box-shadow:0 0 10px rgba(167,139,250,0.55);box-shadow:0 0 10px color-mix(in srgb,var(--accent) 55%,transparent);}' +
    '#dynFxCanvas{position:fixed;top:0;right:0;bottom:0;left:0;z-index:3;pointer-events:none;}' +
    '#fsDynFxCanvas{position:absolute;top:0;right:0;bottom:0;left:0;z-index:2;pointer-events:none;}' +
    '.pill.on{background:rgba(167,139,250,0.35)!important;background:color-mix(in srgb,var(--accent) 35%,transparent)!important;border-color:rgba(167,139,250,0.7)!important;border-color:color-mix(in srgb,var(--accent) 70%,transparent)!important;color:#fff!important;}' +
    '.hdr-btns{flex-wrap:wrap;justify-content:flex-end;row-gap:5px;}' +
    'body{padding-bottom:28px!important;}';
  document.head.appendChild(style);
})();

var fsOverlayEl = document.getElementById('fsOverlay');

// ── 动态叠加特效 ──
var fxCanvas = document.createElement('canvas');
fxCanvas.id = 'dynFxCanvas';
document.body.appendChild(fxCanvas);

var fsFxCanvas = document.createElement('canvas');
fsFxCanvas.id = 'fsDynFxCanvas';
if (fsOverlayEl) fsOverlayEl.appendChild(fsFxCanvas);

var fxCtx = fxCanvas.getContext('2d');
var fsFxCtx = fsFxCanvas.getContext('2d');
var fxType = 'none';
var fxParticles = [];
var fxTime = 0;
var meteorTimer = null;
var thunderNextFlash = 0, thunderBoltLife = 0, thunderBoltPath = [];

// ── 动态特效可调参数：密度 / 速度 / 随机种子 ──
var fxDensity = 1, fxSpeedMul = 1, fxSeed = 1;
var fxRng = Math.random;
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    var t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function reseedFxRng() { fxRng = mulberry32(fxSeed); }
(function loadSavedFxParams() {
  try {
    var d = parseFloat(localStorage.getItem('sg36_fxDensity'));
    var s = parseFloat(localStorage.getItem('sg36_fxSpeed'));
    var sd = parseInt(localStorage.getItem('sg36_fxSeed'), 10);
    fxDensity = isNaN(d) ? 1 : d;
    fxSpeedMul = isNaN(s) ? 1 : s;
    fxSeed = isNaN(sd) ? Math.floor(Math.random() * 100000) : sd;
  } catch (e) { fxSeed = Math.floor(Math.random() * 100000); }
  reseedFxRng();
})();

function resizeFxCanvas() {
  fxCanvas.width = window.innerWidth; fxCanvas.height = window.innerHeight;
  fsFxCanvas.width = window.innerWidth; fsFxCanvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeFxCanvas);
resizeFxCanvas();

function initFxParticles(type) {
  fxParticles = [];
  var W = fxCanvas.width, H = fxCanvas.height;
  var R = fxRng, D = fxDensity;
  if (type === 'stars') {
    for (var i = 0; i < Math.round(90*D); i++) fxParticles.push({ x: R()*W, y: R()*H, r: R()*1.4+0.4, ph: R()*Math.PI*2, spd: R()*2+1 });
  } else if (type === 'leaves') {
    var lc = [['#c2410c','#7c2d12'],['#b45309','#78350f'],['#a16207','#713f12'],['#dc2626','#7f1d1d']];
    for (var i = 0; i < Math.round(20*D); i++) { var c = lc[Math.floor(R()*lc.length)]; fxParticles.push({ x: R()*W, y: R()*H, vy: R()*0.8+0.6, sway: R()*Math.PI*2, swaySpd: R()*0.022+0.012, rot: R()*360, rotSpd: R()*1.2+0.4, size: R()*5+7, c1: c[0], c2: c[1] }); }
  } else if (type === 'glow') {
    var hues = ['rgba(167,139,250,','rgba(56,189,248,','rgba(251,113,133,'];
    for (var i = 0; i < 3; i++) fxParticles.push({ x: R()*W, y: R()*H, r: R()*160+120, hue: hues[i%3], ph: R()*Math.PI*2 });
  } else if (type === 'snow') {
    for (var i = 0; i < Math.round(70*D); i++) fxParticles.push({ x: R()*W, y: R()*H, r: R()*2.2+1, sway: R()*Math.PI*2, swaySpd: R()*0.015+0.005, vy: R()*0.5+0.25 });
  } else if (type === 'rain2') {
    for (var i = 0; i < Math.round(110*D); i++) fxParticles.push({ x: R()*W, y: R()*H, len: R()*16+10, vy: R()*5+6 });
  } else if (type === 'thunder') {
    for (var i = 0; i < Math.round(70*D); i++) fxParticles.push({ x: R()*W, y: R()*H, len: R()*14+8, vy: R()*4+5 });
    thunderNextFlash = performance.now() + 2000 + R()*3000;
    thunderBoltLife = 0; thunderBoltPath = [];
  } else if (type === 'heart') {
    for (var i = 0; i < Math.round(18*D); i++) fxParticles.push({ x: R()*W, y: H+R()*100, vy: R()*0.35+0.15, sway: R()*Math.PI*2, swaySpd: R()*0.02+0.008, size: R()*14+14, pulseSpd: R()*0.003+0.002 });
  } else if (type === 'meteor') {
    scheduleMeteor();
  }
}
function scheduleMeteor() {
  clearTimeout(meteorTimer);
  if (fxType !== 'meteor') return;
  meteorTimer = setTimeout(function() {
    var W = fxCanvas.width;
    fxParticles.push({ x: Math.random()*W*0.6+W*0.2, y: -20, vx: 2.6, vy: 3.4, trail: [] });
    scheduleMeteor();
  }, 1800 + Math.random()*3200);
}
function drawFx(cv, ctx) {
  var W = cv.width, H = cv.height;
  if (!W) return;
  ctx.clearRect(0, 0, W, H);
  if (fxType === 'none') return;
  if (fxType === 'stars') {
    fxParticles.forEach(function(s) {
      var a = 0.35 + 0.55*Math.sin(fxTime*0.001*s.spd+s.ph);
      ctx.globalAlpha = Math.max(0, a); ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI*2); ctx.fill();
    });
    ctx.globalAlpha = 1;
  } else if (fxType === 'leaves') {
    fxParticles.forEach(function(l) {
      l.y += l.vy*fxSpeedMul; l.sway += l.swaySpd*fxSpeedMul; l.rot += (l.rotSpd||0.8)*fxSpeedMul;
      var x = l.x + Math.sin(l.sway)*18;
      if (l.y > H+20) { l.y = -20; l.x = Math.random()*W; }
      ctx.save(); ctx.translate(x, l.y); ctx.rotate(l.rot*Math.PI/180);
      ctx.globalAlpha = 0.82;
      var sz = l.size, grad = ctx.createLinearGradient(0,-sz,0,sz);
      grad.addColorStop(0, l.c1); grad.addColorStop(1, l.c2);
      ctx.fillStyle = grad; ctx.beginPath();
      ctx.moveTo(0,-sz); ctx.bezierCurveTo(sz*0.7,-sz*0.5,sz*0.7,sz*0.5,0,sz); ctx.bezierCurveTo(-sz*0.7,sz*0.5,-sz*0.7,-sz*0.5,0,-sz); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.15)'; ctx.lineWidth = 0.6;
      ctx.beginPath(); ctx.moveTo(0,-sz*0.8); ctx.lineTo(0,sz*0.8); ctx.stroke();
      ctx.restore();
    });
    ctx.globalAlpha = 1;
  } else if (fxType === 'glow') {
    fxParticles.forEach(function(g) {
      var gx = g.x+Math.sin(fxTime*0.0003+g.ph)*60, gy = g.y+Math.cos(fxTime*0.00022+g.ph)*50;
      var grad = ctx.createRadialGradient(gx,gy,0,gx,gy,g.r);
      grad.addColorStop(0, g.hue+'0.20)'); grad.addColorStop(1, g.hue+'0)');
      ctx.fillStyle = grad; ctx.fillRect(0,0,W,H);
    });
  } else if (fxType === 'meteor') {
    for (var i = fxParticles.length-1; i >= 0; i--) {
      var m = fxParticles[i];
      m.trail.push({x:m.x,y:m.y}); if (m.trail.length > 14) m.trail.shift();
      m.x += m.vx*4*fxSpeedMul; m.y += m.vy*4*fxSpeedMul;
      ctx.lineWidth = 2; ctx.beginPath();
      for (var t = 0; t < m.trail.length; t++) {
        ctx.globalAlpha = t/m.trail.length*0.8; ctx.strokeStyle = 'rgba(255,255,255,0.85)';
        var p = m.trail[t]; if (t===0) ctx.moveTo(p.x,p.y); else ctx.lineTo(p.x,p.y);
      }
      ctx.stroke(); ctx.globalAlpha = 1;
      if (m.y > H+30) fxParticles.splice(i,1);
    }
  } else if (fxType === 'snow') {
    fxParticles.forEach(function(s) {
      s.y += s.vy*fxSpeedMul; s.sway += s.swaySpd*fxSpeedMul;
      var x = s.x+Math.sin(s.sway)*14;
      if (s.y > H+6) { s.y = -6; s.x = Math.random()*W; }
      ctx.globalAlpha = 0.8; ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(x,s.y,s.r,0,Math.PI*2); ctx.fill();
    });
    ctx.globalAlpha = 1;
  } else if (fxType === 'rain2') {
    ctx.strokeStyle = 'rgba(180,210,255,0.55)'; ctx.lineWidth = 1.2;
    fxParticles.forEach(function(r) {
      r.y += r.vy*fxSpeedMul; if (r.y > H+20) { r.y = -20; r.x = Math.random()*W; }
      ctx.beginPath(); ctx.moveTo(r.x,r.y); ctx.lineTo(r.x-3,r.y+r.len); ctx.stroke();
    });
  } else if (fxType === 'thunder') {
    ctx.strokeStyle = 'rgba(180,210,255,0.4)'; ctx.lineWidth = 1;
    fxParticles.forEach(function(r) {
      r.y += r.vy*fxSpeedMul; if (r.y > H+20) { r.y = -20; r.x = Math.random()*W; }
      ctx.beginPath(); ctx.moveTo(r.x,r.y); ctx.lineTo(r.x-2,r.y+r.len); ctx.stroke();
    });
    var now = performance.now();
    if (now > thunderNextFlash) {
      thunderNextFlash = now + 2500 + Math.random()*5000;
      thunderBoltLife = 6;
      var bx = W*0.2+Math.random()*W*0.6, by = 0;
      thunderBoltPath = [{x:bx,y:by}];
      while (by < H*0.55) { bx += (Math.random()-0.5)*46; by += Math.random()*32+18; thunderBoltPath.push({x:bx,y:by}); }
    }
    if (thunderBoltLife > 0) {
      ctx.fillStyle = 'rgba(255,255,255,'+(thunderBoltLife>4?0.18:0.05)+')'; ctx.fillRect(0,0,W,H);
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath();
      thunderBoltPath.forEach(function(p,i){ if(i===0) ctx.moveTo(p.x,p.y); else ctx.lineTo(p.x,p.y); });
      ctx.stroke(); thunderBoltLife--;
    }
  } else if (fxType === 'heart') {
    fxParticles.forEach(function(h) {
      h.y -= h.vy*fxSpeedMul; h.sway += h.swaySpd*fxSpeedMul;
      var x = h.x+Math.sin(h.sway)*16;
      if (h.y < -30) { h.y = H+20; h.x = Math.random()*W; }
      var pulse = 1+0.18*Math.sin(fxTime*h.pulseSpd);
      ctx.save(); ctx.translate(x,h.y); ctx.scale(pulse,pulse);
      ctx.font = h.size+'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(244,114,182,0.65)'; ctx.shadowBlur = 12; ctx.globalAlpha = 0.85;
      ctx.fillText('💗',0,0); ctx.restore();
    });
    ctx.globalAlpha = 1; ctx.shadowBlur = 0;
  }
}
function fxLoop() {
  fxTime += 16;
  drawFx(fxCanvas, fxCtx);
  if (window.fsOpen) drawFx(fsFxCanvas, fsFxCtx);
  requestAnimationFrame(fxLoop);
}
requestAnimationFrame(fxLoop);

function setFxType(type) {
  fxType = type;
  try { localStorage.setItem('sg36_fx', type); } catch(e) {}
  initFxParticles(type);
  if (type === 'meteor') scheduleMeteor(); else clearTimeout(meteorTimer);
}
(function loadSavedFx() {
  try { var saved = localStorage.getItem('sg36_fx'); if (saved) setFxType(saved); } catch(e) {}
})();

// ── 自动隐藏滚动条 ──
(function setupScrollbars() {
  ['.sp-body','.tz-list','.fs-content'].forEach(function(sel) {
    document.querySelectorAll(sel).forEach(function(el) {
      var timer;
      el.addEventListener('scroll', function() {
        el.classList.add('scrolling'); clearTimeout(timer);
        timer = setTimeout(function(){ el.classList.remove('scrolling'); }, 900);
      });
    });
  });
})();

// ── 在设置面板追加：动态特效 ──
(function buildSettingsSection() {
  var spBody = document.querySelector('.sp-body');
  if (!spBody) return;

  var section = document.createElement('div');
  section.className = 'sp-bgfx-wrap';
  section.innerHTML =
    '<div class="slbl">动态叠加特效 · Overlay FX</div>' +
    '<div class="pills" id="fxPills">' +
    '<div class="pill" data-fx="none">无</div>' +
    '<div class="pill" data-fx="stars">✨ 星光</div>' +
    '<div class="pill" data-fx="meteor">🌠 流星</div>' +
    '<div class="pill" data-fx="leaves">🍂 落叶</div>' +
    '<div class="pill" data-fx="glow">🌌 光晕</div>' +
    '<div class="pill" data-fx="snow">❄️ 飘雪</div>' +
    '<div class="pill" data-fx="rain2">🌧️ 下雨</div>' +
    '<div class="pill" data-fx="thunder">⚡ 打雷</div>' +
    '<div class="pill" data-fx="heart">💗 心动</div>' +
    '</div>' +
    '<div class="srow" style="flex-direction:column;align-items:stretch;gap:6px;margin-top:12px;">' +
    '<div class="srow-lbl">粒子密度</div>' +
    '<div class="scale-row"><span style="font-size:11px;color:var(--text3);">40%</span>' +
    '<input class="scale-slider" type="range" min="40" max="200" step="10" value="100" id="fxDensitySlider">' +
    '<span style="font-size:11px;color:var(--text3);">200%</span>' +
    '<span class="scale-val" id="fxDensityVal">100%</span></div></div>' +
    '<div class="srow" style="flex-direction:column;align-items:stretch;gap:6px;">' +
    '<div class="srow-lbl">动画速度</div>' +
    '<div class="scale-row"><span style="font-size:11px;color:var(--text3);">40%</span>' +
    '<input class="scale-slider" type="range" min="40" max="200" step="10" value="100" id="fxSpeedSlider">' +
    '<span style="font-size:11px;color:var(--text3);">200%</span>' +
    '<span class="scale-val" id="fxSpeedVal">100%</span></div></div>' +
    '<div class="srow"><div class="srow-lbl">随机种子 · <span id="fxSeedVal">—</span></div>' +
    '<button class="pill" id="fxRerollBtn" style="cursor:pointer;">🎲 换一批</button></div>';
  spBody.insertBefore(section, spBody.firstChild);

  // 特效选择
  var fxPills = document.querySelectorAll('#fxPills .pill');
  function syncFxPills() {
    var cur = 'none'; try { cur = localStorage.getItem('sg36_fx') || 'none'; } catch(e) {}
    fxPills.forEach(function(p){ p.classList.toggle('on', p.dataset.fx === cur); });
  }
  fxPills.forEach(function(p) {
    p.addEventListener('click', function() { setFxType(p.dataset.fx); syncFxPills(); });
  });
  syncFxPills();

  // ── 密度 / 速度 / 随机种子 UI 绑定 ──
  var densityEl = document.getElementById('fxDensitySlider');
  var speedEl = document.getElementById('fxSpeedSlider');
  var densityVal = document.getElementById('fxDensityVal');
  var speedVal = document.getElementById('fxSpeedVal');
  var seedVal = document.getElementById('fxSeedVal');
  var rerollBtn = document.getElementById('fxRerollBtn');
  if (densityEl) {
    densityEl.value = Math.round(fxDensity * 100);
    speedEl.value = Math.round(fxSpeedMul * 100);
    densityVal.textContent = Math.round(fxDensity * 100) + '%';
    speedVal.textContent = Math.round(fxSpeedMul * 100) + '%';
    seedVal.textContent = '#' + fxSeed;
    densityEl.addEventListener('input', function() {
      fxDensity = parseInt(this.value, 10) / 100;
      densityVal.textContent = this.value + '%';
      try { localStorage.setItem('sg36_fxDensity', fxDensity); } catch(e) {}
      initFxParticles(fxType);
    });
    speedEl.addEventListener('input', function() {
      fxSpeedMul = parseInt(this.value, 10) / 100;
      speedVal.textContent = this.value + '%';
      try { localStorage.setItem('sg36_fxSpeed', fxSpeedMul); } catch(e) {}
    });
    rerollBtn.addEventListener('click', function() {
      fxSeed = Math.floor(Math.random() * 100000);
      reseedFxRng();
      seedVal.textContent = '#' + fxSeed;
      try { localStorage.setItem('sg36_fxSeed', fxSeed); } catch(e) {}
      initFxParticles(fxType);
    });
  }
})();

// ══════════════════════════════════════════
//   设置面板分栏：常规 / 城市 / 皮肤
// ══════════════════════════════════════════
(function buildSettingsTabs() {
  var body = document.querySelector('.sp-body');
  if (!body || body.dataset.tabbed) return;
  body.dataset.tabbed = '1';

  // 自定义背景/特效区块是一个整体包裹的div，先拆包成sp-body的直接子节点，
  // 分组逻辑才能正确识别其中的各个 .slbl
  function unwrap(el) {
    if (!el || !el.parentNode) return;
    var parent = el.parentNode;
    while (el.firstChild) parent.insertBefore(el.firstChild, el);
    parent.removeChild(el);
  }
  document.querySelectorAll('.sp-body > .sp-bgfx-wrap').forEach(unwrap);

  var tabStyle = document.createElement('style');
  tabStyle.textContent =
    '.sp-tabs{display:flex;margin-bottom:14px;overflow-x:auto;scrollbar-width:none;}' +
    '.sp-tabs::-webkit-scrollbar{display:none;}' +
    '.sp-tab{margin-right:4px;padding:6px 13px;border-radius:20px;font-size:12px;white-space:nowrap;cursor:pointer;color:var(--text3);background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);transition:all .2s;}' +
    '.sp-tab.on{background:rgba(167,139,250,.22);border-color:rgba(167,139,250,.55);color:#fff;}' +
    '.sp-tabpage{display:none;}' +
    '.sp-tabpage.on{display:block;}';
  document.head.appendChild(tabStyle);

  var TABS = [
    { id: 'general', label: '常规' },
    { id: 'city', label: '城市' },
    { id: 'skin', label: '皮肤' }
  ];
  var FORMAT_IDS = ['sTimefmt', 'sAltline', 'sSec', 'sDatefmt', 'sCardfmt', 'sRowStyle'];
  var GENERAL_IDS = ['sFontsize'];
  var CITY_IDS = ['sPrimary', 'sActive', 'sAdd'];

  function pickTab(slblNode) {
    var id = slblNode.id || '';
    var txt = slblNode.textContent || '';
    if (CITY_IDS.indexOf(id) >= 0) return 'city';
    if (FORMAT_IDS.indexOf(id) >= 0) return 'general';
    if (GENERAL_IDS.indexOf(id) >= 0) return 'general';
    if (txt.indexOf('动态叠加特效') >= 0) return 'skin';
    if (txt.indexOf('Theme') >= 0 || txt.indexOf('主题') >= 0) return 'skin';
    if (txt.indexOf('Font') >= 0) return 'general';
    return 'general';
  }

  var groups = { general: [], city: [], skin: [] };
  var children = Array.prototype.slice.call(body.children);
  var currentTab = 'general';
  children.forEach(function (child) {
    if (child.classList && child.classList.contains('slbl')) currentTab = pickTab(child);
    groups[currentTab].push(child);
  });

  var tabBar = document.createElement('div');
  tabBar.className = 'sp-tabs';
  var pages = {};
  TABS.forEach(function (tdef) {
    var btn = document.createElement('div');
    btn.className = 'sp-tab';
    btn.textContent = tdef.label;
    btn.dataset.tab = tdef.id;
    btn.addEventListener('click', function () { switchSpTab(tdef.id); });
    tabBar.appendChild(btn);

    var page = document.createElement('div');
    page.className = 'sp-tabpage';
    page.id = 'sptab-' + tdef.id;
    groups[tdef.id].forEach(function (node) { page.appendChild(node); });
    pages[tdef.id] = page;
  });

  body.innerHTML = '';
  body.appendChild(tabBar);
  TABS.forEach(function (tdef) { body.appendChild(pages[tdef.id]); });

  window.switchSpTab = function (id) {
    document.querySelectorAll('.sp-tab').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === id); });
    document.querySelectorAll('.sp-tabpage').forEach(function (p) { p.classList.toggle('on', p.id === 'sptab-' + id); });
    try { localStorage.setItem('sg36web_sptab', id); } catch (e) {}
  };
  var savedTab = 'general';
  try { savedTab = localStorage.getItem('sg36web_sptab') || 'general'; } catch (e) {}
  if (TABS.every(function (t) { return t.id !== savedTab; })) savedTab = 'general';
  window.switchSpTab(savedTab);
})();
