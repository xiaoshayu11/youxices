// Class that controls the game itself, it's responsible for whole game process
class GameManager {
    /**
     * @param {number} player Player's checkers, default value is 2
     * @param {number} AIplayer Which one (black or white) checkers the AI will be playing, default value is 1
     */
    constructor(player = 2, AIplayer = 1) {
        // Game board
        this.gameBoard = new Board();
        // Draw manager
        this.drawManager = new DrawManger(this.gameBoard);
        this.playerTurn = 2;
        this.player = player;
        // AI
        this.AI = new AI(AIplayer);
        // 游戏是否已结束（防重复结算）
        this.gameOver = false;
        // 无吃子半回合数（40 个半回合无吃子判和棋）
        this.quietPlies = 0;
        this.lastCheckerCount = 40;
    };

    /**
     * Initializes by drawing the board and checkers
    */
    Initialize() {
        // Draw board
        this.drawManager.DrawBoard();
    };

    /**
     * Stops the game
    */
    Stop() {
        this.AI.Stop();
    }

    /**
     * Called by 'click' event on tile, performs move action and moves selected checker
    */
    Select() {
        // Get all checkers with 'selected' class
        let checkers = document.querySelectorAll('div.tile div.selected');

        // If there's none then return
        if (checkers.length === 0) {
            return;
        } else {
            // Lets check if the player can move at all
            let possible = gameManager.gameBoard.GetPossibleMoves(gameManager.gameBoard.GetAllEmptyTiles(),
                gameManager.gameBoard.checkers.filter(checker => checker.player === gameManager.player));

            if (possible[1].length === 0 || possible[0].length === 0) {
                // If not then he loses
                gameManager.EndTheGame(1);
                return;
            }

            let tileId = this.getAttribute('id').replace('tile', '');
            let tile = gameManager.gameBoard.tiles[tileId];
            let checker = gameManager.gameBoard.checkers[checkers.item(0).getAttribute('id')];

            // Is this in range?
            let inRange = tile.InRange(checker);

            if (inRange) {
                gameManager.drawManager.RemoveMovedTilesHighlight();

                // To check if we can do more than one jump
                if (inRange === 2) {
                    if (checker.Attack(tile)) {
                        checker.Move(tile);
                        if (typeof sfx !== 'undefined') sfx.capture();

                        if (checker.CanMove()) {
                            checker.element.classList.add('selected');
                            setStatus('可以继续跳吃！');
                        } else {
                            setTimeout(() => {
                                gameManager.AI.TryToMove();
                            }, 1000);

                            gameManager.ChangePlayerTurn();
                        }
                    } else {
                        if (typeof sfx !== 'undefined') sfx.invalid();
                    }
                    // Otherwise just move
                } else if (inRange === 1) {
                    if (!checker.CanMove()) {
                        if (checker.Move(tile)) {
                            if (typeof sfx !== 'undefined') sfx.move();
                            setTimeout(() => {
                                gameManager.AI.TryToMove();
                            }, 1000);

                            gameManager.ChangePlayerTurn();
                        } else {
                            if (typeof sfx !== 'undefined') sfx.invalid();
                        }
                    } else {
                        new Message('能吃子时必须吃子！').Show();
                        if (typeof sfx !== 'undefined') sfx.invalid();
                    }
                }
            } else if (tile.position[0] !== checker.position[0] || tile.position[1] !== checker.position[1]) {
                // 点棋子选子时点击会冒泡到该棋子所在的格（inRange 0），那不是无效走子，不响
                if (typeof sfx !== 'undefined') sfx.invalid();
            }
        }
    };

    /**
     * Ends the game, logs and displays the winner
     * @param {number} player Player who won 
     */
    EndTheGame(player) {
        if (this.gameOver) {
            return;
        }
        this.gameOver = true;

        let header;
        let body;
        let logText;

        if (player === 2) {
            header = '你赢了！';
            body = '恭喜你战胜了 AI';
            logText = '白棋（你）获胜！';
            if (typeof sfx !== 'undefined') sfx.win();
        } else if (player === 1) {
            header = '你输了';
            body = 'AI 赢了这局，再接再厉';
            logText = '黑棋（AI）获胜！';
            if (typeof sfx !== 'undefined') sfx.lose();
        } else {
            header = '和棋';
            body = '双方势均力敌';
            logText = '和棋！';
            if (typeof sfx !== 'undefined') sfx.draw();
        }

        Logger.Log(logText);
        setStatus(header);

        let message = document.createElement('p');
        message.innerHTML = body;

        new Message(message, header, { buttonText: '再来一局', onOk: function () { Restart(); } }).ShowWithHeader();

        // Stop the game
        this.Stop();
    }

    /**
     * Checks victory for both players and displays it if someone won
     */
    CheckVictory() {
        if (this.CheckIfAnyLeft(1)) {
            this.EndTheGame(2);
        } else if (this.CheckIfAnyLeft(2)) {
            this.EndTheGame(1);
        }
    };

    /**
     * Checks if the player has any checkers left
     * @param {number} player Player to check
     * @returns {boolean} ture if the player lost
     */
    CheckIfAnyLeft(player) {
        let counter = 0;

        for (let i = 0; i < this.gameBoard.boardSize; i++) {
            if (!this.gameBoard.board[i].includes(player)) {
                counter++;
            }
        }

        if (counter === this.gameBoard.boardSize) {
            return true;
        } else {
            return false;
        }
    };

    /**
     * Changes turn between players
    */
    ChangePlayerTurn() {
        if (this.playerTurn === 1) {
            this.playerTurn = 2;
        } else {
            this.playerTurn = 1;
        }

        setStatus(this.playerTurn === 1 ? 'AI 思考中…' : '轮到你走（白棋）');

        gameManager.CheckVictory();

        if (this.gameOver) {
            return;
        }

        // 40 个半回合无吃子判和棋
        let count = this.gameBoard.checkers.filter(checker => checker.position.length > 0).length;
        if (count === this.lastCheckerCount) {
            this.quietPlies++;
        } else {
            this.quietPlies = 0;
            this.lastCheckerCount = count;
        }

        if (this.quietPlies >= 40) {
            this.EndTheGame(0);
        }
    };
};