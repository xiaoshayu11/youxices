/**
 * Removes message box
 * @param {Node} messageBox DOM Node object of Message
 */
function OkButton(messageBox) {
    document.body.removeChild(messageBox);
};

/**
 * Sets the status line text
 * @param {string} text Status text
 */
function setStatus(text) {
    let status = document.getElementById('status');
    if (status) status.textContent = text;
};

/**
 * Restarts the game in place (no page reload, so the widget/minitool keeps its state)
*/
function Restart() {
    // 移除残留弹窗
    let boxes = document.querySelectorAll('#outerMessageBox');
    for (let box of boxes) {
        if (box.parentNode) box.parentNode.removeChild(box);
    }

    // 清空棋盘与日志
    document.querySelector('div.tiles').innerHTML = '';
    document.getElementById('log').innerHTML = '';

    // 新开一局（残留的 AI 定时器由 TryToMove 的回合守卫挡住）
    gameManager = new GameManager();
    gameManager.Initialize();
    setStatus('轮到你走（白棋）');
};

/**
 * To show message with rules
*/
function Rules() {
    let rules = ['不限时间，想走多久走多久',
        '能吃子时必须吃子',
        '棋子只能走深色格',
        '普通棋子只能往前走',
        '走到底线就升王',
        '王可以往任意方向走',
        '吃光对方棋子，或对方无路可走，即获胜',
        '40 个回合无人吃子判和棋'];
    let message = document.createElement('ul');

    rules.map((rule) => {
        let ruleElement = document.createElement('li');
        ruleElement.innerHTML = rule;
        message.appendChild(ruleElement);
    });

    new Message(message, '玩法规则').ShowWithHeader();
};

// Wire buttons once the DOM is ready (no inline handlers)
document.addEventListener('DOMContentLoaded', function () {
    let restartBtn = document.getElementById('restartBtn');
    if (restartBtn) restartBtn.addEventListener('click', Restart);
    let rulesBtn = document.getElementById('rulesBtn');
    if (rulesBtn) rulesBtn.addEventListener('click', Rules);
});
