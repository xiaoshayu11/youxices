// WebAudio 合成音效（上游无音效，本版新增）
let __audioCtx = null;
let __soundOn = true;

const setSoundOn = (on) => { __soundOn = !!on; };
const isSoundOn = () => __soundOn;

const ensureAudio = () => {
  if (!__audioCtx) {
    try { __audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch (e) { __audioCtx = null; }
  }
  if (__audioCtx && __audioCtx.state === 'suspended') __audioCtx.resume();
  return __audioCtx;
};

const tone = (freq, dur, type, vol, when) => {
  const ctx = ensureAudio();
  if (!ctx) return;
  const t0 = ctx.currentTime + (when || 0);
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type || 'sine';
  osc.frequency.setValueAtTime(freq, t0);
  gain.gain.setValueAtTime(vol || 0.12, t0);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
};

const sfx = {
  select: function () { if (__soundOn) tone(800, 0.04, 'triangle', 0.1); },
  move: function () { if (__soundOn) tone(500, 0.06, 'triangle', 0.12); },
  capture: function () { if (!__soundOn) return; tone(300, 0.08, 'triangle', 0.14); tone(900, 0.08, 'triangle', 0.1, 0.06); },
  king: function () { if (!__soundOn) return; [523, 784, 1047].forEach(function (f, i) { tone(f, 0.14, 'triangle', 0.12, i * 0.09); }); },
  win: function () { if (!__soundOn) return; [523, 659, 784, 1047].forEach(function (f, i) { tone(f, 0.16, 'triangle', 0.13, i * 0.1); }); },
  lose: function () { if (!__soundOn) return; [400, 300, 200].forEach(function (f, i) { tone(f, 0.18, 'triangle', 0.12, i * 0.12); }); },
  draw: function () { if (!__soundOn) return; tone(440, 0.12, 'triangle', 0.12); tone(440, 0.12, 'triangle', 0.12, 0.16); },
  invalid: function () { if (__soundOn) tone(150, 0.1, 'sawtooth', 0.06); }
};

(function () {
  document.addEventListener('pointerdown', function () { ensureAudio(); });
  document.addEventListener('DOMContentLoaded', function () {
    var btn = document.getElementById('soundBtn');
    if (!btn) return;
    var ICON_ON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4z" fill="currentColor" stroke="none"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>';
    var ICON_OFF = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4z" fill="currentColor" stroke="none"/><line x1="16" y1="9" x2="22" y2="15"/><line x1="22" y1="9" x2="16" y2="15"/></svg>';
    var render = function () { btn.innerHTML = isSoundOn() ? ICON_ON : ICON_OFF; };
    var toggle = function () { setSoundOn(!isSoundOn()); render(); };
    btn.addEventListener('mousedown', function (e) { e.stopPropagation(); });
    btn.addEventListener('touchstart', function (e) { e.stopPropagation(); e.preventDefault(); toggle(); }, { passive: false });
    btn.addEventListener('click', function (e) { e.stopPropagation(); toggle(); });
    render();
  });
})();
