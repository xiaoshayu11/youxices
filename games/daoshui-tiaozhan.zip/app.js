/* 倒水挑战（Water Jugs）：装满/倒空/倒入，量出正好目标升数。
   算法（装满/倒空/倒入/判胜/1.5 秒进下一关）沿用上游 Pixel-Arcade waterjugs.js，仅汉化与换主题。
   修复上游毛病：status 文案纯文本（原带 b 标签）；样式全在 styles.css（原 render 注入 style 标签）。 */
var WJ_LEVELS = [{"caps": [5, 3], "target": 4}, {"caps": [8, 5, 3], "target": 4}, {"caps": [12, 7], "target": 6}, {"caps": [9, 4], "target": 6}, {"caps": [10, 7, 3], "target": 5}, {"caps": [14, 9, 5], "target": 11}, {"caps": [17, 6], "target": 8}, {"caps": [15, 9, 4], "target": 8}];

var wjLevel = 0;
var wjCaps = [];
var wjWaters = [];
var wjTarget = 0;
var wjMoves = 0;
var wjWon = false;
var wjSel = null;
var wjAllClear = false;
var wjTimer = null;
var wjSfxClicks = 0;
var wjSfxWins = 0;

// ---- WebAudio 合成音效（无音频文件） ----
var wjAudioCtx = null;
function wjAudio() {
  if (typeof AudioContext === "undefined" && typeof webkitAudioContext === "undefined") return null;
  if (!wjAudioCtx) {
    var AC = (typeof AudioContext !== "undefined") ? AudioContext : webkitAudioContext;
    try { wjAudioCtx = new AC(); } catch (e) { return null; }
  }
  if (wjAudioCtx.state === "suspended") { wjAudioCtx.resume(); }
  return wjAudioCtx;
}
function wjTone(freq, dur, delay, type, gain) {
  var ctx = wjAudio();
  if (!ctx) return;
  var t = ctx.currentTime + (delay || 0);
  var osc = ctx.createOscillator();
  var g = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(gain || 0.12, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}
var sfx = {
  click: function () { wjSfxClicks++; wjTone(1200, 0.05, 0, "square", 0.04); },
  fill: function () { wjSfxClicks++; wjTone(500, 0.12, 0, "sine", 0.1); wjTone(750, 0.14, 0.08, "sine", 0.1); },
  empty: function () { wjSfxClicks++; wjTone(400, 0.12, 0, "sine", 0.09); wjTone(240, 0.16, 0.08, "sine", 0.09); },
  pour: function () { wjSfxClicks++; wjTone(800, 0.1, 0, "sine", 0.09); wjTone(520, 0.14, 0.07, "sine", 0.09); },
  win: function () { wjSfxWins++; wjTone(523, 0.14, 0, "sine", 0.12); wjTone(659, 0.14, 0.12, "sine", 0.12); wjTone(784, 0.26, 0.24, "sine", 0.12); }
};

function wjEl(id) { return document.getElementById(id); }
function wjSetStatus(text, cls) {
  var el = wjEl("wj-status");
  el.textContent = text;
  el.className = "status " + cls;
}

function wjRender() {
  wjEl("wj-lvl").textContent = (wjLevel + 1) + " / " + WJ_LEVELS.length;
  wjEl("wj-moves").textContent = wjMoves;
  wjEl("wj-target").textContent = wjTarget + " 升";
  var box = wjEl("wj-jugs");
  box.innerHTML = "";
  var maxCap = Math.max.apply(null, wjCaps);
  for (var i = 0; i < wjCaps.length; i++) {
    (function (i) {
      var col = document.createElement("div");
      col.className = "jug-col";
      var body = document.createElement("div");
      body.className = "jug-body" + (wjSel === i ? " sel" : "");
      body.setAttribute("data-jug", i);
      body.style.height = Math.round(wjCaps[i] * 180 / maxCap) + "px";
      var water = document.createElement("div");
      water.className = "jug-water";
      water.style.height = (wjWaters[i] / wjCaps[i] * 100) + "%";
      var ticks = document.createElement("div");
      ticks.className = "jug-ticks";
      body.appendChild(water);
      body.appendChild(ticks);
      body.addEventListener("click", function () {
        if (wjWon) return;
        if (wjSel !== null && wjSel !== i) {
          wjAction("pour", i);
        } else {
          wjSel = (wjSel === i) ? null : i;
          if (typeof sfx !== "undefined") sfx.click();
          wjRender();
        }
      });
      var label = document.createElement("div");
      label.className = "jug-label";
      label.textContent = wjWaters[i] + " / " + wjCaps[i] + " 升";
      var btns = document.createElement("div");
      btns.className = "jug-btns";
      var bFill = document.createElement("button");
      bFill.className = "mini-btn";
      bFill.setAttribute("data-fill", i);
      bFill.textContent = "装满";
      bFill.addEventListener("click", function () { wjAction("fill", i); });
      var bEmpty = document.createElement("button");
      bEmpty.className = "mini-btn";
      bEmpty.setAttribute("data-empty", i);
      bEmpty.textContent = "倒空";
      bEmpty.addEventListener("click", function () { wjAction("empty", i); });
      var bPour = document.createElement("button");
      bPour.className = "mini-btn";
      bPour.setAttribute("data-pour", i);
      bPour.textContent = "倒入";
      bPour.addEventListener("click", function () { wjAction("pour", i); });
      btns.appendChild(bFill);
      btns.appendChild(bEmpty);
      btns.appendChild(bPour);
      col.appendChild(body);
      col.appendChild(label);
      col.appendChild(btns);
      box.appendChild(col);
    })(i);
  }
}

function wjAction(kind, idx) {
  if (wjWon) return;
  if (kind === "fill") {
    wjWaters[idx] = wjCaps[idx];
    if (typeof sfx !== "undefined") sfx.fill();
  } else if (kind === "empty") {
    wjWaters[idx] = 0;
    if (typeof sfx !== "undefined") sfx.empty();
  } else if (kind === "pour") {
    if (wjSel === null || wjSel === idx) return;
    var from = wjSel, to = idx;
    var space = wjCaps[to] - wjWaters[to];
    var amount = Math.min(wjWaters[from], space);
    wjWaters[from] -= amount;
    wjWaters[to] += amount;
    if (typeof sfx !== "undefined") sfx.pour();
    wjSel = null;
  }
  wjMoves++;
  wjRender();
  if (wjWaters.indexOf(wjTarget) >= 0) wjWin();
}

function wjWin() {
  wjWon = true;
  if (typeof sfx !== "undefined") sfx.win();
  if (wjLevel >= WJ_LEVELS.length - 1) {
    wjAllClear = true;
    wjSetStatus("全部通关！8 关全过，最后一关用了 " + wjMoves + " 步。点「重新开始」再来一轮。", "win");
  } else {
    wjSetStatus("量出 " + wjTarget + " 升了！用了 " + wjMoves + " 步，下一关…", "win");
    wjTimer = setTimeout(function () { wjLoad(wjLevel + 1); }, 1500);
  }
}

function wjLoad(i) {
  if (wjTimer) { clearTimeout(wjTimer); wjTimer = null; }
  wjLevel = i;
  wjCaps = WJ_LEVELS[i].caps.slice();
  wjWaters = wjCaps.map(function () { return 0; });
  wjTarget = WJ_LEVELS[i].target;
  wjMoves = 0;
  wjWon = false;
  wjSel = null;
  wjAllClear = false;
  wjSetStatus("量出正好 " + wjTarget + " 升水（任意一杯）", "info");
  wjRender();
}

wjEl("wj-restart").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  wjLoad(wjAllClear ? 0 : wjLevel);
});
wjEl("wj-help").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  wjEl("wj-mask").style.display = "block";
});
wjEl("wj-help-close").addEventListener("click", function () {
  wjEl("wj-mask").style.display = "none";
});
wjEl("wj-mask").addEventListener("click", function (e) {
  if (e.target === wjEl("wj-mask")) wjEl("wj-mask").style.display = "none";
});

var WJ = {
  getState: function () {
    return {
      level: wjLevel,
      moves: wjMoves,
      waters: wjWaters.slice(),
      target: wjTarget,
      won: wjWon,
      sel: wjSel,
      helpVisible: wjEl("wj-mask").style.display === "block",
      sfxClicks: wjSfxClicks,
      sfxWins: wjSfxWins
    };
  }
};

wjLoad(0);
