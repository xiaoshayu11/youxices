/* 指尖炼金 — 纯 WebAudio 合成音效（无音频文件）。
 * 顶层 var sfx；调用处一律用 typeof sfx !== 'undefined' 做守卫
 * （顶层 const 不挂 window，见数字拼图教训；var 虽挂 window，仍统一用 typeof 守卫）。
 * AudioContext 只在首次用户手势后创建并 resume（autoplay 策略）；
 * 启动时、场景预设时的调用在手势前发生，一律静默 no-op。
 * 静音偏好存 localStorage（默认开声）；涂抹音效内部节流 90ms。 */
var sfx = (function () {
  'use strict';
  var MUTE_KEY = 'zhijian-lianjin.muted';
  var ctx = null, unlocked = false, noiseBuf = null;
  var muted = false;
  var lastPlay = {};
  try { muted = localStorage.getItem(MUTE_KEY) === '1'; } catch (e) {}

  function resume() {
    if (!ctx) return;
    try {
      if (ctx.state === 'suspended' && ctx.resume) {
        var p = ctx.resume();
        if (p && p.catch) p.catch(function () {});
      }
    } catch (e) {}
  }
  function ensure() {
    if (!unlocked) return null;
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      try { ctx = new AC(); } catch (e) { ctx = null; return null; }
    }
    resume();
    return ctx;
  }
  function unlock() {
    if (unlocked) { resume(); return; }
    unlocked = true;
    ensure();
  }
  function throttle(name, ms) {
    var now = Date.now();
    if (lastPlay[name] && now - lastPlay[name] < ms) return false;
    lastPlay[name] = now;
    return true;
  }
  function tone(freq0, freq1, dur, type, vol) {
    if (muted) return;
    var ac = ensure();
    if (!ac) return;
    try {
      var t0 = ac.currentTime;
      var o = ac.createOscillator();
      var g = ac.createGain();
      o.type = type || 'sine';
      o.frequency.setValueAtTime(Math.max(freq0, 1), t0);
      if (freq1 && freq1 !== freq0) o.frequency.exponentialRampToValueAtTime(Math.max(freq1, 1), t0 + dur);
      g.gain.setValueAtTime(vol || 0.1, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
      o.connect(g);
      g.connect(ac.destination);
      o.start(t0);
      o.stop(t0 + dur + 0.02);
    } catch (e) {}
  }
  function noiseBuffer(ac) {
    if (noiseBuf) return noiseBuf;
    try {
      var len = Math.floor(ac.sampleRate * 0.5);
      var buf = ac.createBuffer(1, len, ac.sampleRate);
      var d = buf.getChannelData(0);
      for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      noiseBuf = buf;
    } catch (e) { noiseBuf = null; }
    return noiseBuf;
  }
  function noiseHit(dur, freq, vol, sweepTo, filterType) {
    if (muted) return;
    var ac = ensure();
    if (!ac) return;
    var buf = noiseBuffer(ac);
    if (!buf) return;
    try {
      var t0 = ac.currentTime;
      var src = ac.createBufferSource();
      src.buffer = buf;
      src.loop = true;
      var f = ac.createBiquadFilter();
      f.type = filterType || 'bandpass';
      f.frequency.setValueAtTime(Math.max(freq, 20), t0);
      if (sweepTo) f.frequency.exponentialRampToValueAtTime(Math.max(sweepTo, 20), t0 + dur);
      if (f.Q) f.Q.value = 1;
      var g = ac.createGain();
      g.gain.setValueAtTime(vol || 0.1, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
      src.connect(f);
      f.connect(g);
      g.connect(ac.destination);
      src.start(t0);
      src.stop(t0 + dur + 0.02);
    } catch (e) {}
  }

  /* 首手势解锁：注册在 window 上，audio.js 先于 app.js 加载，
     故解锁监听先于游戏自身的 pointerdown/keydown 处理跑。 */
  window.addEventListener('pointerdown', unlock);
  window.addEventListener('keydown', unlock);
  window.addEventListener('touchstart', unlock, { passive: true });

  return {
    /* 短促点击：选元素、暂停/下雨/保存按钮 */
    click: function () {
      if (!throttle('click', 50)) return;
      tone(740, 520, 0.07, 'triangle', 0.12);
    },
    /* 涂抹：kind 为 tick（通用）/ drop（水）/ crackle（火/岩浆）。
       三种共用一个 90ms 节流窗，连续涂抹最多每 90ms 响一次。 */
    paint: function (kind) {
      if (!throttle('paint', 90)) return;
      if (kind === 'drop') tone(640 + Math.random() * 120, 170, 0.11, 'sine', 0.09);
      else if (kind === 'crackle') noiseHit(0.045, 2200 + Math.random() * 3000, 0.07, null, 'bandpass');
      else tone(1150 + Math.random() * 250, 900, 0.035, 'sine', 0.05);
    },
    /* 清空：噪声扫过 + 正弦下滑 */
    clear: function () {
      if (!throttle('clear', 300)) return;
      noiseHit(0.35, 2800, 0.10, 320, 'bandpass');
      tone(520, 140, 0.3, 'sine', 0.07);
    },
    setMuted: function (m) {
      muted = !!m;
      try { localStorage.setItem(MUTE_KEY, muted ? '1' : '0'); } catch (e) {}
      return muted;
    },
    isMuted: function () { return muted; },
    /* 仅供测试：返回 AudioContext 状态（未创建时为 'none'） */
    state: function () { return ctx ? ctx.state : 'none'; }
  };
})();
