/* 纯 WebAudio 合成音效（无音频文件）。
 * 顶层 var sfx；调用处一律用 typeof sfx !== 'undefined' 做守卫。
 * 每种音效内部节流：同一音效在节流窗内重复触发只响一次（挡板连续碰撞时防刷屏）。 */
var sfx = (function () {
  'use strict';
  var ctx = null;
  var lastPlay = {};
  function ensure() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }
  function tone(freq0, freq1, dur, type, vol) {
    var ac = ensure();
    if (!ac) return;
    var t0 = ac.currentTime;
    var o = ac.createOscillator();
    var g = ac.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq0, t0);
    if (freq1 && freq1 !== freq0) o.frequency.exponentialRampToValueAtTime(Math.max(freq1, 1), t0 + dur);
    g.gain.setValueAtTime(vol || 0.15, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    o.connect(g);
    g.connect(ac.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }
  function throttle(name, ms) {
    var now = Date.now();
    if (lastPlay[name] && now - lastPlay[name] < ms) return false;
    lastPlay[name] = now;
    return true;
  }
  return {
    launch: function () { if (!throttle('launch', 150)) return; tone(300, 900, 0.25, 'sine', 0.18); },
    flip: function () { if (!throttle('flip', 70)) return; tone(220, 140, 0.08, 'square', 0.12); },
    bumper: function () { if (!throttle('bumper', 60)) return; tone(880, 1320, 0.12, 'triangle', 0.16); },
    drain: function () { if (!throttle('drain', 200)) return; tone(400, 90, 0.4, 'sine', 0.18); }
  };
})();
