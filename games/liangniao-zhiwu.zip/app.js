// 椋鸟之舞 —— 改编自 Ben Eater 的 Boids（MIT，https://github.com/beneater/boids）
// 画布尺寸随舞台区域变化；飞行参数由界面滑杆实时调节。
let width = 150;
let height = 150;

// 飞行参数（滑杆实时改这里）
const params = {
  count: 100,       // 鸟群数量
  visualRange: 75,  // 视野
  centering: 0.005, // 聚合
  avoid: 0.05,      // 分离
  matching: 0.05,   // 对齐
  speedLimit: 15,   // 速度上限
};

const THEMES = ["#558cf4", "#f4b400", "#f472b6", "#34d399", "#a78bfa"];
let themeIdx = 0;
let paused = false;
// 捕食者（手指/鼠标按住拖动的位置），null 表示未激活
let predator = null;

var boids = [];

function initBoids() {
  for (var i = 0; i < params.count; i += 1) {
    boids[boids.length] = {
      x: Math.random() * width,
      y: Math.random() * height,
      dx: Math.random() * 10 - 5,
      dy: Math.random() * 10 - 5,
      history: [],
    };
  }
}

// 调整鸟群数量（多了补、少了截），并刷新顶栏计数
function setCount(n) {
  params.count = n;
  while (boids.length < n) {
    boids.push({
      x: Math.random() * width,
      y: Math.random() * height,
      dx: Math.random() * 10 - 5,
      dy: Math.random() * 10 - 5,
      history: [],
    });
  }
  boids.length = n;
  document.getElementById("birdcount").textContent = n;
}

function distance(boid1, boid2) {
  return Math.sqrt(
    (boid1.x - boid2.x) * (boid1.x - boid2.x) +
      (boid1.y - boid2.y) * (boid1.y - boid2.y),
  );
}

// Called initially and whenever the window resizes to update the canvas
// size and width/height variables.
function sizeCanvas() {
  const canvas = document.getElementById("boids");
  const stage = document.getElementById("stage");
  width = stage.clientWidth;
  height = stage.clientHeight;
  canvas.width = width;
  canvas.height = height;
}

// Constrain a boid to within the window. If it gets too close to an edge,
// nudge it back in and reverse its direction.
function keepWithinBounds(boid) {
  const margin = Math.max(30, Math.min(width, height) * 0.15);
  const turnFactor = 1;

  if (boid.x < margin) {
    boid.dx += turnFactor;
  }
  if (boid.x > width - margin) {
    boid.dx -= turnFactor
  }
  if (boid.y < margin) {
    boid.dy += turnFactor;
  }
  if (boid.y > height - margin) {
    boid.dy -= turnFactor;
  }
}

// Find the center of mass of the other boids and adjust velocity slightly to
// point towards the center of mass.
function flyTowardsCenter(boid) {
  const centeringFactor = params.centering;

  let centerX = 0;
  let centerY = 0;
  let numNeighbors = 0;

  for (let otherBoid of boids) {
    if (distance(boid, otherBoid) < params.visualRange) {
      centerX += otherBoid.x;
      centerY += otherBoid.y;
      numNeighbors += 1;
    }
  }

  if (numNeighbors) {
    centerX = centerX / numNeighbors;
    centerY = centerY / numNeighbors;

    boid.dx += (centerX - boid.x) * centeringFactor;
    boid.dy += (centerY - boid.y) * centeringFactor;
  }
}

// Move away from other boids that are too close to avoid colliding
function avoidOthers(boid) {
  const minDistance = 20; // The distance to stay away from other boids
  const avoidFactor = params.avoid;
  let moveX = 0;
  let moveY = 0;
  for (let otherBoid of boids) {
    if (otherBoid !== boid) {
      if (distance(boid, otherBoid) < minDistance) {
        moveX += boid.x - otherBoid.x;
        moveY += boid.y - otherBoid.y;
      }
    }
  }

  boid.dx += moveX * avoidFactor;
  boid.dy += moveY * avoidFactor;
}

// Find the average velocity (speed and direction) of the other boids and
// adjust velocity slightly to match.
function matchVelocity(boid) {
  const matchingFactor = params.matching;

  let avgDX = 0;
  let avgDY = 0;
  let numNeighbors = 0;

  for (let otherBoid of boids) {
    if (distance(boid, otherBoid) < params.visualRange) {
      avgDX += otherBoid.dx;
      avgDY += otherBoid.dy;
      numNeighbors += 1;
    }
  }

  if (numNeighbors) {
    avgDX = avgDX / numNeighbors;
    avgDY = avgDY / numNeighbors;

    boid.dx += (avgDX - boid.dx) * matchingFactor;
    boid.dy += (avgDY - boid.dy) * matchingFactor;
  }
}

// 躲避捕食者：手指/鼠标按住的位置会把附近的鸟惊散
function avoidPredator(boid) {
  if (!predator) return;
  const scareRange = 110;
  const dx = boid.x - predator.x;
  const dy = boid.y - predator.y;
  const d = Math.sqrt(dx * dx + dy * dy);
  if (d < scareRange && d > 0.01) {
    const f = (1 - d / scareRange) * 1.2;
    boid.dx += (dx / d) * f;
    boid.dy += (dy / d) * f;
  }
}

// Speed will naturally vary in flocking behavior, but real animals can't go
// arbitrarily fast.
function limitSpeed(boid) {
  const speedLimit = params.speedLimit;

  const speed = Math.sqrt(boid.dx * boid.dx + boid.dy * boid.dy);
  if (speed > speedLimit) {
    boid.dx = (boid.dx / speed) * speedLimit;
    boid.dy = (boid.dy / speed) * speedLimit;
  }
}

const DRAW_TRAIL = false;

function drawBoid(ctx, boid) {
  const angle = Math.atan2(boid.dy, boid.dx);
  ctx.translate(boid.x, boid.y);
  ctx.rotate(angle);
  ctx.translate(-boid.x, -boid.y);
  ctx.fillStyle = THEMES[themeIdx];
  ctx.beginPath();
  ctx.moveTo(boid.x, boid.y);
  ctx.lineTo(boid.x - 15, boid.y + 5);
  ctx.lineTo(boid.x - 15, boid.y - 5);
  ctx.lineTo(boid.x, boid.y);
  ctx.fill();
  ctx.setTransform(1, 0, 0, 1, 0, 0);

  if (DRAW_TRAIL) {
    ctx.strokeStyle = "#558cf466";
    ctx.beginPath();
    ctx.moveTo(boid.history[0][0], boid.history[0][1]);
    for (const point of boid.history) {
      ctx.lineTo(point[0], point[1]);
    }
    ctx.stroke();
  }
}

// Main animation loop
// 单步推进所有鸟（主循环每帧调一次；测试也可直接调）
function updateBoids() {
  for (let boid of boids) {
    // Update the velocities according to each rule
    flyTowardsCenter(boid);
    avoidOthers(boid);
    matchVelocity(boid);
    avoidPredator(boid);
    limitSpeed(boid);
    keepWithinBounds(boid);

    // Update the position based on the current velocity
    boid.x += boid.dx;
    boid.y += boid.dy;
    if (DRAW_TRAIL) {
      boid.history.push([boid.x, boid.y]);
      boid.history = boid.history.slice(-50);
    }
  }
}

function animationLoop() {
  // Update each boid
  if (!paused) updateBoids();

  // Clear the canvas and redraw all the boids in their current positions
  const ctx = document.getElementById("boids").getContext("2d");
  ctx.clearRect(0, 0, width, height);
  if (predator) {
    ctx.strokeStyle = "rgba(229,72,77,0.5)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(predator.x, predator.y, 26, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = "rgba(229,72,77,0.22)";
    ctx.beginPath();
    ctx.arc(predator.x, predator.y, 26, 0, Math.PI * 2);
    ctx.fill();
  }
  for (let boid of boids) {
    drawBoid(ctx, boid);
  }

  // Schedule the next frame
  window.requestAnimationFrame(animationLoop);
}

/* ============ 音频：纯 WebAudio 合成，无音频文件 ============ */
var AudioSys = (function () {
  var AC = window.AudioContext || window.webkitAudioContext;
  var ctx = null;
  var master = null;
  var muted = false;
  var started = false;
  var chirpsPlayed = 0;
  var lastWhoosh = 0;
  var PENTA = [261.63, 293.66, 329.63, 392.0, 440.0, 523.25, 587.33, 659.25];

  function ensure() {
    if (ctx) return true;
    if (!AC) return false;
    try {
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : 1;
      master.connect(ctx.destination);
    } catch (e) {
      ctx = null;
      return false;
    }
    return true;
  }

  function start() {
    if (!ensure()) return;
    if (ctx.state === "suspended") ctx.resume();
    if (started) return;
    started = true;
    schedulePad();
    scheduleChirp();
  }

  function padNote(freq, t0) {
    var o = ctx.createOscillator();
    var g = ctx.createGain();
    var f = ctx.createBiquadFilter();
    o.type = "triangle";
    o.frequency.value = freq;
    f.type = "lowpass";
    f.frequency.value = 1200;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(0.05, t0 + 0.9);
    g.gain.linearRampToValueAtTime(0.0001, t0 + 3.2);
    o.connect(f);
    f.connect(g);
    g.connect(master);
    o.start(t0);
    o.stop(t0 + 3.3);
  }

  function schedulePad() {
    if (!started) return;
    var t0 = ctx.currentTime + 0.1;
    padNote(PENTA[Math.floor(Math.random() * PENTA.length)], t0);
    padNote(PENTA[Math.floor(Math.random() * PENTA.length)], t0);
    setTimeout(schedulePad, 3000 + Math.random() * 3000);
  }

  function chirp() {
    if (!started) return;
    chirpsPlayed++;
    var t0 = ctx.currentTime + 0.05;
    var base = 2200 + Math.random() * 1200;
    var n = 2 + Math.floor(Math.random() * 3);
    var pan = null;
    if (ctx.createStereoPanner) {
      pan = ctx.createStereoPanner();
      pan.pan.value = Math.random() * 1.6 - 0.8;
      pan.connect(master);
    }
    for (var i = 0; i < n; i++) {
      var o = ctx.createOscillator();
      var g = ctx.createGain();
      var s = t0 + i * 0.09;
      o.type = "sine";
      o.frequency.setValueAtTime(base * (1 + Math.random() * 0.15), s);
      o.frequency.exponentialRampToValueAtTime(base * 0.7, s + 0.07);
      g.gain.setValueAtTime(0.0001, s);
      g.gain.exponentialRampToValueAtTime(0.12, s + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, s + 0.08);
      o.connect(g);
      g.connect(pan || master);
      o.start(s);
      o.stop(s + 0.1);
    }
  }

  function scheduleChirp() {
    if (!started) return;
    chirp();
    setTimeout(scheduleChirp, 2000 + Math.random() * 5000);
  }

  function whoosh() {
    if (!started || !ctx) return;
    var now = ctx.currentTime;
    if (now - lastWhoosh < 0.3) return;
    lastWhoosh = now;
    var len = Math.floor(ctx.sampleRate * 0.4);
    var buf = ctx.createBuffer(1, len, ctx.sampleRate);
    var d = buf.getChannelData(0);
    for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    var src = ctx.createBufferSource();
    src.buffer = buf;
    var f = ctx.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.setValueAtTime(400, now);
    f.frequency.exponentialRampToValueAtTime(2000, now + 0.35);
    f.Q.value = 1.2;
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(0.18, now + 0.08);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.4);
    src.connect(f);
    f.connect(g);
    g.connect(master);
    src.start(now);
  }

  function toggle() {
    muted = !muted;
    if (master) master.gain.value = muted ? 0 : 1;
    if (!muted) start();
    return muted;
  }

  return {
    start: start,
    toggle: toggle,
    isMuted: function () { return muted; },
    whoosh: whoosh,
    chirpNow: chirp,
    state: function () {
      return {
        ctx: ctx ? ctx.state : "none",
        started: started,
        muted: muted,
        chirps: chirpsPlayed
      };
    }
  };
})();

// 把所有鸟的速度随机打散
function scatter() {
  for (let boid of boids) {
    boid.dx = Math.random() * 24 - 12;
    boid.dy = Math.random() * 24 - 12;
  }
  AudioSys.whoosh();
}

function bindUI() {
  const $ = (id) => document.getElementById(id);
  const num = (v) => String(Math.round(v * 1000) / 1000);
  const slider = (id, key, fmt, apply) => {
    const el = $(id);
    const out = $(id + "v");
    const update = () => {
      const v = parseFloat(el.value);
      params[key] = v;
      out.textContent = fmt(v);
      if (apply) apply(v);
    };
    el.addEventListener("input", update);
    update();
  };
  slider("count", "count", (v) => Math.round(v) + " 只",
    (v) => setCount(Math.round(v)));
  slider("coherence", "centering", num);
  slider("separation", "avoid", num);
  slider("alignment", "matching", num);
  slider("visual", "visualRange", (v) => String(Math.round(v)));
  slider("speed", "speedLimit", (v) => String(Math.round(v)));

  $("scatter").addEventListener("click", scatter);
  $("theme").addEventListener("click", () => {
    themeIdx = (themeIdx + 1) % THEMES.length;
  });
  $("sound").addEventListener("click", () => {
    AudioSys.toggle();
    $("sound").textContent = AudioSys.isMuted() ? "音效关" : "音效开";
  });
  document.addEventListener("pointerdown", function unlockAudio() {
    AudioSys.start();
    document.removeEventListener("pointerdown", unlockAudio);
  });

  $("pause").addEventListener("click", () => {
    paused = !paused;
    $("pause").textContent = paused ? "继续" : "暂停";
  });

  // 捕食者：按住拖动，鸟群四散
  const cv = $("boids");
  const setPred = (e) => {
    const r = cv.getBoundingClientRect();
    predator = { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  cv.addEventListener("pointerdown", (e) => {
    cv.setPointerCapture(e.pointerId);
    AudioSys.start();
    AudioSys.whoosh();
    setPred(e);
  });
  cv.addEventListener("pointermove", (e) => { if (predator) setPred(e); });
  const clearPred = () => { predator = null; };
  cv.addEventListener("pointerup", clearPred);
  cv.addEventListener("pointercancel", clearPred);
}

window.onload = () => {
  const stage = document.getElementById("stage");
  new ResizeObserver(sizeCanvas).observe(stage);
  window.addEventListener("resize", sizeCanvas, false);
  sizeCanvas();

  // Randomly distribute the boids to start
  initBoids();
  bindUI();

  // Schedule the main animation loop
  window.requestAnimationFrame(animationLoop);
};

// 调试 API（冒烟测试用）
window.__boids = {
  count: () => boids.length,
  params,
  setCount,
  scatter,
  tick(n) { for (let i = 0; i < n; i++) updateBoids(); },
  setPredator(x, y) { predator = (x == null) ? null : { x, y }; },
  first() {
    const b = boids[0];
    return b ? { x: Math.round(b.x), y: Math.round(b.y) } : null;
  },
  maxSpeed() {
    let m = 0;
    for (const b of boids) {
      const s = Math.hypot(b.dx, b.dy);
      if (s > m) m = s;
    }
    return Math.round(m * 10) / 10;
  },
  setPaused(v) { paused = v; },
  audioState: () => AudioSys.state(),
  audioStart: () => AudioSys.start(),
  audioToggle: () => AudioSys.toggle(),
  chirpNow: () => AudioSys.chirpNow(),
  whoosh: () => AudioSys.whoosh(),
  isPaused: () => paused,
};
