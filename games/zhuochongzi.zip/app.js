/* 捉虫子（Catch The Insect）：60 秒内点中草地上的昆虫得分，捉一只刷两只。
   机制源自 he-is-talha 26-Insect-Catch-Game（MIT），昆虫为内联 SVG 手绘。 */
function zcEl(id) { return document.getElementById(id); }

/* ---- WebAudio 合成音效 ---- */
var zcAudioCtx = null;
function zcCtx() {
  if (!zcAudioCtx) {
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    zcAudioCtx = new AC();
  }
  if (zcAudioCtx.state === "suspended") zcAudioCtx.resume();
  return zcAudioCtx;
}
function zcTone(freqFrom, freqTo, dur, type, vol, delay) {
  var ctx = zcCtx();
  if (!ctx) return;
  var t0 = ctx.currentTime + (delay || 0);
  var osc = ctx.createOscillator();
  var gain = ctx.createGain();
  osc.type = type || "sine";
  osc.frequency.setValueAtTime(freqFrom, t0);
  osc.frequency.exponentialRampToValueAtTime(Math.max(freqTo, 1), t0 + dur);
  gain.gain.setValueAtTime(vol || 0.15, t0);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}
var sfx = {
  catchBug: function () { zcTone(620, 980, 0.12, "sine", 0.18, 0); },
  miss: function () { zcTone(200, 140, 0.1, "triangle", 0.08, 0); },
  click: function () { zcTone(500, 700, 0.07, "sine", 0.1, 0); },
  end: function () {
    zcTone(523, 523, 0.14, "sine", 0.16, 0);
    zcTone(659, 659, 0.14, "sine", 0.16, 0.15);
    zcTone(784, 784, 0.22, "sine", 0.16, 0.3);
  }
};

/* ---- 4 种昆虫内联 SVG（瓢虫/蝴蝶/蜜蜂/蜻蜓） ---- */
var ZC_BUGS = [
  '<svg viewBox="0 0 100 100"><g stroke="#333" stroke-width="4" stroke-linecap="round"><path d="M28 38 L12 28"/><path d="M26 55 L9 55"/><path d="M28 72 L12 82"/><path d="M72 38 L88 28"/><path d="M74 55 L91 55"/><path d="M72 72 L88 82"/></g><ellipse cx="50" cy="56" rx="27" ry="31" fill="#e23b3b"/><path d="M50 27 L50 85" stroke="#333" stroke-width="3"/><circle cx="50" cy="26" r="12" fill="#333"/><circle cx="38" cy="48" r="5" fill="#333"/><circle cx="63" cy="44" r="4" fill="#333"/><circle cx="42" cy="68" r="4" fill="#333"/><circle cx="61" cy="70" r="5" fill="#333"/><circle cx="45" cy="23" r="2.4" fill="#fff"/><circle cx="56" cy="23" r="2.4" fill="#fff"/></svg>',
  '<svg viewBox="0 0 100 100"><ellipse cx="28" cy="34" rx="20" ry="14" fill="#b06fd8" transform="rotate(-30 28 34)"/><ellipse cx="72" cy="34" rx="20" ry="14" fill="#b06fd8" transform="rotate(30 72 34)"/><ellipse cx="31" cy="66" rx="16" ry="11" fill="#f2a541" transform="rotate(25 31 66)"/><ellipse cx="69" cy="66" rx="16" ry="11" fill="#f2a541" transform="rotate(-25 69 66)"/><ellipse cx="50" cy="52" rx="6" ry="26" fill="#5b3a29"/><circle cx="50" cy="24" r="7" fill="#5b3a29"/><path d="M46 19 Q38 8 31 7" stroke="#5b3a29" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M54 19 Q62 8 69 7" stroke="#5b3a29" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="30" cy="33" r="4" fill="#fff" opacity="0.7"/><circle cx="70" cy="33" r="4" fill="#fff" opacity="0.7"/></svg>',
  '<svg viewBox="0 0 100 100"><ellipse cx="34" cy="26" rx="16" ry="9" fill="#cfe8ff" opacity="0.85" transform="rotate(-25 34 26)"/><ellipse cx="66" cy="26" rx="16" ry="9" fill="#cfe8ff" opacity="0.85" transform="rotate(25 66 26)"/><ellipse cx="50" cy="58" rx="24" ry="28" fill="#f7c948"/><path d="M30 48 Q50 56 70 48 L70 60 Q50 68 30 60 Z" fill="#333"/><path d="M33 72 Q50 79 67 72 L64 82 Q50 87 36 82 Z" fill="#333"/><circle cx="50" cy="32" r="11" fill="#333"/><circle cx="45" cy="29" r="2.4" fill="#fff"/><circle cx="56" cy="29" r="2.4" fill="#fff"/><path d="M50 86 L45 95 L55 95 Z" fill="#333"/></svg>',
  '<svg viewBox="0 0 100 100"><ellipse cx="24" cy="36" rx="22" ry="7" fill="#a8d8f0" opacity="0.8" transform="rotate(-18 24 36)"/><ellipse cx="76" cy="36" rx="22" ry="7" fill="#a8d8f0" opacity="0.8" transform="rotate(18 76 36)"/><ellipse cx="27" cy="52" rx="18" ry="6" fill="#a8d8f0" opacity="0.65" transform="rotate(14 27 52)"/><ellipse cx="73" cy="52" rx="18" ry="6" fill="#a8d8f0" opacity="0.65" transform="rotate(-14 73 52)"/><rect x="46" y="34" width="8" height="52" rx="4" fill="#1f9e8f"/><circle cx="50" cy="28" r="10" fill="#1f9e8f"/><circle cx="44" cy="25" r="4.5" fill="#14665c"/><circle cx="56" cy="25" r="4.5" fill="#14665c"/><path d="M46 44 L54 44 M46 56 L54 56 M46 68 L54 68" stroke="#14665c" stroke-width="2.5"/></svg>'
];
var ZC_FLOWER = '<svg viewBox="0 0 100 100"><g fill="#ffffff"><circle cx="50" cy="26" r="14"/><circle cx="72" cy="44" r="14"/><circle cx="63" cy="70" r="14"/><circle cx="37" cy="70" r="14"/><circle cx="28" cy="44" r="14"/></g><circle cx="50" cy="50" r="12" fill="#ffb020"/></svg>';

/* ---- 游戏状态 ---- */
var ZC_DURATION = 60;
var zcScreen = "home";
var zcScore = 0;
var zcTimeLeft = ZC_DURATION;
var zcOver = false;
var zcTimerId = null;
var zcLastTick = 0;
var zcSpawnTimers = [];
var zcMsgTimer = null;
var zcSfxClicks = 0;
var zcSfxWins = 0;
var zcSfxMiss = 0;

function zcUpdateHud() {
  zcEl("zc-score").textContent = zcScore;
  var t = Math.ceil(Math.max(zcTimeLeft, 0));
  zcEl("zc-time").textContent = t;
  var pct = Math.max(zcTimeLeft, 0) / ZC_DURATION * 100;
  zcEl("zc-timefill").style.width = pct + "%";
}

function zcClearTimers() {
  if (zcTimerId) { clearInterval(zcTimerId); zcTimerId = null; }
  for (var i = 0; i < zcSpawnTimers.length; i++) clearTimeout(zcSpawnTimers[i]);
  zcSpawnTimers = [];
  if (zcMsgTimer) { clearTimeout(zcMsgTimer); zcMsgTimer = null; }
}

function zcClearBugs() {
  var bugs = document.querySelectorAll(".zc-bug");
  for (var i = 0; i < bugs.length; i++) bugs[i].parentNode.removeChild(bugs[i]);
}

function zcScheduleSpawn(delay) {
  var id = setTimeout(zcCreateInsect, delay);
  zcSpawnTimers.push(id);
}

function zcCreateInsect() {
  if (zcOver || zcScreen !== "game") return;
  var field = zcEl("zc-field");
  var bug = document.createElement("div");
  bug.className = "zc-bug";
  var kind = Math.floor(Math.random() * ZC_BUGS.length);
  var x = 12 + Math.random() * 76;
  var y = 18 + Math.random() * 66;
  bug.style.left = x + "%";
  bug.style.top = y + "%";
  var rot = Math.floor(Math.random() * 360);
  bug.innerHTML = '<div style="width:100%;height:100%;transform:rotate(' + rot + 'deg)">' + ZC_BUGS[kind] + "</div>";
  bug.setAttribute("data-caught", "0");
  var handler = function (e) {
    if (e && e.preventDefault) e.preventDefault();
    if (e && e.stopPropagation) e.stopPropagation();
    zcCatch(bug);
  };
  bug.addEventListener("touchstart", handler);
  bug.addEventListener("click", handler);
  field.appendChild(bug);
}

function zcCatch(bug) {
  if (zcOver || zcScreen !== "game") return;
  if (bug.getAttribute("data-caught") === "1") return;
  bug.setAttribute("data-caught", "1");
  zcScore++;
  zcSfxClicks++;
  if (typeof sfx !== "undefined") sfx.catchBug();
  bug.className = "zc-bug caught";
  setTimeout(function () {
    if (bug.parentNode) bug.parentNode.removeChild(bug);
  }, 300);
  zcScheduleSpawn(1000);
  zcScheduleSpawn(1500);
  if (zcScore === 20) {
    zcEl("zc-msg").className = "zc-msg visible";
    if (zcMsgTimer) clearTimeout(zcMsgTimer);
    zcMsgTimer = setTimeout(function () { zcEl("zc-msg").className = "zc-msg"; }, 2500);
  }
  zcUpdateHud();
}

function zcTick() {
  var now = Date.now();
  var dt = (now - zcLastTick) / 1000;
  zcLastTick = now;
  zcTimeLeft -= dt;
  if (zcTimeLeft <= 0) {
    zcTimeLeft = 0;
    zcUpdateHud();
    zcEnd();
    return;
  }
  zcUpdateHud();
}

function zcStart() {
  zcClearTimers();
  zcClearBugs();
  zcScore = 0;
  zcTimeLeft = ZC_DURATION;
  zcOver = false;
  zcEl("zc-over").className = "zc-over zc-hidden";
  zcEl("zc-msg").className = "zc-msg";
  zcUpdateHud();
  zcScheduleSpawn(1000);
  zcLastTick = Date.now();
  zcTimerId = setInterval(zcTick, 200);
}

function zcEnd() {
  zcOver = true;
  zcClearTimers();
  zcClearBugs();
  zcSfxWins++;
  if (typeof sfx !== "undefined") sfx.end();
  zcEl("zc-final").textContent = zcScore;
  zcEl("zc-over").className = "zc-over";
}

function zcShowHome() {
  zcScreen = "home";
  zcClearTimers();
  zcClearBugs();
  zcEl("zc-game").className = "zc-hidden";
  zcEl("zc-home").className = "";
}

function zcShowGame() {
  zcScreen = "game";
  zcEl("zc-home").className = "zc-hidden";
  zcEl("zc-game").className = "";
  zcStart();
}

/* ---- 装饰花朵 ---- */
function zcDecorate() {
  var field = zcEl("zc-field");
  var spots = [[8, 78], [86, 72], [14, 30], [90, 24]];
  for (var i = 0; i < spots.length; i++) {
    var f = document.createElement("div");
    f.className = "zc-flower";
    f.style.left = spots[i][0] + "%";
    f.style.top = spots[i][1] + "%";
    f.innerHTML = ZC_FLOWER;
    field.appendChild(f);
  }
  var homeBugs = document.querySelectorAll(".zc-home-bug");
  for (var j = 0; j < homeBugs.length; j++) homeBugs[j].innerHTML = ZC_BUGS[j % ZC_BUGS.length];
}

/* ---- 事件绑定 ---- */
zcEl("zc-start").addEventListener("click", function () {
  zcCtx();
  if (typeof sfx !== "undefined") sfx.click();
  zcShowGame();
});
zcEl("zc-again").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  zcStart();
});
zcEl("zc-back").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  zcShowHome();
});
zcEl("zc-over-home").addEventListener("click", function () {
  if (typeof sfx !== "undefined") sfx.click();
  zcShowHome();
});
function zcOpenHelp() {
  if (typeof sfx !== "undefined") sfx.click();
  zcEl("zc-mask").className = "zc-mask open";
}
zcEl("zc-help").addEventListener("click", zcOpenHelp);
zcEl("zc-help-home").addEventListener("click", zcOpenHelp);
zcEl("zc-help-close").addEventListener("click", function () {
  zcEl("zc-mask").className = "zc-mask";
});
zcEl("zc-mask").addEventListener("click", function (e) {
  if (e.target === zcEl("zc-mask")) zcEl("zc-mask").className = "zc-mask";
});
function zcFieldTap(e) {
  if (zcOver || zcScreen !== "game") return;
  if (e.target === zcEl("zc-field") || e.target.className === "zc-flower" || (e.target.parentNode && e.target.parentNode.className === "zc-flower")) {
    zcSfxMiss++;
    if (typeof sfx !== "undefined") sfx.miss();
  }
}
zcEl("zc-field").addEventListener("touchstart", zcFieldTap);
zcEl("zc-field").addEventListener("click", zcFieldTap);

/* ---- 测试桥 ---- */
var ZC = {
  getState: function () {
    return {
      screen: zcScreen,
      score: zcScore,
      timeLeft: Math.round(zcTimeLeft * 10) / 10,
      bugsVisible: document.querySelectorAll(".zc-bug").length,
      over: zcOver,
      helpVisible: zcEl("zc-mask").className.indexOf("open") >= 0,
      sfxClicks: zcSfxClicks,
      sfxWins: zcSfxWins,
      sfxMiss: zcSfxMiss
    };
  },
  setTimeLeft: function (s) {
    zcTimeLeft = s;
    zcLastTick = Date.now();
    zcUpdateHud();
    return ZC.getState();
  }
};

zcDecorate();
zcUpdateHud();
